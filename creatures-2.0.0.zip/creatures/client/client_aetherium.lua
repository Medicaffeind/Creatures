local defaultMaxAetherium = 100

CreateThread(function()

    while not LocalPlayer.state.isLoggedIn do
        Wait(1000)
    end

    LocalPlayer.state.maxAetherium =
        LocalPlayer.state.maxAetherium or defaultMaxAetherium

    LocalPlayer.state.aetherium =
        LocalPlayer.state.aetherium or defaultMaxAetherium
end)

exports('GetAetherium', function()
    return LocalPlayer.state.aetherium or 0
end)

exports('SetAetherium', function(value)
    if type(value) ~= 'number' or value ~= value or value < 0 or value == math.huge then return false end


    value = math.max(
        0,
        math.min(
            LocalPlayer.state.maxAetherium or 100,
            value
        )
    )

    LocalPlayer.state.aetherium = value

    TriggerServerEvent(
        'creatures:server:update',
        value
    )

    return value
end)

exports('AddAetherium', function(amount)
    if type(amount) ~= 'number' or amount ~= amount or amount < 0 or amount == math.huge then return false end


    local current =
        LocalPlayer.state.aetherium or 0

    return exports.creatures:SetAetherium(
        current + amount
    )
end)

exports('RemoveAetherium', function(amount)
    if type(amount) ~= 'number' or amount ~= amount or amount < 0 or amount == math.huge then return false end


    local current =
        LocalPlayer.state.aetherium or 0

    if current < amount then
        return false
    end

    exports.creatures:SetAetherium(
        current - amount
    )

    return true
end)

RegisterNetEvent(
    'creatures:client:set',
    function(value)

        LocalPlayer.state.aetherium = value
    end
)

RegisterCommand('mana', function()

    local current =
        LocalPlayer.state.aetherium or 0

    local max =
    LocalPlayer.state.maxAetherium or 100

    if LocalPlayer.state.demonVeiled then
            max = 50
    end

    lib.notify({
        title = "Aetherium Reserves",
        description = ("Your magical reserves are at %s / %s."):format(
            current,
            max
        ),
        type = "inform"
    })

end)

-- Regeneration
CreateThread(function()

    while true do
        Wait(5000)

        local current =
            LocalPlayer.state.aetherium or 100

        local max =
            LocalPlayer.state.maxAetherium or 100

        if LocalPlayer.state.demonVeiled then
            max = 50
        end

        if LocalPlayer.state.isLoggedIn and current < max then

            exports.creatures:SetAetherium(
                math.min(max, current + 5)
            )
        end
    end
end)