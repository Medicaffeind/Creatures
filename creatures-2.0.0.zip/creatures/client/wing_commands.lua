if not Config.Wings.enabled then return end

-- Generic flight control for adapters and servers without vendor commands.
-- This starts the configured flight engine; wing meshes are equipped by packs.
local flying = false
AddEventHandler('flight:deactivate', function() flying = false end)
RegisterCommand('wingflight', function(_, args)
    if flying then
        TriggerEvent('flight:deactivate')
        return
    end
    local wingSet = args[1]
    if not wingSet or not Config.WingRaceAccess[wingSet] then
        return lib.notify({ title = 'Wing flight', type = 'inform',
            description = 'Usage: /wingflight [wingSet] [speed 1-3]. See shared/wings.lua for wing sets.' })
    end
    if not lib.callback.await('creatures:server:canUseWingSet', false, wingSet) then
        return lib.notify({ title = 'Wing flight', type = 'error', description = 'Your race cannot use this wing set.' })
    end
    local selected = exports.creatures:GetSelectedFlightSpeed()
    local ok, preset = exports.creatures:SetFlightSpeed(args[2] or selected, true, false)
    if ok then flying = exports.creatures:ActivateFlight(preset) end
end, false)
