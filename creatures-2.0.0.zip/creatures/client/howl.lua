local settings = Config.Howl
if not settings.Enabled then return end

local active, gpsOffers = {}, {}
local gpsPromptRunning = false
local ready = false

RegisterNUICallback('ready', function(_, cb)
    ready = true
    cb({ ok = true })
end)
RegisterNUICallback('audioError', function(data, cb)
    print(('[creatures] Howl audio failed: %s'):format(tostring(data.message):sub(1, 200)))
    cb({ ok = true })
end)

local function stop(id)
    active[id] = nil
    SendNUIMessage({ action = 'stop', id = id })
end

local function requestHowl()
    TriggerServerEvent('creatures:howl:request')
end
RegisterCommand(settings.Command, requestHowl, false)
AddEventHandler('creatures:howl', requestHowl)
exports('Howl', requestHowl)

RegisterNetEvent('creatures:howl:play', function(id, pos, soundIndex)
    if source ~= 65535 or not ready then return end
    local url = settings.SoundUrls[soundIndex]
    if type(url) ~= 'string' then return end
    if not url:match('^https://') then
        url = ('https://cfx-nui-%s/%s'):format(GetCurrentResourceName(), url)
    end
    active[id] = { pos = vector3(pos.x, pos.y, pos.z), started = GetGameTimer() }
    SendNUIMessage({ action = 'play', id = id, url = url, duration = settings.DurationMs })
end)
RegisterNetEvent('creatures:howl:position', function(id, pos)
    if source ~= 65535 or not active[id] then return end
    active[id].pos = vector3(pos.x, pos.y, pos.z)
end)
RegisterNetEvent('creatures:howl:stop', function(id)
    if source == 65535 then stop(id) end
end)

CreateThread(function()
    while true do
        Wait(next(active) and 100 or 500)
        local listener = GetEntityCoords(PlayerPedId())
        local yaw = math.rad(GetGameplayCamRot(2).z)
        for id, howl in pairs(active) do
            if GetGameTimer() - howl.started > settings.DurationMs then
                stop(id)
            else
                local delta = howl.pos - listener
                local horizontal = math.sqrt(delta.x * delta.x + delta.y * delta.y)
                local pan = horizontal > 0.1
                    and (delta.x * math.cos(yaw) + delta.y * math.sin(yaw)) / horizontal or 0
                local volume = settings.Volume * math.max(0, 1 - #delta / settings.Range)
                SendNUIMessage({ action = 'update', id = id, volume = volume, pan = pan })
            end
        end
    end
end)

local function cleanup()
    for id in pairs(active) do stop(id) end
    gpsOffers = {}
end
AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then cleanup() end
end)
RegisterNetEvent('QBCore:Client:OnPlayerUnload', cleanup)

RegisterNetEvent('creatures:howl:gpsOffer', function(pos)
    if source ~= 65535 or not settings.GpsPrompt then return end
    gpsOffers[#gpsOffers + 1] = { x = pos.x, y = pos.y, received = GetGameTimer() }
    if gpsPromptRunning then return end
    gpsPromptRunning = true
    CreateThread(function()
        while #gpsOffers > 0 do
            local offer = table.remove(gpsOffers, 1)
            if GetGameTimer() - offer.received < 60000 then
                local ok, answer = pcall(lib.alertDialog, {
                    header = 'A Werewolf Howls',
                    content = 'You hear a distant howl. Mark its location on your GPS?',
                    centered = true, cancel = true,
                    labels = { confirm = 'Yes', cancel = 'No' }
                }, 30000)
                if ok and answer == 'confirm' and LocalPlayer.state.isLoggedIn then
                    SetNewWaypoint(offer.x, offer.y)
                end
            end
        end
        gpsPromptRunning = false
    end)
end)

