if not Config.Wings.enabled then return end

local settings = Config.FlightSpeeds or {}
local selectedLevel = 1
local maximumLevel = 0
local currentTier = 0
local mathStoreFlightActive = false

local function notify(description, kind)
    lib.notify({
        title = 'Flight Speed',
        description = description,
        type = kind or 'inform',
    })
end

local function refreshAccess(showDowngrade)
    local allowed, tier = lib.callback.await(
        'creatures:server:getFlightSpeedAccess',
        false
    )
    maximumLevel = tonumber(allowed) or 0
    currentTier = tonumber(tier) or 0

    if maximumLevel < 1 and mathStoreFlightActive then
        TriggerEvent('flight:deactivate')
    end
    if maximumLevel > 0 and selectedLevel > maximumLevel then
        selectedLevel = maximumLevel
        if mathStoreFlightActive and settings.levels and settings.levels[selectedLevel] then
            TriggerEvent('flight:activateWithPresetNoBucketCheck', settings.levels[selectedLevel])
        end
        if showDowngrade then
            notify(('Your race tier now allows flight speed %d.'):format(selectedLevel), 'warning')
        end
    end
end

local function setFlightSpeed(requestedLevel, silent, applyWhileFlying)
    refreshAccess(false)

    if maximumLevel < 1 then
        notify('Your race cannot use tiered flight speeds.', 'error')
        return false
    end

    requestedLevel = tonumber(requestedLevel)
    if not requestedLevel then
        requestedLevel = selectedLevel + 1
        if requestedLevel > maximumLevel then requestedLevel = 1 end
    end

    requestedLevel = math.floor(requestedLevel)
    if not settings.levels or not settings.levels[requestedLevel] then
        notify('Use /flightspeed 1, 2, or 3.', 'error')
        return false
    end

    if requestedLevel > maximumLevel then
        local requiredTier = settings.unlockTier and settings.unlockTier[requestedLevel] or '?'
        notify(('Speed %d unlocks at race tier %s. You are tier %d.'):format(
            requestedLevel,
            tostring(requiredTier),
            currentTier
        ), 'error')
        return false
    end

    selectedLevel = requestedLevel
    if not silent then
        notify(('Flight speed set to %d (maximum unlocked: %d).'):format(
            selectedLevel,
            maximumLevel
        ), 'success')
    end

    local mathStorePreset = settings.levels[selectedLevel]
    if mathStoreFlightActive and applyWhileFlying ~= false then
        TriggerEvent('flight:activateWithPresetNoBucketCheck', mathStorePreset)
    end

    return true, mathStorePreset
end

RegisterCommand(settings.command or 'flightspeed', function(_, args)
    setFlightSpeed(args[1])
end, false)

RegisterCommand('+creatures_cycle_flight_speed', function()
    setFlightSpeed(nil)
end, false)

RegisterCommand('-creatures_cycle_flight_speed', function()
end, false)

RegisterKeyMapping(
    '+creatures_cycle_flight_speed',
    'Cycle unlocked flight speed',
    'keyboard',
    settings.cycleKey or 'K'
)

AddEventHandler('flight:deactivate', function()
    mathStoreFlightActive = false
end)

CreateThread(function()
    Wait(1500)
    refreshAccess(false)

    while true do
        Wait(5000)
        refreshAccess(true)
    end
end)

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    CreateThread(function()
        Wait(1000)
        refreshAccess(false)
    end)
end)

-- These events are optional accelerators. Periodic metadata refresh keeps the
-- resource functional even if creatures no longer emits them.
RegisterNetEvent('creatures:client:setTier', function()
    CreateThread(function()
        Wait(250)
        refreshAccess(true)
    end)
end)

RegisterNetEvent('creatures:client:clearTier', function()
    CreateThread(function()
        Wait(250)
        refreshAccess(true)
    end)
end)

exports('GetSelectedFlightSpeed', function()
    local mathStorePreset = settings.levels and settings.levels[selectedLevel] or nil
    return selectedLevel, maximumLevel, mathStorePreset
end)

exports('SetFlightSpeed', function(requestedLevel, silent, applyWhileFlying)
    return setFlightSpeed(requestedLevel, silent == true, applyWhileFlying)
end)

-- Wing resources start flight through this export so vendor equip/open events
-- cannot make the controller believe flight is active. This guarantees one
-- MathStore activation event per command invocation.
exports('ActivateFlight', function(mathStorePreset)
    if Config.Wings.dampenerResource and GetResourceState(Config.Wings.dampenerResource) == 'started' and exports[Config.Wings.dampenerResource]:IsInsideAetherDampener() then
        notify('An Aether Dampener prevents flight here.', 'error')
        return false
    end
    if GetResourceState(Config.Wings.flightResource) ~= 'started' then
        notify('The configured flight resource is unavailable.', 'error')
        return false
    end
    if Config.Wings.noFlyResource and GetResourceState(Config.Wings.noFlyResource) == 'started'
        and not exports[Config.Wings.noFlyResource]:CanStartFlight() then return false end
    refreshAccess(false)
    mathStorePreset = tonumber(mathStorePreset)
    local permitted = false
    for level, preset in pairs(settings.levels) do
        if preset == mathStorePreset and level <= maximumLevel then permitted = true end
    end
    if not permitted then return false end

    TriggerEvent('flight:activateWithPresetNoBucketCheck', mathStorePreset)
    mathStoreFlightActive = true
    return true
end)

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() and mathStoreFlightActive then
        TriggerEvent('flight:deactivate')
    end
end)
RegisterNetEvent('QBCore:Client:OnPlayerUnload', function()
    if mathStoreFlightActive then TriggerEvent('flight:deactivate') end
    selectedLevel, maximumLevel, currentTier = 1, 0, 0
end)
