if not Config.Wings.kitsuneEnabled then return end

local settings = Config.KitsuneTails
local equipped
local busy = false
local generation = 0

local function notify(message)
    lib.notify({ title = 'Kitsune Tails', description = message, type = 'error' })
end

local function removeTails()
    generation = generation + 1
    equipped = nil
    if GetResourceState(settings.resource) == 'started' then
        TriggerEvent('mathstore:removeKitsune')
    end
end

local function getAccess()
    if GetResourceState('creatures') ~= 'started' then return 0 end
    return tonumber(lib.callback.await('creatures:server:getKitsuneTailAccess', false)) or 0
end

local function spawnTails(count, style)
    -- A one-tail-only style may not exist on the larger sets.
    style = math.min(style, settings.stylesByCount[count])
    TriggerEvent('creatures:client:clearKitsuneTails')
    equipped = { count = count, style = style }
    -- The vendor concatenates this prefix with '_' and the style index.
    TriggerEvent('mathstore:spawnKitsune', 'mtskt' .. count, style)
end

local function equipTails(requestedCount, style)
    if busy then return end
    if GetResourceState(settings.resource) ~= 'started' then
        notify('The kitsune tail resource is unavailable.')
        return
    end
    style = tonumber(style or 1)
    if not style or style ~= math.floor(style) or style < 1 then
        notify('Enter a valid whole-number tail style.')
        return
    end

    busy = true
    local requestGeneration = generation
    local ok, maximum = pcall(getAccess)
    busy = false
    if requestGeneration ~= generation then return end
    if not ok then
        notify('Unable to check your kitsune tier. Please try again.')
        return
    end
    if maximum < 1 then
        notify('Your race and tier do not allow kitsune tails.')
        return
    end
    local count = requestedCount or maximum
    if not settings.stylesByCount[count] or count > maximum then
        notify(('Your tier allows up to %d tails.'):format(maximum))
        return
    end
    if style > settings.stylesByCount[count] then
        notify(('Choose a style from 1 to %d.'):format(settings.stylesByCount[count]))
        return
    end
    if GetResourceState(settings.resource) ~= 'started' then return end
    spawnTails(count, style)
end

local function registerCommands()
    RegisterCommand(settings.command, function(_, args)
        equipTails(nil, args[1])
    end, false)
    for count in pairs(settings.stylesByCount) do
        local tailCount = count
        RegisterCommand('mtskit' .. tailCount, function(_, args)
            equipTails(tailCount, args[1])
        end, false)
    end
    RegisterCommand('rkits', removeTails, false)
end

-- The vendor registers unrestricted commands on startup. Re-register ours after
-- its scripts load, including when the vendor resource is restarted independently.
AddEventHandler('onClientResourceStart', function(resource)
    if resource ~= settings.resource and resource ~= GetCurrentResourceName() then return end
    CreateThread(function()
        Wait(0)
        registerCommands()
        -- Discard any vendor appearance surviving a controller restart.
        removeTails()
    end)
end)

AddEventHandler('mathstore:removeKitsune', function()
    generation = generation + 1
    equipped = nil
end)
AddEventHandler('mathstore:triggerLimpeza', function()
    generation = generation + 1
    equipped = nil
end)

local function refreshTails()
    if not equipped or busy then return end
    busy = true
    local previous = equipped
    local ok, maximum = pcall(getAccess)
    busy = false
    if equipped ~= previous then return end
    if not ok or maximum < 1 then
        removeTails()
    elseif previous.count > maximum then
        spawnTails(maximum, previous.style)
    end
end

CreateThread(function()
    while true do
        Wait(5000)
        refreshTails()
    end
end)

for _, event in ipairs({ 'creatures:client:setTier', 'creatures:client:clearTier' }) do
    RegisterNetEvent(event, function()
        CreateThread(function()
            Wait(250)
            refreshTails()
        end)
    end)
end
RegisterNetEvent('QBCore:Client:OnPlayerUnload', removeTails)
AddEventHandler('creatures:client:clearKitsuneTails', removeTails)
AddEventHandler('onClientResourceStop', function(resource)
    if resource == GetCurrentResourceName() or resource == 'creatures' then
        removeTails()
    elseif resource == settings.resource then
        generation = generation + 1
        equipped = nil
    end
end)
