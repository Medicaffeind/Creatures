if not Config.Wings.mothEnabled then return end

local equipped, flying, busy = false, false, false
local lastAnimation, startedAt, landedAt
local attachedWings = false
local shiftHeld = false
local equipGeneration = 0
local manualAnimationUntil = 0
local warnedAnimationFallback = false
-- Ped height measures the entity origin, not clearance under its feet.
-- Use separate enter/leave thresholds and debounce contact changes so normal
-- standing height or a one-frame contact glitch cannot flap the wing state.
local airborneState = false
local airborneCandidate, airborneCandidateAt
local function isMothAirborne(ped)
    if IsEntityDead(ped) or IsPedInAnyVehicle(ped, false) then
        airborneState, airborneCandidate, airborneCandidateAt = false, nil, nil
        return false
    end
    local height = GetEntityHeightAboveGround(ped)
    local threshold = airborneState and 1.15 or 1.5
    local candidate = IsEntityInAir(ped) or height > threshold
    if candidate == airborneState then
        airborneCandidate, airborneCandidateAt = nil, nil
    elseif candidate ~= airborneCandidate then
        airborneCandidate, airborneCandidateAt = candidate, GetGameTimer()
    elseif GetGameTimer() - airborneCandidateAt >= 250 then
        airborneState = candidate
        airborneCandidate, airborneCandidateAt = nil, nil
    end
    return airborneState
end

local flightAnimations = {
    { 'mathstoreupfly@animation', 'mathstoreupfly_clip' },
    { 'mathstoreloopfast_1@animation', 'mathstoreloopfast_1_clip' },
    { 'flyloopnew_1@animation', 'flyidlenew_1_clip' },
    { 'mtsflydescida@animation', 'mtsflydescida_clip' },
    { 'mtsflyup_1@animation', 'mtsflyup_1_clip' },
}
local function hasFlightAnimation(ped)
    for _, anim in ipairs(flightAnimations) do
        if IsEntityPlayingAnim(ped, anim[1], anim[2], 3) then return true end
    end
    return false
end
local observedFlight = false
local wingModels = {}
for _, suffix in ipairs({ '', '_blue', '_white', '_red', '_pink', '_green', '_grey', '_yellow' }) do
    wingModels[GetHashKey('wls_mothwing' .. suffix)] = true
end

-- A mapped key tracks Shift independently of the movement controls that
-- MathStore disables while flying. It does not change the flight engine speed.
RegisterCommand('+creatures_moth_boost_animation', function() shiftHeld = true end, false)
RegisterCommand('-creatures_moth_boost_animation', function() shiftHeld = false end, false)
RegisterKeyMapping('+creatures_moth_boost_animation', 'Moth wings: fast flight animation', 'keyboard', 'LSHIFT')

-- Observe the actual wing props so admin equips and resource restarts also
-- participate in animation sync without granting access to the flight command.
CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local previouslyAttached = attachedWings
        attachedWings = false
        if GetResourceState('wls_mothwings') == 'started' then
            for _, entity in ipairs(GetGamePool('CObject')) do
                if wingModels[GetEntityModel(entity)] and IsEntityAttachedToEntity(entity, ped) then
                    attachedWings = true
                    break
                end
            end
        end
        if attachedWings ~= previouslyAttached then lastAnimation = nil end
        Wait(500)
    end
end)

local function notify(message, kind)
    lib.notify({ title = 'Moth Wings', description = message, type = kind or 'error' })
end

local function sendAnimation(state)
    if GetResourceState('wls_mothwings') ~= 'started' then return false end
    local ok, handled = pcall(function()
        return exports.wls_mothwings:PlayBridgeAnimation(state)
    end)
    if ok and handled then return true end
    if not warnedAnimationFallback then
        warnedAnimationFallback = true
        print('[creatures] Native moth animation handler unavailable; using documented event. Restart wls_mothwings, then creatures.')
    end
    TriggerServerEvent('wls_mothwings:changeAnimation', state)
    return true
end

local function animate(state)
    if GetGameTimer() < manualAnimationUntil then return end
    if not (equipped or attachedWings) then return end
    -- Let the vendor finish/loop the current clip; only send state changes.
    if lastAnimation == state then return end
    if sendAnimation(state) then
        lastAnimation = state
    end
end

local function stopFlight()
    if flying then TriggerEvent('flight:deactivate') end
    flying, landedAt, observedFlight = false, nil, false
    manualAnimationUntil = 0
    lastAnimation = nil
end

RegisterNetEvent('creatures:client:mothAdminAnimation', function(state)
    if state == 'idle' or state == 'fly' or state == 'flyfast' then
        manualAnimationUntil = GetGameTimer() + 15000
        lastAnimation = nil
        sendAnimation(state)
        print(('[creatures] Manual moth animation: %s (automatic sync paused for 15 seconds).'):format(state))
    end
end)

AddEventHandler('flight:deactivate', function()
    flying, landedAt, observedFlight = false, nil, false
    manualAnimationUntil = 0
    lastAnimation = nil
end)

RegisterNetEvent('creatures:client:mothEquipped', function(value)
    equipGeneration = equipGeneration + 1
    if not value then stopFlight() end
    equipped = value == true
    lastAnimation = nil
    if equipped then
        local generation = equipGeneration
        SetTimeout(7000, function()
            if equipped and generation == equipGeneration and not attachedWings then
                notify('Moth wings did not appear. Check the server console for vendor errors.')
            end
        end)
    end
end)

RegisterCommand('moth', function(_, args)
    if busy then return end
    busy = true
    local color = (args[1] or 'default'):lower()
    local ok, allowed, reason = pcall(lib.callback.await,
        'creatures:server:mothEquip', false, color)
    busy = false
    if not ok then
        print(('[creatures] Moth equip request failed: %s'):format(tostring(allowed)))
        notify('Moth wing request failed. Check F8 for the error.')
    elseif not allowed then
        notify(reason or 'The server rejected the moth wing request.')

    end
end, false)

RegisterCommand('mothfly', function()
    if busy then return end
    if flying then
        local ped = PlayerPedId()
        if IsEntityInAir(ped) or hasFlightAnimation(ped) then
            stopFlight()
            return
        end
        -- The engine can land without sending flight:deactivate. Clear the
        -- stale flag, then start again with this same command invocation.
        stopFlight()
    end
    if not equipped then notify('Equip moth wings first with /moth [color].') return end
    if GetResourceState(Config.Wings.flightResource) ~= 'started' then
        notify('The flight resource is unavailable.') return
    end
    busy = true
    local ok, allowed = pcall(lib.callback.await, 'creatures:server:mothFlightAccess', false)
    busy = false
    if not ok or not allowed or not equipped then
        notify('Only tier 5 Fae with moth wings equipped can use this flight option.') return
    end
    if IsEntityDead(PlayerPedId()) or IsPedInAnyVehicle(PlayerPedId(), false) then return end
    if Config.Wings.noFlyResource and GetResourceState(Config.Wings.noFlyResource) == 'started'
        and not exports[Config.Wings.noFlyResource]:CanStartFlight() then return end
    local permitted, preset = exports.creatures:SetFlightSpeed(3, true, false)
    if not permitted or not equipped then return end
    manualAnimationUntil = 0
    lastAnimation = nil
    flying = exports.creatures:ActivateFlight(preset)
    startedAt, landedAt = GetGameTimer(), nil
end, false)

CreateThread(function()
    while true do
        Wait(250)
        if equipped then
            local ped = PlayerPedId()
            if IsEntityDead(ped) then
                stopFlight()
                equipped = false
                TriggerServerEvent('creatures:server:mothRemove')
            elseif flying then
                -- Hovering can stop the ped's movement animation without
                -- ending flight. Only start the landing timer on the ground.
                local airborne = isMothAirborne(ped)
                if airborne then
                    landedAt = nil
                else
                    if GetGameTimer() - startedAt > 1500 then
                        landedAt = landedAt or GetGameTimer()
                        if GetGameTimer() - landedAt >= 750 then stopFlight() end
                    end
                end
            end
        end
    end
end)

-- Animation follows the visible wings and airborne state, not which command
-- started flight. Never deactivate flight because a ped animation stops.
CreateThread(function()
    while true do
        Wait(0)
        if equipped or attachedWings then
            local ped = PlayerPedId()
            local airborne = isMothAirborne(ped)
            -- Merely standing at a height or holding Shift is not flight.
            -- Recognize other MathStore entry points by their flight pose,
            -- retaining that observation during an airborne hover.
            if hasFlightAnimation(ped) then observedFlight = true end
            if not airborne then observedFlight = false end
            local activeFlight = airborne and (flying or observedFlight)
            local boosting = shiftHeld or IsControlPressed(0, 21) or IsDisabledControlPressed(0, 21)
            animate(activeFlight and (boosting and 'flyfast' or 'fly') or 'idle')
        else
            lastAnimation = nil
        end
    end
end)

AddEventHandler('QBCore:Client:OnPlayerUnload', function()
    stopFlight()
    equipped = false
    attachedWings, shiftHeld = false, false
    TriggerServerEvent('creatures:server:mothRemove')
end)

AddEventHandler('onClientResourceStop', function(resource)
    if resource == GetCurrentResourceName() or resource == 'wls_mothwings'
        or resource == 'MathStoreFly' then
        stopFlight()
        equipped = false
        attachedWings, shiftHeld = false, false
    end
end)
