'use strict';

// Invisible NUI audio mixer. No focus capture, CDN, or external JS dependency.
const context = new AudioContext();
const sounds = new Map();
const clamp = (value, min, max) => Math.max(min, Math.min(max, Number(value) || 0));
const post = (name, body) => fetch(`https://${GetParentResourceName()}/${name}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
}).catch(() => {});

function stop(id) {
    const sound = sounds.get(id);
    if (!sound) return;
    sounds.delete(id);
    clearTimeout(sound.timer);
    sound.abort.abort();
    if (sound.source) {
        sound.source.onended = null;
        try { sound.source.stop(); } catch (_) { /* Already ended. */ }
        sound.source.disconnect();
    }
    sound.gain.disconnect();
    sound.pan.disconnect();
}

async function play(data) {
    stop(data.id);
    const gain = context.createGain();
    const pan = context.createStereoPanner();
    gain.gain.value = 0;
    gain.connect(pan).connect(context.destination);
    const sound = { gain, pan, abort: new AbortController(), source: null, timer: null };
    sounds.set(data.id, sound);
    sound.timer = setTimeout(() => stop(data.id), clamp(data.duration, 1000, 120000));
    try {
        await context.resume();
        const response = await fetch(data.url, { signal: sound.abort.signal });
        if (!response.ok) throw new Error(`Audio request returned HTTP ${response.status}`);
        const buffer = await context.decodeAudioData(await response.arrayBuffer());
        if (sounds.get(data.id) !== sound) return;
        const source = context.createBufferSource();
        sound.source = source;
        source.buffer = buffer;
        source.connect(gain);
        source.onended = () => { if (sounds.get(data.id) === sound) stop(data.id); };
        source.start();
    } catch (error) {
        if (sounds.get(data.id) !== sound) return;
        stop(data.id);
        if (error.name !== 'AbortError') post('audioError', { message: error.message });
    }
}

window.addEventListener('message', ({ data }) => {
    if (!data || typeof data.id !== 'string') return;
    if (data.action === 'play' && typeof data.url === 'string') void play(data);
    if (data.action === 'stop') stop(data.id);
    if (data.action === 'update') {
        const sound = sounds.get(data.id);
        if (!sound) return;
        sound.gain.gain.setTargetAtTime(clamp(data.volume, 0, 1), context.currentTime, 0.04);
        sound.pan.pan.setTargetAtTime(clamp(data.pan, -1, 1), context.currentTime, 0.04);
    }
});
window.addEventListener('unload', () => { for (const id of sounds.keys()) stop(id); });
post('ready', {});
