# Contributing

Keep changes focused and document player-facing behavior, configuration changes, and migration steps. Preserve the resource name and existing metadata keys unless a migration is provided.

Before proposing a change, run the checks in [docs/TESTING.md](docs/TESTING.md) and report any in-game testing separately. Add regression coverage for authorization, synchronization, or lifecycle changes. Keep optional resources optional and check their availability before calling exports.

Do not include paid models, proprietary vendor source, recordings without redistribution permission, credentials, logs containing player data, or database exports. This repository currently has no license file; clarify reuse/contribution terms with its owner before redistributing it.
