if not Config.Wings.enabled then return end

local function normalize(value)
    return type(value) == 'string' and value:lower() or ''
end

local function listContains(list, value)
    if type(list) ~= 'table' then return false end

    value = normalize(value)
    for i = 1, #list do
        if normalize(list[i]) == value then return true end
    end

    return false
end

local function getPlayerMetadata(source)
    local player = exports.qbx_core:GetPlayer(source)
    return player and (player.PlayerData.metadata or {}) or nil
end

local function hasRequiredRace(source, races)
    if type(races) ~= 'table' and type(races) ~= 'string' then return false end

    if exports.creatures:HasRequiredRace(source, races) == true then return true end

    -- HasRequiredRace is exact/case-sensitive. Normalize the exported race so
    -- configured male/female aliases are still recognized consistently.
    return listContains(races, exports.creatures:GetPlayerRace(source))
end

local function hasMinimumTier(source, tier, minimum)
    if exports.creatures:HasRequiredTier(source, { min = minimum }) == true then
        return true
    end

    -- creatures validates tiers against Config.Races[playerRace]. Male and
    -- female wing aliases may intentionally share a canonical race config, so
    -- use authoritative QBX metadata when that export cannot resolve an alias.
    return tier >= minimum
end

local function getMaximumLevel(source, tier)
    local maximum = 0

    for level, requiredTier in pairs(Config.FlightSpeeds.unlockTier or {}) do
        level = tonumber(level)
        requiredTier = tonumber(requiredTier)
        if level and requiredTier
            and hasMinimumTier(source, tier, requiredTier)
            and level > maximum
        then
            maximum = level
        end
    end

    return maximum
end

local function getFlightSpeedAccess(source)
    if not hasRequiredRace(source, Config.FlightSpeeds.races) then return 0, 0 end

    local metadata = getPlayerMetadata(source)
    if not metadata then return 0, 0 end

    local tier = tonumber(metadata.creatureTier) or 0
    return getMaximumLevel(source, tier), tier
end

local function canUseWingSet(source, wingSet)
    if type(wingSet) ~= 'string' then return false end

    return hasRequiredRace(source, Config.WingRaceAccess[wingSet])
end

lib.callback.register('creatures:server:getFlightSpeedAccess', getFlightSpeedAccess)
lib.callback.register('creatures:server:canUseWingSet', canUseWingSet)
