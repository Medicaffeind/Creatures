if not Config.Wings.mothEnabled then return end

local equipped = {}
local colors = {
    default = 'wls_mothwing', blue = 'wls_mothwing_blue',
    white = 'wls_mothwing_white', red = 'wls_mothwing_red',
    pink = 'wls_mothwing_pink', green = 'wls_mothwing_green',
    grey = 'wls_mothwing_grey', yellow = 'wls_mothwing_yellow',
}

local function hasAccess(playerId)
    local player = exports.qbx_core:GetPlayer(playerId)
    if not player then return false end
    local race = exports.creatures:GetPlayerRace(playerId)
    race = type(race) == 'string' and race:lower() or ''
    return (race == 'fae' or race == 'malefae' or race == 'femalefae')
        and tonumber((player.PlayerData.metadata or {}).creatureTier) == 5
end

local function remove(playerId)
    equipped[playerId] = nil
    if GetResourceState('wls_mothwings') == 'started' then
        exports.wls_mothwings:RemoveBridgeMoth(playerId)
    end
    TriggerClientEvent('creatures:client:mothEquipped', playerId, false)
end

lib.callback.register('creatures:server:mothEquip', function(source, color)
    if color == 'off' then
        remove(source)
        return true
    end
    if not hasAccess(source) then return false, 'Only tier 5 Fae can use moth wings.' end
    if GetResourceState('wls_mothwings') ~= 'started' then
        return false, 'The moth wing resource is unavailable.'
    end
    if type(color) ~= 'string' or not colors[color] then
        return false, 'Colors: default, blue, white, red, pink, green, grey, yellow.'
    end
    -- Invoke the vendor handler with the validated player's context.
    local removed, removeError = exports.wls_mothwings:RemoveBridgeMoth(source)
    if not removed then return false, removeError end
    local attached, attachError = exports.wls_mothwings:EquipTierFiveMoth(source, colors[color])
    if not attached then return false, attachError end
    equipped[source] = true
    TriggerClientEvent('creatures:client:mothEquipped', source, true)
    return true
end)

lib.callback.register('creatures:server:mothFlightAccess', function(source)
    return equipped[source] == true and hasAccess(source)
end)

RegisterNetEvent('creatures:server:mothRemove', function()
    if equipped[source] then remove(source) end
end)

AddEventHandler('playerDropped', function() equipped[source] = nil end)
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() and resource ~= 'wls_mothwings' then return end
    for playerId in pairs(equipped) do remove(playerId) end
end)

CreateThread(function()
    while true do
        Wait(5000)
        for playerId in pairs(equipped) do
            if not hasAccess(playerId) then remove(playerId) end
        end
    end
end)
