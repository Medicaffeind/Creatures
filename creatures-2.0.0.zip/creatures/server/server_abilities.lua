-- Validate network entry points before the legacy ability implementations.
local RegisterNetEvent = CreaturesRegisterAbilityEvent

-- Helper
local function GetPlayersInRadius(coords, radius)
    local players = {}

    for _, playerId in ipairs(GetPlayers()) do
        local targetId = tonumber(playerId)

        if targetId then
            local targetPed = GetPlayerPed(targetId)

            if targetPed ~= 0 then
                local targetCoords = GetEntityCoords(targetPed)
                local distance = #(coords - targetCoords)

                if distance <= radius then
                    players[#players + 1] = targetId
                end
            end
        end
    end

    return players
end

-- Demons
RegisterNetEvent(
    'creatures:setDemonVeil',
    function(enabled)

        local player =
            exports.qbx_core:GetPlayer(source)

        if not player then
            return
        end

        player.Functions.SetMetaData(
            'demonVeiled',
            enabled
        )
    end
)

RegisterNetEvent('creatures:suppressionEffect', function(targetId, demonCoords)

    local target = exports.qbx_core:GetPlayer(targetId)

    if not target then
        return
    end

    local race =
        target.PlayerData.metadata.creatureRace or 'human'

    if race == 'maledemon'
    or race == 'femaledemon' then
        return
    end

    TriggerClientEvent(
        'creatures:client:suppressionEffect',
        targetId,
        demonCoords
    )
end)

RegisterNetEvent('creatures:demonDisturb', function(targetId)

    local target = exports.qbx_core:GetPlayer(targetId)

    if not target then
        return
    end

    local race =
        target.PlayerData.metadata.creatureRace or 'human'

    -- Demons are immune
    if race == 'maledemon'
    or race == 'femaledemon' then
        return
    end

    local currentStress =
        target.PlayerData.metadata.stress or 0

    local newStress =
        math.min(100, currentStress + 2)

    target.Functions.SetMetaData(
        'stress',
        newStress
    )

    TriggerClientEvent(
        'hud:client:UpdateStress',
        targetId,
        newStress
    )
end)

-- Fae
RegisterNetEvent(
    'creatures_fae:mischief',
    function(model)

        TriggerClientEvent(
            'creatures_fae:mischief',
            -1,
            source,
            model
        )
    end
)

RegisterNetEvent(
    'creatures_fae:endMischief',
    function()

        TriggerClientEvent(
            'creatures_fae:endMischief',
            -1,
            source
        )
    end
)

RegisterNetEvent('creatures_fae:fairydust', function(targetId)

    local target = exports.qbx_core:GetPlayer(targetId)

    if not target then
        return
    end

    local race = target.PlayerData.metadata.creatureRace or 'human'

    if race == 'malefae'
    or race == 'femalefae' then
        return
    end

    TriggerClientEvent(
        'creatures_fae:client:fairydust',
        targetId
    )
end)

-- Witch/Warlock
RegisterNetEvent(
    'creatures:aetheriumBoltCast',
    function(startCoords, forward)

        local src = source

        TriggerClientEvent(
            'creatures:client:aetheriumBoltCast',
            -1,
            startCoords,
            forward
        )

        CreateThread(function()

            local currentPos = startCoords

            for _ = 1, 40 do

                Wait(25)

                currentPos =
                    currentPos + (forward * 1.5)

                for _, playerId in pairs(GetPlayers()) do

                    playerId =
                        tonumber(playerId)

                    if playerId ~= src then

                        local targetPed =
                            GetPlayerPed(playerId)

                        if DoesEntityExist(targetPed) then

                            local targetCoords =
                                GetEntityCoords(targetPed)

                            local dist =
                                #(currentPos - targetCoords)

                            if dist <= 1.5 then

                                TriggerClientEvent(
                                    'creatures:client:aetheriumBoltHit',
                                    -1,
                                    playerId
                                )

                                return
                            end
                        end
                    end
                end
            end
        end)
    end
)

RegisterNetEvent(
    'creatures:concussiveBlastHit',
    function(targetId, direction)

        local src = source

        local casterPed = GetPlayerPed(src)
        local targetPed = GetPlayerPed(targetId)

        if not DoesEntityExist(casterPed)
        or not DoesEntityExist(targetPed) then
            return
        end

        local casterCoords = GetEntityCoords(casterPed)
        local targetCoords = GetEntityCoords(targetPed)

        local distance =
            #(casterCoords - targetCoords)

        if distance > 8.0 then
            return
        end

        TriggerClientEvent(
            'creatures:client:concussiveBlastHit',
            targetId,
            direction
        )
    end
)

-- Dragonkin
RegisterNetEvent(
    'creatures:dragonFireBreath',
    function(origin, forward)

        local src = source

        local casterPed = GetPlayerPed(src)

        if not DoesEntityExist(casterPed) then
            return
        end

        -- Fire breath visual for everyone
        TriggerClientEvent(
            'creatures:client:dragonFireBreathFX',
            -1,
            src
        )

        for _, targetId in pairs(GetPlayers()) do

            targetId = tonumber(targetId)

            if targetId ~= src then

                local targetPed =
                    GetPlayerPed(targetId)

                if DoesEntityExist(targetPed) then

                    local targetCoords =
                        GetEntityCoords(targetPed)

                    local direction =
                        targetCoords - origin

                    local distance =
                        #direction

                    if distance <= 6.0 then

                        direction =
                            direction / distance

                        local dot =
                            forward.x * direction.x +
                            forward.y * direction.y +
                            forward.z * direction.z

                        -- Very tight stream
                        if dot >= 0.96 then
                        
                            TriggerClientEvent(
                                'creatures:client:dragonFireHit',
                                targetId
                            )
                        end
                    end
                end
            end
        end
    end
)

RegisterNetEvent(
    'creatures:dragonGustHit',
    function(targetId, direction)

        local src = source

        local casterPed = GetPlayerPed(src)
        local targetPed = GetPlayerPed(targetId)

        if not DoesEntityExist(casterPed)
        or not DoesEntityExist(targetPed) then
            return
        end

        local casterCoords = GetEntityCoords(casterPed)
        local targetCoords = GetEntityCoords(targetPed)

        local distance =
            #(casterCoords - targetCoords)

        if distance > 8.0 then
            return
        end

        TriggerClientEvent(
            'creatures:client:dragonGustHit',
            targetId,
            direction
        )
    end
)
-- Elf
RegisterNetEvent(
    'creatures:healingRain',
    function(coords)

        TriggerClientEvent(
            'creatures:client:healingRain',
            -1,
            coords
        )

        for i = 1, 15 do

            Wait(1000)

            for _, id in pairs(GetPlayers()) do

                local ped =
                    GetPlayerPed(id)

                if #(GetEntityCoords(ped) - coords) <= 10.0 then

                    TriggerClientEvent(
                        'creatures:client:healRainTick',
                        id
                    )
                end
            end
        end
    end
)

RegisterNetEvent(
    'creatures:rootTarget',
    function(targetId)

        local src = source

        local casterPed =
            GetPlayerPed(src)

        local targetPed =
            GetPlayerPed(targetId)

        if not DoesEntityExist(casterPed)
        or not DoesEntityExist(targetPed) then
            return
        end

        local casterCoords =
            GetEntityCoords(casterPed)

        local targetCoords =
            GetEntityCoords(targetPed)

        local distance =
            #(casterCoords - targetCoords)

        -- Root range
        if distance > 10.0 then
            return
        end

        TriggerClientEvent(
            'creatures:client:rootTarget',
            targetId
        )
    end
)

-- Usar
RegisterNetEvent(
    'creatures:maulTarget',
    function(targetId)

        local src = source

        local casterPed =
            GetPlayerPed(src)

        local targetPed =
            GetPlayerPed(targetId)

        if not DoesEntityExist(casterPed)
        or not DoesEntityExist(targetPed) then
            return
        end

        local distance =
            #(GetEntityCoords(casterPed) -
            GetEntityCoords(targetPed))

        if distance > 3.0 then
            return
        end

        TriggerClientEvent(
            'creatures:client:maulHit',
            targetId
        )
    end
)

RegisterNetEvent(
    'creatures:ursarRoar',
    function(origin)

        local src = source

        local casterPed =
            GetPlayerPed(src)

        if not DoesEntityExist(casterPed) then
            return
        end

        for _, targetId in pairs(GetPlayers()) do

            targetId =
                tonumber(targetId)

            if targetId ~= src then

                local targetPed =
                    GetPlayerPed(targetId)

                if DoesEntityExist(targetPed) then

                    local targetCoords =
                        GetEntityCoords(targetPed)

                    local direction =
                        targetCoords - origin

                    local distance =
                        #direction

                    if distance <= 12.0 then

                        direction =
                            direction / distance

                        TriggerClientEvent(
                            'creatures:client:ursarRoarHit',
                            targetId,
                            direction
                        )
                    end
                end
            end
        end
    end
)

-- Mermaids

-- Qbox is accessed directly; no QB-Core compatibility bridge is needed.

local HYDRO_COOLDOWN = 12000
local HYDRO_DAMAGE = 20
local HYDRO_RANGE = 50.0
local HYDRO_RADIUS = 0.75

local lastHydroSpear = {}

local function NormalizeVector(direction)

    local length = math.sqrt(
        direction.x * direction.x +
        direction.y * direction.y +
        direction.z * direction.z
    )

    if length <= 0.001 then
        return nil
    end

    return vector3(
        direction.x / length,
        direction.y / length,
        direction.z / length
    )
end


local function GetClosestPlayerOnPath(
    source,
    origin,
    direction
)

    local closestPlayer = nil
    local closestDistance = HYDRO_RANGE

    for _, playerId in ipairs(GetPlayers()) do

        local target = tonumber(playerId)

        if target and target ~= source then

            local targetPed = GetPlayerPed(target)

            if targetPed ~= 0 then

                local targetCoords =
                    GetEntityCoords(targetPed)

                local relative =
                    targetCoords - origin

                local forwardDistance =
                    relative.x * direction.x +
                    relative.y * direction.y +
                    relative.z * direction.z

                if forwardDistance >= 0.0
                and forwardDistance <= HYDRO_RANGE then

                    local closestPoint =
                        origin +
                        direction * forwardDistance

                    local distance =
                        #(targetCoords - closestPoint)

                    if distance <= HYDRO_RADIUS
                    and forwardDistance < closestDistance then

                        closestDistance = forwardDistance
                        closestPlayer = target

                    end
                end
            end
        end
    end

    return closestPlayer
end


RegisterNetEvent(
    'creatures:hydroSpear',
    function(clientOrigin, clientDirection)

        local source = source

        -- Race check
        if not exports.creatures:HasRequiredRace(source, 'mermaid') then

            if Config.Debug then
                print(
                    ('[Creatures Mermaid] %s attempted Hydro Spear without Mermaid race.')
                    :format(source)
                )
            end

            return
        end

        -- Cooldown check
        local now = GetGameTimer()

        if lastHydroSpear[source] then

            local elapsed = now - lastHydroSpear[source]

            if elapsed < HYDRO_COOLDOWN then

                if Config.Debug then
                    print(
                        ('[Creatures Mermaid] Hydro Spear cooldown blocked for %s.')
                        :format(source)
                    )
                end

                return
            end
        end

        -- Validate direction
        if type(clientDirection) ~= 'vector3' then

            if Config.Debug then
                print('[Creatures Mermaid] Invalid Hydro Spear direction.')
            end

            return
        end

        local direction = NormalizeVector(clientDirection)

        if not direction then

            if Config.Debug then
                print('[Creatures Mermaid] Failed to normalize Hydro Spear direction.')
            end

            return
        end

        -- Get caster ped
        local sourcePed = GetPlayerPed(source)

        if sourcePed == 0 then
            return
        end

        local playerCoords = GetEntityCoords(sourcePed)

        -- Starting point of the water spear
        local origin =
            playerCoords +
            vector3(0.0, 0.0, 0.8)

        -- Consume cooldown
        lastHydroSpear[source] = now

        -- Find player hit by the spear
        local target =
            GetClosestPlayerOnPath(
                source,
                origin,
                direction
            )

        -- Everyone sees the Hydro Spear effect
        TriggerClientEvent(
            'creatures:client:hydroSpearFX',
            -1,
            source,
            origin,
            direction,
            HYDRO_RANGE
        )

        -- Nothing hit
        if not target then

            if Config.Debug then
                print(
                    ('[Creatures Mermaid] Hydro Spear fired by %s but hit nothing.')
                    :format(source)
                )
            end

            return
        end

        local targetPed = GetPlayerPed(target)

        if targetPed == 0 then
            return
        end

        local damage = HYDRO_DAMAGE

        -- Send damage AND knockback direction to victim
        TriggerClientEvent(
            'creatures:client:hydroSpearHit',
            target,
            damage,
            direction
        )

        if Config.Debug then

            print(
                ('[Creatures Mermaid] Hydro Spear | %s -> %s | Damage: %s')
                :format(
                    source,
                    target,
                    damage
                )
            )

            print(
                ('[Creatures Mermaid] Hydro Spear knockback direction: %.2f, %.2f, %.2f')
                :format(
                    direction.x,
                    direction.y,
                    direction.z
                )
            )
        end
    end
)


AddEventHandler(
    'playerDropped',
    function()

        lastHydroSpear[source] = nil

    end
)

-- Werewolf

local HOWL_COOLDOWN = 30000
local REND_COOLDOWN = 15000
local BREACH_COOLDOWN = 60000

local lastHowl = {}
local lastRend = {}
local lastBreach = {}

local function IsWerewolf(source)

    return exports.creatures:HasRequiredRace(
        source,
        {
            "malewerewolf",
            "femalewerewolf"
        }
    )

end

RegisterNetEvent(
    "creatures:werewolfHowl",
    function()

        local source = source

        if not IsWerewolf(source) then
            return
        end

        local now = GetGameTimer()

        if lastHowl[source] then

            if now - lastHowl[source] < HOWL_COOLDOWN then
                return
            end

        end

        lastHowl[source] = now

        local Player = exports.qbx_core:GetPlayer(source)
        
        if not Player then 
            return
        end

        local tier = tonumber(Player.PlayerData.metadata.creatureTier) or 0

        local multiplier = 1.20
        local duration = 10000

        if tier >= 2 then
            multiplier = 1.25
            duration = 12000
        end

        if tier >= 4 then
            multiplier = 1.30
            duration = 15000
        end

        if tier >= 5 then
            multiplier = 1.35
            duration = 18000
        end

        TriggerClientEvent(
            "creatures:client:werewolfHowl",
            source,
            duration,
            multiplier
        )

        TriggerClientEvent(
            "creatures:client:werewolfHowlFX",
            -1,
            source
        )

    end
)

RegisterNetEvent(
    "creatures:werewolfRend",
    function(target)
        
        local source = source

        if not IsWerewolf(source) then
            return
        end

        target = tonumber(target)

        if not target then
            return
        end

        if not GetPlayerName(target) then
            return
        end

        local now = GetGameTimer()

        if lastRend[source] then

            if now - lastRend[source] < REND_COOLDOWN then
                return
            end

        end

        local sourcePed = GetPlayerPed(source)
        local targetPed = GetPlayerPed(target)

        if sourcePed == 0 or targetPed == 0 then
            return
        end

        local sourceCoords = GetEntityCoords(sourcePed)
        local targetCoords = GetEntityCoords(targetPed)

        local distance = #(sourceCoords - targetCoords)

        if distance > 3.5 then
            return
        end

        lastRend[source] = now

        local Player = exports.qbx_core:GetPlayer(source)
        
        if not Player then 
            return
        end

        local tier = tonumber(Player.PlayerData.metadata.creatureTier) or 0

        local damage = 20

        if tier >= 2 then
            damage = 25
        end

        if tier >= 4 then
            damage = 30
        end

        if tier >= 5 then
            damage = 35
        end

        local direction = targetCoords - sourceCoords

        local length = math.sqrt(
            direction.x * direction.x +
            direction.y * direction.y +
            direction.z * direction.z
        )

        if length > 0 then

            direction = vector3(
                direction.x / length,
                direction.y / length,
                direction.z / length
            )

        else

            direction = vector3(
                0.0,
                0.0,
                0.0
            )

        end

        TriggerClientEvent(
            "creatures:client:feralRendHit",
            target,
            damage,
            direction
        )

    end
)

RegisterNetEvent(
    "creatures:werewolfBreachDoor",
    function(door, doorCoords)

        local source = source

        if not IsWerewolf(source) then
            return
        end

        if not GlobalState.bloodMoon then
            return
        end

        local Player = exports.qbx_core:GetPlayer(source)

        if not Player then
            return
        end

        local tier =
            tonumber(
                Player.PlayerData.metadata.creatureTier
            ) or 0

        if tier < 4 then
            return
        end

        local now = GetGameTimer()

        if lastBreach[source] then

            if now - lastBreach[source] < BREACH_COOLDOWN then
                return
            end

        end

        local sourcePed = GetPlayerPed(source)

        if sourcePed == 0 then
            return
        end

        local sourceCoords =
            GetEntityCoords(sourcePed)

        if type(doorCoords) ~= "vector3" then
            return
        end

        local distance =
            #(sourceCoords - doorCoords)

        if distance > 3.5 then
            return
        end

        lastBreach[source] = now

        TriggerEvent(
            "creatures:server:breachDoor",
            source,
            door
        )

    end
)

AddEventHandler(
    "playerDropped",
    function()

        local source = source

        lastHowl[source] = nil
        lastRend[source] = nil
        lastBreach[source] = nil

    end
)
-- Toughness exports live in server_main.lua.

-- Angel

RegisterNetEvent('creatures:angelDestress', function(targetId)

    local angel = exports.qbx_core:GetPlayer(source)

    if not angel then
        return
    end

    local race =
        angel.PlayerData.metadata.creatureRace or 'human'

    if race ~= 'angel' then
        return
    end

    local target = exports.qbx_core:GetPlayer(targetId)

    if not target then
        return
    end

    local currentStress =
        target.PlayerData.metadata.stress or 0

    local newStress =
        math.max(0, currentStress - 2)

    target.Functions.SetMetaData(
        'stress',
        newStress
    )

    TriggerClientEvent(
        'hud:client:UpdateStress',
        targetId,
        newStress
    )
end)

RegisterNetEvent(
    'creatures:server:angelSanctuary',
    function()

        local src = source

        local player =
            exports.qbx_core:GetPlayer(src)

        if not player then
            return
        end

        local race =
            exports.qbx_core:GetMetadata(
                src,
                'creatureRace'
            )

        if not race then
            race = 'human'
        end

        if race ~= 'angel' then
            return
        end

        local config =
            Config.Races.angel.Sanctuary

        if not config then
            print(
                '[Creatures] ERROR: Angel Sanctuary config missing.'
            )
            return
        end

        local aetherCost =
            tonumber(config.AetherCost) or 25

        local duration =
            tonumber(config.Duration) or 15

        local radius =
            tonumber(config.Radius) or 15.0

        local rawAether =
            exports.qbx_core:GetMetadata(
                src,
                'aetherium'
            )

        local currentAether

        if rawAether ~= nil then
            currentAether = tonumber(rawAether)
        end

        if currentAether == nil then
            currentAether = 100

            exports.qbx_core:SetMetadata(
                src,
                'aetherium',
                currentAether
            )
        end

        if currentAether < aetherCost then

            TriggerClientEvent(
                'ox_lib:notify',
                src,
                {
                    title = 'Sanctuary',
                    description = 'You do not have enough Aetherium.',
                    type = 'error'
                }
            )

            return
        end

        local newAether =
            currentAether - aetherCost

        exports.qbx_core:SetMetadata(
            src,
            'aetherium',
            newAether
        )

        TriggerClientEvent(
            'creatures:client:set',
            src,
            newAether
        )

        local ped =
            GetPlayerPed(src)

        if ped == 0 then
            return
        end

        local coords =
            GetEntityCoords(ped)

        local affectedPlayers = GetPlayersInRadius(coords, radius)

        for _, targetId in ipairs(affectedPlayers) do
            TriggerClientEvent(
                'creatures:client:angelSanctuary',
                targetId,
                coords,
                duration,
                radius
            )
        end
    end
)

RegisterNetEvent('creatures:server:angelDivineSmite', function(coords)
    local src = source

    local Player = exports.qbx_core:GetPlayer(src)
    if not Player then return end

    local race =
        exports.qbx_core:GetMetadata(
            src,
            'creatureRace'
        )

    if race ~= 'angel' then
        return
    end

    local tier =
        tonumber(
            exports.qbx_core:GetMetadata(
                src,
                'creatureTier'
            )
        ) or 0

    if tier < 4 then
        TriggerClientEvent(
            'ox_lib:notify',
            src,
            {
                title = 'Divine Smite',
                description = 'You are not strong enough to use this ability yet.',
                type = 'error'
            }
        )
        return
    end

    local config = Config.Races.angel.DivineSmite

    local aether =
        tonumber(
            exports.qbx_core:GetMetadata(
                src,
                'aetherium'
            )
        ) or 0

    if aether < config.AetherCost then
        TriggerClientEvent(
            'ox_lib:notify',
            src,
            {
                title = 'Divine Smite',
                description = 'You do not have enough Aetherium.',
                type = 'error'
            }
        )
        return
    end

    aether = aether - config.AetherCost

    exports.qbx_core:SetMetadata(
        src,
        'aetherium',
        aether
    )

    TriggerClientEvent(
        'creatures:client:set',
        src,
        aether
    )

    local duration =
        tonumber(config.Duration) or 6

    local radius =
        tonumber(config.Radius) or 2.0

    local effectRadius =
        tonumber(config.EffectRadius) or 15.0

    local tickInterval =
        tonumber(config.TickInterval) or 1000

    -- Broadcast the visual effect to everyone.
    TriggerClientEvent(
        'creatures:client:angelDivineSmite',
        -1,
        coords,
        duration,
        radius
    )

    -- Only players within EffectRadius hear/feel the impact.
    local nearbyPlayers =
        GetPlayersInRadius(
            coords,
            effectRadius
        )

    for _, targetId in ipairs(nearbyPlayers) do
        TriggerClientEvent(
            'creatures:client:angelDivineSmiteImpact',
            targetId
        )
    end

    local damageTable = {
        25,
        25,
        35,
        50,
        75,
        100
    }

    local startTime = GetGameTimer()

    while GetGameTimer() - startTime < (duration * 1000) do

        local elapsed =
            GetGameTimer() - startTime

        local damageIndex =
            math.floor(
                elapsed / tickInterval
            ) + 1

        if damageIndex > #damageTable then
            damageIndex = #damageTable
        end

        local damage =
            damageTable[damageIndex] or 0

        for _, targetId in ipairs(GetPlayers()) do
            local targetIdNumber =
                tonumber(targetId)

            if targetIdNumber then

                local target =
                    exports.qbx_core:GetPlayer(
                        targetIdNumber
                    )

                if target then

                    local targetRace =
                        exports.qbx_core:GetMetadata(
                            targetIdNumber,
                            'creatureRace'
                        )

                    if not targetRace then
                        targetRace = 'human'
                    end

                    -- Angels are immune to Divine Smite.
                    if targetRace ~= 'angel' then

                        local targetPed =
                            GetPlayerPed(
                                targetIdNumber
                            )

                        if targetPed ~= 0 then

                            local targetCoords =
                                GetEntityCoords(
                                    targetPed
                                )

                            local distance =
                                #(coords - targetCoords)

                            if distance <= radius then

                                TriggerClientEvent(
                                    'creatures:client:angelSmiteDamage',
                                    targetIdNumber,
                                    damage,
                                    src
                                )

                            end
                        end
                    end
                end
            end
        end

        Wait(tickInterval)
    end
end)

RegisterNetEvent(
    'creatures:server:angelDivineTouch',
    function()

        local src = source

        local player =
            exports.qbx_core:GetPlayer(src)

        if not player then
            return
        end

        local race =
            player.PlayerData.metadata.creatureRace or 'human'

        if race ~= 'angel' then
            return
        end

        local tier =
            tonumber(player.PlayerData.metadata.creatureTier) or 0

        if tier < 0 then
            tier = 0
        end

        if tier > 5 then
            tier = 5
        end

        local divinetouchConfig =
            Config.Races.angel.DivineTouch

        local tierData =
            divinetouchConfig[tier]

        if not tierData then
            return
        end

        local currentAether =
            tonumber(
                exports.qbx_core:GetMetadata(
                    src,
                    'aetherium'
                )
            )

        if currentAether == nil then
            currentAether = 100

            exports.qbx_core:SetMetadata(
                src,
                'aetherium',
                currentAether
            )
        end

        if currentAether < tierData.AetherCost then

            TriggerClientEvent(
                'ox_lib:notify',
                src,
                {
                    title = 'Divine Touch',
                    description = 'You do not have enough Aetherium.',
                    type = 'error'
                }
            )

            return
        end

        local casterPed =
            GetPlayerPed(src)

        if casterPed == 0 then
            return
        end

        local casterCoords =
            GetEntityCoords(casterPed)

        local nearbyPlayers = {}

        for _, playerId in ipairs(GetPlayers()) do

            local targetId =
                tonumber(playerId)

            if targetId and targetId ~= src then

                local targetPed =
                    GetPlayerPed(targetId)

                if targetPed ~= 0 then

                    local targetCoords =
                        GetEntityCoords(targetPed)

                    local distance =
                        #(casterCoords - targetCoords)

                    if distance <= 1.0 then

                        nearbyPlayers[#nearbyPlayers + 1] =
                            targetId

                    end
                end
            end
        end

        if #nearbyPlayers == 0 then

            TriggerClientEvent(
                'ox_lib:notify',
                src,
                {
                    title = 'Divine Touch',
                    description = 'There is no player close enough to heal.',
                    type = 'error'
                }
            )

            return
        end

        local targetId =
            nearbyPlayers[
                math.random(
                    1,
                    #nearbyPlayers
                )
            ]

        local targetPlayer =
            exports.qbx_core:GetPlayer(targetId)

        if not targetPlayer then
            return
        end

        local options = {}

        if tierData.FullHeal then

            options = {
                health = 200,

                injuries = {
                    {
                        type = 'all',
                        limb = 'all'
                    }
                },

                limbHealth = 100
            }

        elseif tierData.RandomInjury then

            local injuryTotals =
                exports['wasabi_ambulance_v2']
                    :getPlayerInjuryTotals(targetId)

            if not injuryTotals then

                TriggerClientEvent(
                    'ox_lib:notify',
                    src,
                    {
                        title = 'Divine Touch',
                        description = 'The chosen player could not be healed.',
                        type = 'error'
                    }
                )

                return
            end

            local availableInjuries = {}

            for _, injuryType in ipairs({
                'cut',
                'brokenbone',
                'blunt',
                'gunshot',
                'fist',
                'taser',
                'burn'
            }) do

                local count =
                    tonumber(
                        injuryTotals[injuryType]
                    ) or 0

                if count > 0 then

                    availableInjuries[#availableInjuries + 1] =
                        injuryType

                end
            end

            if #availableInjuries == 0 then

                TriggerClientEvent(
                    'ox_lib:notify',
                    src,
                    {
                        title = 'Divine Touch',
                        description = 'The chosen player has no injuries that need healing.',
                        type = 'inform'
                    }
                )

                return
            end

            local injuryType =
                availableInjuries[
                    math.random(
                        1,
                        #availableInjuries
                    )
                ]

            local limbs =
                tierData.Limbs

            local randomLimb =
                limbs[
                    math.random(
                        1,
                        #limbs
                    )
                ]

            options = {
                injuries = {
                    {
                        type = injuryType,
                        limb = randomLimb
                    }
                }
            }

        else

            local injuries = {}

            for _, injuryType in ipairs(
                tierData.Injuries or {}
            ) do

                injuries[#injuries + 1] = {
                    type = injuryType,
                    limb = 'all'
                }

            end

            options.injuries = injuries

            if tierData.LimbHealth then

                options.limbHealth =
                    tierData.LimbHealth

            end
        end

        local success, error =
            exports['wasabi_ambulance_v2']:ApplyHeal(
                targetId,
                options
            )

        if not success then

            print(
                ('[Creatures] Divine Touch failed for %s on target %s: %s')
                    :format(
                        src,
                        targetId,
                        tostring(error)
                    )
            )

            TriggerClientEvent(
                'ox_lib:notify',
                src,
                {
                    title = 'Divine Touch',
                    description = 'The divine healing failed.',
                    type = 'error'
                }
            )

            return
        end

        local newAether =
            currentAether - tierData.AetherCost

        player.Functions.SetMetaData(
            'aetherium',
            newAether
        )

        TriggerClientEvent(
            'creatures:client:set',
            src,
            newAether
        )

        TriggerClientEvent(
            'ox_lib:notify',
            src,
            {
                title = 'Divine Touch',
                description =
                    ('You have healed a nearby player. Aetherium: %s')
                    :format(newAether),
                type = 'success'
            }
        )

        TriggerClientEvent(
            'ox_lib:notify',
            targetId,
            {
                title = 'Divine Touch',
                description = 'Divine forces have healed you.',
                type = 'success'
            }
        )
    end
)


-- Kitsune abilities

local requestTimes = {}
local activeFoxFires = {}
local nextOrbId = 0

local function Notify(source, title, description, notificationType)
    TriggerClientEvent('ox_lib:notify', source, {
        title = title,
        description = description,
        type = notificationType or 'error'
    })
end

local function GetKitsuneConfig(source, abilityName)
    local Player = exports.qbx_core:GetPlayer(source)
    if not Player then return nil end

    local metadata = Player.PlayerData.metadata or {}

    if metadata.creatureRace ~= 'kitsune' then
        return nil
    end

    local raceConfig = Config.Races.kitsune
    if not raceConfig then return nil end

    local config = raceConfig[abilityName]
    if not config then return nil end

    local cost = tonumber(config.AetherCost)
    if not cost or cost < 0 then return nil end

    local ped = GetPlayerPed(source)
    if not ped or ped == 0 then return nil end

    return config, cost, ped
end

local function TryUseAetherium(source, cost)
    local current = tonumber(
        exports.creatures:GetPlayerAetherium(source)
    )

    if not current or current < cost then
        Notify(
            source,
            'Aetherium',
            'You do not have enough Aetherium.',
            'error'
        )
        return false
    end

    return exports.creatures:SetPlayerAetherium(
        source,
        current - cost
    ) == true
end

local function AllowRequest(source, abilityName)
    local now = GetGameTimer()

    requestTimes[source] = requestTimes[source] or {}

    local previous = requestTimes[source][abilityName] or -1000

    -- Anti-spam protection, not an ability cooldown.
    if now - previous < 100 then
        return false
    end

    requestTimes[source][abilityName] = now

    return true
end

local function BroadcastNearby(coords, radius, eventName, ...)
    local args = { ... }

    for _, playerId in ipairs(GetPlayers()) do
        local targetId = tonumber(playerId)

        if targetId then
            local ped = GetPlayerPed(targetId)

            if ped and ped ~= 0 then
                local targetCoords = GetEntityCoords(ped)

                if #(targetCoords - coords) <= radius then
                    TriggerClientEvent(
                        eventName,
                        targetId,
                        table.unpack(args)
                    )
                end
            end
        end
    end
end

-- Kitsune Dash

RegisterNetEvent('creatures:server:kitsuneDash', function()
    local src = source

    if not AllowRequest(src, 'Dash') then
        return
    end

    local config, cost, ped = GetKitsuneConfig(src, 'Dash')
    if not config then
        return
    end

    if not TryUseAetherium(src, cost) then
        return
    end

    local coords = GetEntityCoords(ped)
    local radius = tonumber(config.EffectRadius) or 100.0

    -- Apply the dash movement and start the trail for nearby players.
    TriggerClientEvent(
        'creatures:client:kitsuneDash',
        src,
        config
    )

    BroadcastNearby(
        coords,
        radius,
        'creatures:client:kitsuneDashFX',
        src,
        config
    )
end)

RegisterNetEvent('creatures:server:kitsuneDashTrail', function(points)
    local src = source

    if type(points) ~= 'table' or #points > 30 then
        return
    end

    local Player = exports.qbx_core:GetPlayer(src)
    if not Player then return end

    if (Player.PlayerData.metadata or {}).creatureRace ~= 'kitsune' then
        return
    end

    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return end

    local playerCoords = GetEntityCoords(ped)
    local validated = {}

    for _, point in ipairs(points) do
        if type(point) == 'table'
            and type(point.x) == 'number'
            and type(point.y) == 'number'
            and type(point.z) == 'number' then

            local coords = vector3(point.x, point.y, point.z)

            if #(coords - playerCoords) <= 100.0 then
                validated[#validated + 1] = {
                    x = point.x,
                    y = point.y,
                    z = point.z
                }
            end
        end
    end

    if #validated == 0 then return end

    BroadcastNearby(
        playerCoords,
        tonumber(Config.Races.kitsune.Dash.EffectRadius) or 100.0,
        'creatures:client:kitsuneDashTrailFX',
        validated
    )
end)


-- Kitsune Fox Fire
RegisterNetEvent('creatures:server:kitsuneFoxFire', function()
    local src = source

    if not AllowRequest(src, 'FoxFire') then return end

    local config, cost, ped = GetKitsuneConfig(src, 'FoxFire')
    if not config then return end

    local maxOrbs = tonumber(config.MaxOrbs) or 0
    local playerOrbs = activeFoxFires[src] or {}

    if maxOrbs > 0 then
        local count = 0

        for _ in pairs(playerOrbs) do
            count = count + 1
        end

        if count >= maxOrbs then
            Notify(
                src,
                'Fox Fire',
                'You have reached the maximum number of active wisps.',
                'error'
            )
            return
        end
    end

    if not TryUseAetherium(src, cost) then return end

    nextOrbId = nextOrbId + 1

    local orbId = nextOrbId
    local duration = math.max(
        0,
        tonumber(config.DisperseTime) or 10
    )

    activeFoxFires[src] = playerOrbs
    playerOrbs[orbId] = true

    local coords = GetEntityCoords(ped)
    local radius = tonumber(config.EffectRadius) or 100.0

    -- Send the caster's server ID. Clients use it to locate the ped
    -- and calculate the fixed orb position when the event arrives.
    BroadcastNearby(
        coords,
        radius,
        'creatures:client:kitsuneFoxFireFX',
        src,
        config
    )

    SetTimeout(duration * 1000, function()
        local orbs = activeFoxFires[src]

        if orbs then
            orbs[orbId] = nil

            if not next(orbs) then
                activeFoxFires[src] = nil
            end
        end
    end)
end)

AddEventHandler('playerDropped', function()
    local src = source

    requestTimes[src] = nil
    activeFoxFires[src] = nil
end)

-- Bossmob & Standardmob

RegisterNetEvent('creatures:server:selfMend', function()
    local src = source

    local player = exports.qbx_core:GetPlayer(src)
    if not player then return end

    local metadata = player.PlayerData.metadata or {}
    local race = metadata.creatureRace

    -- Only standardmob and bossmob can use Self Mend.
    if race ~= 'standardmob' and race ~= 'bossmob' then
        return
    end

    -- No tier requirement.
    local raceConfig = Config.Races[race]
    local selfMendConfig = raceConfig and raceConfig.SelfMend

    if not selfMendConfig then
        print(('[Creatures] Missing SelfMend config for %s')
            :format(race))
        return
    end

    local cost = tonumber(selfMendConfig.AetherCost)
    if not cost or cost < 0 then
        print(('[Creatures] Invalid SelfMend AetherCost for %s')
            :format(race))
        return
    end

    -- Get current Aetherium.
    local currentAether = tonumber(
        exports.qbx_core:GetMetadata(src, 'aetherium')
    )

    if currentAether == nil then
        currentAether = 100
        player.Functions.SetMetaData('aetherium', currentAether)
    end

    if currentAether < cost then
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Self Mend',
            description = 'You do not have enough Aetherium.',
            type = 'error'
        })
        return
    end

    -- Fully restore health, clear every injury, and restore every limb.
    local options = {
        injuries = {
            {
                type = 'all',
                limb = 'all'
            }
        },
        limbHealth = 100,
    }

    local success, err = exports['wasabi_ambulance_v2']:ApplyHeal(
        src,
        options
    )

    if not success then
        print(('[Creatures] Self Mend failed for %s: %s')
            :format(src, tostring(err)))

        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Self Mend',
            description = 'Self Mend could not heal your injuries.',
            type = 'error'
        })
        return
    end

    -- Deduct Aetherium only after successful healing.
    local newAether = currentAether - cost

    player.Functions.SetMetaData('aetherium', newAether)

    TriggerClientEvent(
        'creatures:client:set',
        src,
        newAether
    )

    TriggerClientEvent('ox_lib:notify', src, {
        title = 'Self Mend',
        description = (
            'Your health, limbs, and injuries have been restored. Aetherium remaining: %s'
        ):format(newAether),
        type = 'success'
    })
end)