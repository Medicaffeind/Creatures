if not Config.Wings.kitsuneEnabled then return end

local settings = Config.KitsuneTails

local function getTailAccess(source, pack)
    if GetResourceState('creatures') ~= 'started' then return 0 end
    if not exports.creatures:HasRequiredRace(source, settings.races) then return 0 end

    -- Resolve the tier exclusively through creatures' authoritative exports.
    local tiers = settings.tailsByTier
    if type(pack) == 'string' and settings.nolis and settings.nolis.packs[pack] then
        tiers = settings.nolis.tailsByTier
    end
    for tier, count in pairs(tiers) do
        if exports.creatures:HasRequiredTier(source, tier) then
            return count
        end
    end
    return 0
end

lib.callback.register('creatures:server:getKitsuneTailAccess', getTailAccess)

-- Ears require the race only, independently of tier validity or tail unlocks.
lib.callback.register('creatures:server:canUseKitsuneEars', function(source)
    return GetResourceState('creatures') == 'started'
        and exports.creatures:HasRequiredRace(source, { 'kitsune' }) == true
end)
