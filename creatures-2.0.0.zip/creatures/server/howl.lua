if not Config.Howl.Enabled then return end
local active, cooldown = {}, {}
local serial = 0

local function notify(src, message)
    TriggerClientEvent('ox_lib:notify', src, {
        title = 'Werewolf Howl', description = message, type = 'error'
    })
end

local function stop(src)
    local howl = active[src]
    if not howl then return end
    for target in pairs(howl.listeners) do
        TriggerClientEvent('creatures:howl:stop', target, howl.id)
    end
    active[src] = nil
end

RegisterNetEvent('creatures:howl:request', function()
    local src = source
    if (cooldown[src] or 0) > os.time() then return end
    -- Throttle rejected requests as well; never trust client race/position/URL.
    cooldown[src] = os.time() + 2
    if GetResourceState('creatures') ~= 'started'
        or not Config.Howl.AllowedRaces[exports.creatures:GetPlayerRace(src)] then
        return notify(src, 'Only werewolves can howl.')
    end
    if not Config.Howl.SoundUrls or #Config.Howl.SoundUrls == 0 then
        return notify(src, 'The howl sound has not been configured yet.')
    end
    local ped = GetPlayerPed(src)
    if ped == 0 or GetEntityHealth(ped) <= 0 then return end
    stop(src)
    cooldown[src] = os.time() + Config.Howl.CooldownSeconds
    serial = serial + 1
    local pos = GetEntityCoords(ped)
    local howl = {
        id = ('creatures_howl_%s_%s'):format(src, serial),
        bucket = GetPlayerRoutingBucket(src),
        started = GetGameTimer(), listeners = {}
    }
    local soundIndex = math.random(#Config.Howl.SoundUrls)
    active[src] = howl
    -- Coordinate-based delivery works beyond OneSync ped streaming range.
    for _, player in ipairs(GetPlayers()) do
        local target = tonumber(player)
        local targetPed = GetPlayerPed(target)
        if targetPed ~= 0 and GetPlayerRoutingBucket(target) == howl.bucket
            and #(GetEntityCoords(targetPed) - pos) <= Config.Howl.Range + Config.Howl.ListenerBuffer then
            howl.listeners[target] = true
            TriggerClientEvent('creatures:howl:play', target, howl.id, pos, soundIndex)
            -- Only other werewolves within actual hearing range receive the GPS offer.
            if Config.Howl.GpsPrompt and target ~= src and #(GetEntityCoords(targetPed) - pos) < Config.Howl.Range
                and Config.Howl.AllowedRaces[exports.creatures:GetPlayerRace(target)] then
                TriggerClientEvent('creatures:howl:gpsOffer', target, pos)
            end
        end
    end
end)

CreateThread(function()
    while true do
        Wait(Config.Howl.UpdateMs)
        for src, howl in pairs(active) do
            local ped = GetPlayerPed(src)
            if ped == 0 or GetPlayerRoutingBucket(src) ~= howl.bucket
                or GetGameTimer() - howl.started >= Config.Howl.DurationMs then
                stop(src)
            else
                local pos = GetEntityCoords(ped)
                for target in pairs(howl.listeners) do
                    if GetPlayerPed(target) == 0 or GetPlayerRoutingBucket(target) ~= howl.bucket then
                        TriggerClientEvent('creatures:howl:stop', target, howl.id)
                        howl.listeners[target] = nil
                    else
                        TriggerClientEvent('creatures:howl:position', target, howl.id, pos)
                    end
                end
            end
        end
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    stop(src)
    cooldown[src] = nil
    for _, howl in pairs(active) do howl.listeners[src] = nil end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for src in pairs(active) do stop(src) end
end)
