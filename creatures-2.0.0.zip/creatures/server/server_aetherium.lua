local DEFAULT_AETHERIUM = 100
local MAX_AETHERIUM = 100


local function GetPlayerAetherium(source)

    local value =
        exports.qbx_core:GetMetadata(
            source,
            'aetherium'
        )

    value = tonumber(value)

    if value == nil then
        value = DEFAULT_AETHERIUM

        exports.qbx_core:SetMetadata(
            source,
            'aetherium',
            value
        )
    end

    return math.max(
        0,
        math.min(
            MAX_AETHERIUM,
            value
        )
    )
end

exports('GetPlayerAetherium', GetPlayerAetherium)


local function SetPlayerAetherium(source, value)

    value = tonumber(value)

    if not value or value ~= value or value == math.huge or value == -math.huge then
        return false
    end

    value = math.max(
        0,
        math.min(
            MAX_AETHERIUM,
            value
        )
    )

    exports.qbx_core:SetMetadata(
        source,
        'aetherium',
        value
    )

    TriggerClientEvent(
        'creatures:client:set',
        source,
        value
    )

    return true
end

exports('SetPlayerAetherium', SetPlayerAetherium)


RegisterNetEvent(
    'creatures:server:update',
    function(value)

        local src = source

        local player =
            exports.qbx_core:GetPlayer(src)

        if not player then
            return
        end

        SetPlayerAetherium(
            src,
            value
        )
    end
)


AddEventHandler(
    'QBCore:Server:OnPlayerLoaded',
    function()

        local src = source

        local player =
            exports.qbx_core:GetPlayer(src)

        if not player then
            return
        end

        local value =
            GetPlayerAetherium(src)

        TriggerClientEvent(
            'creatures:client:set',
            src,
            value
        )

        print(
            ('[Creatures] Aetherium loaded for %s: %s')
                :format(
                    src,
                    value
                )
        )
    end
)