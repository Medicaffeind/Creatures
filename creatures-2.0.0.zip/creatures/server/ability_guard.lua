-- Central validation for ability network entry points. Local-only visual and
-- movement effects still rely on the client; see SECURITY.md for the boundary.
local policies = {
    ['creatures:setDemonVeil'] = { races = { 'demon' }, boolean = 1 },
    ['creatures:suppressionEffect'] = { races = { 'demon' }, target = 1, range = 12, origin = 2, cooldown = 30000 },
    ['creatures:demonDisturb'] = { races = { 'demon' }, target = 1, range = 12 },
    ['creatures_fae:mischief'] = { races = { 'fae' }, model = 1, cooldown = 30000 },
    ['creatures_fae:endMischief'] = { races = { 'fae' } },
    ['creatures_fae:fairydust'] = { races = { 'fae' }, target = 1, range = 12, cooldown = 900000 },
    ['creatures:aetheriumBoltCast'] = { races = { 'witch', 'warlock' }, origin = 1, direction = 2 },
    ['creatures:concussiveBlastHit'] = { races = { 'witch', 'warlock' }, target = 1, range = 10, direction = 2 },
    ['creatures:dragonFireBreath'] = { races = { 'maledragonkin', 'femaledragonkin' }, origin = 1, direction = 2 },
    ['creatures:dragonGustHit'] = { races = { 'maledragonkin', 'femaledragonkin', 'witch', 'warlock' }, target = 1, range = 10, direction = 2 },
    ['creatures:healingRain'] = { races = { 'elf' }, origin = 1, cooldown = 60000 },
    ['creatures:rootTarget'] = { races = { 'elf' }, target = 1, range = 12, cooldown = 25000 },
    ['creatures:maulTarget'] = { races = { 'maleursar', 'femaleursar' }, target = 1, range = 4 },
    ['creatures:ursarRoar'] = { races = { 'maleursar', 'femaleursar' }, origin = 1 },
    ['creatures:hydroSpear'] = { races = { 'mermaid' }, origin = 1, direction = 2 },
    ['creatures:werewolfHowl'] = { races = { 'malewerewolf', 'femalewerewolf' } },
    ['creatures:werewolfRend'] = { races = { 'malewerewolf', 'femalewerewolf' }, target = 1, range = 4 },
    ['creatures:werewolfBreachDoor'] = { races = { 'malewerewolf', 'femalewerewolf' }, origin = 2 },
    ['creatures:angelDestress'] = { races = { 'angel' }, target = 1, range = 15 },
    ['creatures:server:angelSanctuary'] = { races = { 'angel' } },
    ['creatures:server:angelDivineSmite'] = { races = { 'angel' }, origin = 1, originRange = 100 },
    ['creatures:server:angelDivineTouch'] = { races = { 'angel' }, dependency = 'wasabi_ambulance_v2' },
    ['creatures:server:kitsuneDash'] = { races = { 'kitsune' } },
    ['creatures:server:kitsuneDashTrail'] = { races = { 'kitsune' } },
    ['creatures:server:kitsuneFoxFire'] = { races = { 'kitsune' } },
    ['creatures:server:selfMend'] = { races = { 'standardmob', 'bossmob' }, dependency = 'wasabi_ambulance_v2' },
}

local props = {
    'prop_box_ammo07a', 'prop_bush_neat_06', 'prop_couch_sm_02',
    'prop_recyclebin_04_b', 'prop_barrel_exp_01a', 'prop_cs_panties_03',
    'prop_bush_neat_02', 'prop_bush_med_06', 'prop_pot_plant_05d',
    'prop_roadcone01b', 'prop_mc_conc_barrier_01', 'prop_barrier_wat_03b', 'prop_sign_road_01a',
}
local allowedProps = {}
for _, model in ipairs(props) do allowedProps[model] = true end
local limits = {}
local function finite(value)
    return type(value) == 'number' and value == value and math.abs(value) < 1000000
end
local function vector(value)
    return type(value) == 'vector3' and finite(value.x) and finite(value.y) and finite(value.z)
end

function CreaturesRegisterAbilityEvent(name, handler)
    local policy = assert(policies[name], 'Missing ability policy: ' .. name)
    RegisterNetEvent(name, function(...)
        local src, args = source, table.pack(...)
        if not HasRequiredRace(src, policy.races) then return end
        local ped = GetPlayerPed(src)
        if ped == 0 or GetEntityHealth(ped) <= 0 then return end
        if policy.boolean and type(args[policy.boolean]) ~= 'boolean' then return end
        if policy.model and not allowedProps[args[policy.model]] then return end
        if policy.target then
            local target = tonumber(args[policy.target])
            if not target or target ~= math.floor(target) then return end
            local targetPed = GetPlayerPed(target)
            if targetPed == 0 or GetPlayerRoutingBucket(src) ~= GetPlayerRoutingBucket(target)
                or #(GetEntityCoords(ped) - GetEntityCoords(targetPed)) > policy.range then return end
            args[policy.target] = target
        end
        if policy.origin then
            local origin = args[policy.origin]
            if not vector(origin) or #(GetEntityCoords(ped) - origin) > (policy.originRange or 5) then return end
        end
        if policy.direction then
            local direction = args[policy.direction]
            if not vector(direction) or #direction > 1.5 then return end
        end
        limits[src] = limits[src] or {}
        local key = name .. (policy.target and (':' .. args[policy.target]) or '')
        local now = GetGameTimer()
        if now < (limits[src][key] or 0) then return end
        limits[src][key] = now + (policy.cooldown or 1000)
        if policy.dependency and GetResourceState(policy.dependency) ~= 'started' then
            TriggerClientEvent('ox_lib:notify', src, {
                title = 'Ability unavailable', type = 'error',
                description = 'This ability requires ' .. policy.dependency .. '.',
            })
            return
        end
        handler(table.unpack(args, 1, args.n))
    end)
end
AddEventHandler('playerDropped', function() limits[source] = nil end)
