local function canManage(source)
    if source > 0 and IsPlayerAceAllowed(source, Config.AdminAce) then return true end
    if source > 0 then
        TriggerClientEvent('ox_lib:notify', source, {
            title = 'Access denied', description = 'Creature administration permission required.', type = 'error'
        })
    end
    return false
end

local function validForm(source, race, formType)
    local player = exports.qbx_core:GetPlayer(source)
    return player and type(race) == 'string' and Config.Races[race]
        and player.PlayerData.metadata.creatureRace == race
        and (formType == 'transform' or formType == 'mutate')
end

-- Server

-- Save form appearance from Illenium to player metadata
lib.callback.register('creatures:server:saveFormAppearance', function(source, race, formType, appearance)
    local Player = exports.qbx_core:GetPlayer(source)
    if not Player then return false end
    if not validForm(source, race, formType) or type(appearance) ~= 'table' then return false end
    local ok, encoded = pcall(json.encode, appearance)
    if not ok or #encoded > 65536 then return false end
    local raceData = Config.Races[race]
    local tier = tonumber(Player.PlayerData.metadata.creatureTier) or 0
    local expected = formType == 'mutate' and raceData.mutateModel
        or (tier == 5 and raceData.eldertransformModel or raceData.transformModel)
    if appearance.model ~= expected and appearance.model ~= joaat(expected) then return false end

    local meta = Player.PlayerData.metadata or {}

    meta.creatureForms = meta.creatureForms or {}
    meta.creatureForms[race] = meta.creatureForms[race] or {}
    meta.creatureForms[race][formType] = meta.creatureForms[race][formType] or {}

    meta.creatureForms[race][formType].model = appearance.model or GetEntityModel(GetPlayerPed(source))
    meta.creatureForms[race][formType].appearance = json.encode(appearance)


    Player.Functions.SetMetaData('creatureForms', meta.creatureForms)
    Player.Functions.Save() -- forces DB save


    print(('[creatures] Saved %s form for race %s for player %s'):format(formType, race, Player.PlayerData.citizenid))
    return true
end)



-- Get saved form appearance
lib.callback.register('creatures:server:getFormAppearance', function(source, race, formType)
    if not validForm(source, race, formType) then return nil end
    local Player = exports.qbx_core:GetPlayer(source)
    if not Player then return nil end

    local meta = Player.PlayerData.metadata.creatureForms or {}

    if meta[race] and meta[race][formType] then
    local formData = meta[race][formType]
    formData.model = formData.model or Config.Races[race][formType .. "Model"]

    if type(formData.appearance) == "string" then
        formData.appearance = json.decode(formData.appearance)
    end

        return formData
    end


    -- If nothing saved, return default from config
    if Config.Races[race] and Config.Races[race][formType .. "Model"] then
        return { model = Config.Races[race][formType .. "Model"], appearance = nil }
    end

    return nil
end)


-- Get saved race

function GetPlayerRace(source)
    local Player = exports.qbx_core:GetPlayer(source)
    return Player and Player.PlayerData.metadata.creatureRace or 'human'
end

exports('GetPlayerRace', GetPlayerRace)

lib.callback.register('creatures:server:getSavedRace', function(source)
    return GetPlayerRace(source)
end)

-- Assign Race Command
RegisterCommand("setrace", function(source, args, raw)
    if not canManage(source) then return end
    local src = source
    if src == 0 then
        print("Console cannot use this command.")
        return
    end

    local targetId = tonumber(args[1])
    local race = args[2]

    if not targetId or not race then
        return TriggerClientEvent('ox_lib:notify', source, {
            title = "Usage",
            description = "Usage: /setrace [id] [race]",
            type = "error"
        })
    end

    if not Config.Races[race] then
        return TriggerClientEvent('ox_lib:notify', source, {
            title = "Invalid Race",
            description = ("'%s' is not a valid race."):format(race),
            type = "error"
        })
    end

    local Player = exports.qbx_core:GetPlayer(targetId)
    if not Player then
        return TriggerClientEvent('ox_lib:notify', source, {
            title = "Player Not Found",
            description = ("No player found with ID %s."):format(targetId),
            type = "error"
        })
    end

    Player.Functions.SetMetaData("creatureRace", race)

    SetPlayerToughness(targetId)
    
    TriggerClientEvent("creatures:client:setRace", targetId, race)

    TriggerClientEvent('ox_lib:notify', source, {
        title = "Race Set",
        description = ("Player %s is now race '%s'."):format(targetId, race),
        type = "success"
    })

    TriggerClientEvent('ox_lib:notify', targetId, {
        title = "Race Assigned",
        description = ("You have been set as race '%s'."):format(race),
        type = "inform"
    })
end, false)


-- Remove Race Command
RegisterCommand("removerace", function(source, args, raw)
    if not canManage(source) then return end
    local src = source
    if src == 0 then
        print("Console cannot use this command.")
        return
    end

    local targetId = tonumber(args[1])
    if not targetId then
        return TriggerClientEvent('ox_lib:notify', source, {
            title = "Usage",
            description = "Usage: /removerace [id]",
            type = "error"
        })
    end

    local Player = exports.qbx_core:GetPlayer(targetId)
    if not Player then
        return TriggerClientEvent('ox_lib:notify', source, {
            title = "Player Not Found",
            description = ("No player found with ID %s."):format(targetId),
            type = "error"
        })
    end

    Player.Functions.SetMetaData("creatureRace", nil)

    TriggerClientEvent("creatures:client:setToughness", targetId, 0)

    TriggerClientEvent("creatures:client:clearRace", targetId)

    TriggerClientEvent('ox_lib:notify', source, {
        title = "Race Removed",
        description = ("Removed race from player %s."):format(targetId),
        type = "success"
    })

    TriggerClientEvent('ox_lib:notify', targetId, {
        title = "Race Removed",
        description = "Your race has been cleared.",
        type = "inform"
    })
end, false)

-- Get Saved Tier
lib.callback.register('creatures:server:getSavedTier', function(source)
    local Player = exports.qbx_core:GetPlayer(source)
    if Player then
        return Player.PlayerData.metadata.creatureTier or 0
    end
    return 0
end)

-- Assign Tier Command
RegisterCommand("settier", function(source, args)
    if not canManage(source) then return end
    local src = source
    if src == 0 then return print("Console cannot use this command.") end

    local targetId = tonumber(args[1])
    local tier = tonumber(args[2])

    if not targetId or not tier then
        return TriggerClientEvent('ox_lib:notify', source, {
            title = "Usage",
            description = "/settier [id] [0-5]",
            type = "error"
        })
    end

    if tier ~= math.floor(tier) or tier < 0 or tier > 5 then
        return TriggerClientEvent('ox_lib:notify', source, {
            title = "Invalid Tier",
            description = "Tier must be between 0 and 5.",
            type = "error"
        })
    end

    local Player = exports.qbx_core:GetPlayer(targetId)
    if not Player then
        return TriggerClientEvent('ox_lib:notify', source, {
            title = "Player Not Found",
            description = ("No player found with ID %s."):format(targetId),
            type = "error"
        })
    end

    Player.Functions.SetMetaData("creatureTier", tier)
    TriggerClientEvent("creatures:client:setTier", targetId, tier)

    TriggerClientEvent('ox_lib:notify', source, {
        title = "Tier Set",
        description = ("Player %s now has tier %s."):format(targetId, tier),
        type = "success"
    })
end, false)

-- Remove Tier
RegisterCommand("removetier", function(source, args)
    if not canManage(source) then return end
    local src = source
    if src == 0 then return print("Console cannot use this command.") end

    local targetId = tonumber(args[1])
    if not targetId then
        return TriggerClientEvent('ox_lib:notify', source, {
            title = "Usage",
            description = "/removetier [id]",
            type = "error"
        })
    end

    local Player = exports.qbx_core:GetPlayer(targetId)
    if not Player then
        return TriggerClientEvent('ox_lib:notify', source, {
            title = "Player Not Found",
            description = ("No player found with ID %s."):format(targetId),
            type = "error"
        })
    end

    Player.Functions.SetMetaData("creatureTier", nil)
    TriggerClientEvent("creatures:client:clearTier", targetId)

    TriggerClientEvent('ox_lib:notify', source, {
        title = "Tier Removed",
        description = ("Tier removed from player %s."):format(targetId),
        type = "success"
    })
    Player.Functions.Save()
end, false)

-- Check if player already has a saved form appearance
lib.callback.register('creatures:server:hasFormAppearance', function(source, race, formType)
    if not validForm(source, race, formType) then return nil end
    local Player = exports.qbx_core:GetPlayer(source)
    if not Player then return false end

    local meta = Player.PlayerData.metadata or {}
    meta.creatureForms = meta.creatureForms or {}

    local hasAppearance = meta.creatureForms[race]
    and meta.creatureForms[race][formType]
    and meta.creatureForms[race][formType].appearance
    and meta.creatureForms[race][formType].appearance ~= "{}"

    return hasAppearance and true or false

end)

function HasRequiredRace(source, requiredRace)
    local Player = exports.qbx_core:GetPlayer(source)
    if not Player then return false end

    local playerRace = Player.PlayerData.metadata.creatureRace or 'human'

    if not requiredRace then return true end

    if type(requiredRace) == 'string' then
        return playerRace == requiredRace
    end

    if type(requiredRace) == 'table' then
        -- support { 'elf', 'dwarf' }
        for i = 1, #requiredRace do
            if requiredRace[i] == playerRace then
                return true
            end
        end

        -- support { allow = {}, deny = {} }
        if requiredRace.allow then
            for i = 1, #requiredRace.allow do
                if requiredRace.allow[i] == playerRace then
                    return true
                end
            end
            return false
        end

        if requiredRace.deny then
            for i = 1, #requiredRace.deny do
                if requiredRace.deny[i] == playerRace then
                    return false
                end
            end
            return true
        end
    end

    return false
end

exports('HasRequiredRace', HasRequiredRace)

function HasRequiredTier(source, requiredTier)
    local Player = exports.qbx_core:GetPlayer(source)

    if not Player then
        return false
    end

    local playerRace = Player.PlayerData.metadata.creatureRace or 'human'
    local playerTier = tonumber(Player.PlayerData.metadata.creatureTier) or 0

    if requiredTier == nil then
        return true
    end

    if not Config.Races[playerRace] then
        return false
    end

    if not Config.Races[playerRace].Tiers[playerTier] then
        return false
    end

    if type(requiredTier) == 'number' then
        return playerTier == requiredTier
    end

    if type(requiredTier) == 'string' then
        local tier = tonumber(requiredTier)

        if tier then
            return playerTier == tier
        end

        return false
    end

    if type(requiredTier) ~= 'table' then
        return false
    end

    for i = 1, #requiredTier do
        local tier = tonumber(requiredTier[i])

        if tier and playerTier == tier then
            return true
        end
    end

    if requiredTier.allow then
        for i = 1, #requiredTier.allow do
            local tier = tonumber(requiredTier.allow[i])

            if tier and playerTier == tier then
                return true
            end
        end

        return false
    end

    if requiredTier.deny then
        for i = 1, #requiredTier.deny do
            local tier = tonumber(requiredTier.deny[i])

            if tier and playerTier == tier then
                return false
            end
        end

        return true
    end

    if requiredTier.min then
        local minTier = tonumber(requiredTier.min)

        if minTier and playerTier < minTier then
            return false
        end
    end

    if requiredTier.max then
        local maxTier = tonumber(requiredTier.max)

        if maxTier and playerTier > maxTier then
            return false
        end
    end

    -- Passed min/max requirements
    if requiredTier.min or requiredTier.max then
        return true
    end

    return false
end

exports('HasRequiredTier', HasRequiredTier)

-- Toughness

local function GetMaxToughness(source)
    local Player = exports.qbx_core:GetPlayer(source)
    if not Player then return 0 end

    local race = Player.PlayerData.metadata.creatureRace or 'human'

    if race == 'human' then
        return 0
    end

    local raceData = Config.Races[race]
    if not raceData then
        return 0
    end

    return tonumber(raceData.toughness) or 0
end

function SetPlayerToughness(source)
    local amount = GetMaxToughness(source)

    TriggerClientEvent(
        'creatures:client:setToughness',
        source,
        amount
    )

    return amount
end

exports('SetPlayerToughness', SetPlayerToughness)

function GetPlayerToughness(source)
    return GetMaxToughness(source)
end

exports('GetPlayerToughness', GetPlayerToughness)

lib.callback.register('creatures:server:getToughness', function(source)
    return GetMaxToughness(source)
end)
