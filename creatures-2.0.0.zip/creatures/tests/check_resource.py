"""Offline regression checks. Requires Python 3 and lupa (Lua 5.4).

Run from any directory: python tests/check_resource.py
These mocks exercise registration and policy; they do not simulate GTA/FiveM.
"""
from pathlib import Path
import re
from lupa.lua54 import LuaRuntime

ROOT = Path(__file__).resolve().parents[1]
lua = LuaRuntime(unpack_returned_tuples=True)
compile_lua = lua.eval('function(code, name) local f,e = load(code,name); return f ~= nil,e end')
files = sorted(ROOT.rglob('*.lua'))
for path in files:
    ok, error = compile_lua(path.read_text(encoding='utf-8-sig'), str(path))
    assert ok, error
print(f'PASS: Lua 5.4 syntax ({len(files)} files)')

lua.execute('''
callbacks, events, commands, api, threads, sent, players = {}, {}, {}, {}, {}, {}, {}
clock, now, source, admin = 10000, 1000, 1, false
resourceStates = {}
local builtinType = type
local vm = {}
function vector3(x,y,z) return setmetatable({x=x,y=y,z=z}, vm) end
vm.__sub = function(a,b) return vector3(a.x-b.x,a.y-b.y,a.z-b.z) end
vm.__add = function(a,b) return vector3(a.x+b.x,a.y+b.y,a.z+b.z) end
vm.__mul = function(a,b) return vector3(a.x*b,a.y*b,a.z*b) end
vm.__len = function(a) return math.sqrt(a.x*a.x+a.y*a.y+a.z*a.z) end
function type(v) if getmetatable(v) == vm then return 'vector3' end return builtinType(v) end
function joaat(v) return v end
function GetGameTimer() return clock end
os.time = function() return now end
function GetCurrentResourceName() return 'creatures' end
function GetResourceState(name) return resourceStates[name] or 'started' end
function IsPlayerAceAllowed(id, ace) assert(ace == Config.AdminAce); return admin end
function GetPlayers() local t={} for id in pairs(players) do t[#t+1]=tostring(id) end return t end
function GetPlayerPed(id) return players[tonumber(id)] and tonumber(id) or 0 end
function GetEntityHealth(ped) return players[ped] and 200 or 0 end
function GetEntityCoords(ped) return players[ped].coords end
function GetEntityModel(ped) return 'mp_m_freemode_01' end
function GetPlayerRoutingBucket(id) return players[tonumber(id)].bucket end
function GetPlayerName(id) return players[id] and 'test' or nil end
function DoesEntityExist(ped) return ped ~= 0 end
function TriggerClientEvent(name, target, ...) sent[#sent+1]={name=name,target=target,args={...}} end
function CreateThread(fn) threads[#threads+1]=coroutine.create(fn) end
function Wait(ms) coroutine.yield(ms) end
function SetTimeout(ms,fn) end
function AddEventHandler(name,fn) events[name]=events[name] or {}; table.insert(events[name],fn) end
function RegisterNetEvent(name,fn)
    assert(not callbacks[name], 'callback/event collision '..name)
    AddEventHandler(name,fn)
end
function RegisterCommand(name,fn)
    assert(not commands[name], 'duplicate command '..name)
    commands[name]=fn
end
function TriggerEvent(name,...) for _,fn in ipairs(events[name] or {}) do fn(...) end end
json={encode=function(v) return '{}' end,decode=function(v) return {} end}
GlobalState={}
lib={callback={register=function(name,fn)
    assert(not callbacks[name], 'duplicate callback '..name)
    callbacks[name]=fn
end}}
local qbx = {}
function qbx:GetPlayer(id) return players[tonumber(id)] end
function qbx:GetMetadata(id,key) return players[id].PlayerData.metadata[key] end
function qbx:SetMetadata(id,key,value) players[id].PlayerData.metadata[key]=value end
exports=setmetatable({qbx_core=qbx}, {
    __call=function(_,name,fn) assert(not api[name], 'duplicate export '..name); api[name]=fn end,
    __index=function(_,resource)
        return setmetatable({}, {__index=function(_,name) return function(_,...) return api[name](...) end end})
    end
})
function addPlayer(id,race,tier,x,bucket)
    local meta={creatureRace=race,creatureTier=tier,aetherium=100}
    players[id]={coords=vector3(x or 0,0,0),bucket=bucket or 0,
        PlayerData={metadata=meta,citizenid='test'..id},
        Functions={SetMetaData=function(k,v) meta[k]=v end,Save=function() end}}
end
function fire(name,id,...)
    source=id
    for _,fn in ipairs(events[name] or {}) do fn(...) end
end
''')

def execute(relative):
    lua.execute((ROOT / relative).read_text(encoding='utf-8-sig'), name=relative)

for name in ('config', 'wings', 'howl'):
    execute(f'shared/{name}.lua')
lua.execute('''
local count=0
for race, data in pairs(Config.Races) do
    count=count+1
    for _, key in ipairs({'transformModel','eldertransformModel','mutateModel'}) do
        assert(data[key]=='mp_m_freemode_01' or data[key]=='mp_f_freemode_01', race..':'..key)
    end
    for tier=0,5 do assert(data.Tiers[tier],race..': missing tier') end
end
assert(count >= 20)
assert(Config.Races.werecatfemale.transformModel=='mp_f_freemode_01')
assert(Config.Howl and Config.FlightSpeeds and Config.Races, 'configuration overwritten')
Config.Wings.kitsuneEnabled=true
Config.Wings.mothEnabled=true
''')
print('PASS: combined configuration and freemode defaults')

manifest = (ROOT / 'fxmanifest.lua').read_text(encoding='utf-8-sig')
server_block = re.search(r'server_scripts\s*{(.*?)}', manifest, re.S)[1]
for relative in re.findall(r"'([^']+)'", server_block):
    execute(relative)
print('PASS: server startup and unique callbacks/exports/commands')

lua.execute('''
addPlayer(1,'fae',0)
addPlayer(2,'human',0,10)
commands.setrace(1,{'2','malewerewolf'})
assert(players[2].PlayerData.metadata.creatureRace=='human','unprivileged race assignment')
admin=true
commands.setrace(1,{'2','malewerewolf'})
assert(players[2].PlayerData.metadata.creatureRace=='malewerewolf')
commands.settier(1,{'2','2.5'})
assert(players[2].PlayerData.metadata.creatureTier==0,'fractional tier accepted')
commands.settier(1,{'2','5'})
assert(players[2].PlayerData.metadata.creatureTier==5)
assert(callbacks['creatures:server:saveFormAppearance'](1,'fae','transform',{model='mp_m_freemode_01'}))
assert(not callbacks['creatures:server:saveFormAppearance'](1,'demon','transform',{model='mp_m_freemode_01'}))
assert(not callbacks['creatures:server:saveFormAppearance'](1,'fae','transform',{model='custom_ped'}))
assert(not callbacks['creatures:server:saveFormAppearance'](1,'fae','invalid',{}))
for tier=0,5 do
    players[1].PlayerData.metadata.creatureTier=tier
    local maximum=callbacks['creatures:server:getFlightSpeedAccess'](1)
    assert(maximum==math.floor(tier/2)+1)
end
assert(callbacks['creatures:server:canUseWingSet'](1,'fae_new'))
assert(not callbacks['creatures:server:canUseWingSet'](1,'demon_new'))
assert(not callbacks['creatures:server:canUseWingSet'](1,'missing'))
players[1].PlayerData.metadata.creatureRace='human'
assert(callbacks['creatures:server:getFlightSpeedAccess'](1)==0)
players[1].PlayerData.metadata.creatureRace='kitsune'
assert(callbacks['creatures:server:getKitsuneTailAccess'](1)==9)
players[1].PlayerData.metadata.creatureTier=2
assert(callbacks['creatures:server:getKitsuneTailAccess'](1)==3)
assert(callbacks['creatures:server:canUseKitsuneEars'](1))
assert(api.SetPlayerAetherium(1,150))
assert(api.GetPlayerAetherium(1)==100)
assert(not api.SetPlayerAetherium(1,0/0))
assert(not api.SetPlayerAetherium(1,math.huge))
''')
print('PASS: staff permissions, form validation, flight tiers, wing ownership, tails, energy bounds')

lua.execute('''
sent={}
fire('creatures:suppressionEffect',1,2,vector3(0,0,0))
assert(#sent==0,'wrong race can suppress')
players[1].PlayerData.metadata.creatureRace='demon'
fire('creatures:suppressionEffect',1,2,vector3(999,0,0))
assert(#sent==0,'forged origin accepted')
players[2].bucket=1
fire('creatures:suppressionEffect',1,2,vector3(0,0,0))
assert(#sent==0,'cross-bucket target accepted')
players[2].bucket=0
fire('creatures:suppressionEffect',1,2,vector3(0,0,0))
assert(#sent==1)
fire('creatures:suppressionEffect',1,2,vector3(0,0,0))
assert(#sent==1,'cooldown ignored')
players[1].PlayerData.metadata.creatureRace='fae'
fire('creatures_fae:mischief',1,'unapproved_model')
assert(#sent==1,'unapproved prop accepted')
''')
print('PASS: ability race, origin, routing-bucket, prop, and throttle guards')

lua.execute('''
Config.Howl.SoundUrls={'sounds/test1.ogg','sounds/test2.ogg'}
addPlayer(1,'malewerewolf',1,0)
addPlayer(2,'femalewerewolf',1,1000)
addPlayer(3,'human',0,1000)
addPlayer(4,'malewerewolf',1,1000,1)
addPlayer(5,'malewerewolf',1,2300)
addPlayer(6,'malewerewolf',1,2100)
sent={}
fire('creatures:howl:request',3)
for _,v in ipairs(sent) do assert(v.name~='creatures:howl:play') end
sent={}
fire('creatures:howl:request',1)
local heard, gps, selected = {},{},nil
for _,v in ipairs(sent) do
    if v.name=='creatures:howl:play' then
        heard[v.target]=true
        selected=selected or v.args[3]
        assert(selected==v.args[3],'listeners received different clips')
    end
    if v.name=='creatures:howl:gpsOffer' then gps[v.target]=true end
end
assert(heard[1] and heard[2] and heard[3] and heard[6])
assert(not heard[4] and not heard[5])
assert(gps[2] and not gps[1] and not gps[3] and not gps[6])
local before=#sent
fire('creatures:howl:request',1)
assert(#sent==before,'howl cooldown ignored')
players[1].bucket=2
local thread=threads[#threads]
assert(coroutine.resume(thread)) -- first wait
assert(coroutine.resume(thread)) -- bucket change stops delivery
local stopped=0
for _,v in ipairs(sent) do if v.name=='creatures:howl:stop' then stopped=stopped+1 end end
assert(stopped==4,'bucket change did not clean up all listeners')
fire('playerDropped',1)
''')
print('PASS: howl authorization, shared selection, radius/buffer, GPS, cooldown, bucket cleanup')

lua.execute('''
api, commands, events, threads = {}, {}, {}, {}
LocalPlayer = {state={isLoggedIn=true}}
PlayerData = {metadata={}}
function RegisterKeyMapping(...) end
function RegisterNUICallback(...) end
function PlayerId() return 1 end
function PlayerPedId() return 1 end
function GetHashKey(value) return joaat(value) end
function GetResourceKvpString(...) return nil end
function SendNUIMessage(...) end
''')
client_block = re.search(r'client_scripts\s*{(.*?)}', manifest, re.S)[1]
for relative in re.findall(r"'([^']+)'", client_block):
    if relative.startswith('@'):
        continue
    execute(relative)
print('PASS: client startup and unique commands/exports')

lua.execute('''
lib.notify=function() end
lib.requestModel=function() end
lib.callback.await=function(name,_,...) return callbacks[name](1,...) end
api.StartRaceAbilities=function() end
function GetPedArmour() return 0 end
function IsModelInCdimage() return true end
function IsModelAPed() return true end
function GetPlayerStamina() return 100 end
function SetPlayerStamina() end
function SetPlayerModel(_,model) selectedModel=model end
function SetModelAsNoLongerNeeded() end
function ExecuteCommand(text)
    local command,arg=text:match('^(%S+)%s*(.*)$')
    commands[command](0,{arg})
end
function run(fn,...)
    local co=coroutine.create(fn)
    local ok,err=coroutine.resume(co,...)
    assert(ok,err)
    local steps=0
    while coroutine.status(co)~='dead' do
        steps=steps+1; assert(steps<20,'unexpected long-running command')
        ok,err=coroutine.resume(co); assert(ok,err)
    end
end
edited=0
exports['illenium-appearance']={startPlayerCustomization=function(_,cb,config)
    assert(config.ped==false,'form editor allows an unconfigured model')
    edited=edited+1
    cb({model=selectedModel})
end}
addPlayer(1,'malewerewolf',0)
fire('creatures:client:setRace',1,'malewerewolf')
run(commands.transform)
assert(api.GetCurrentForm()=='transform')
assert(selectedModel=='mp_m_freemode_01' and edited==1)
local reloaded=false
AddEventHandler('illenium-appearance:client:reloadSkin',function() reloaded=true end)
commands.revert()
assert(api.GetCurrentForm()==nil and reloaded,'freemode transformation cannot revert')
run(commands.mutate)
assert(api.GetCurrentForm()=='mutate' and edited==2)
commands.revert()
players[1].PlayerData.metadata.creatureRace='femalewerewolf'
fire('creatures:client:setRace',1,'femalewerewolf')
run(commands.transform)
assert(selectedModel=='mp_f_freemode_01' and api.GetCurrentForm()=='transform')
''')
print('PASS: male/female freemode form editing and reverting')

for relative in re.findall(r"'((?:client|server|shared|html|integrations)/[^']+)'", manifest):
    if '*' in relative:
        assert list(ROOT.glob(relative)), f'Empty manifest glob: {relative}'
    else:
        assert (ROOT / relative).is_file(), f'Missing manifest file: {relative}'
for path in ROOT.rglob('*.md'):
    for href in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8-sig')):
        if '://' in href or href.startswith('#'):
            continue
        target = href.strip('<>').split('#')[0]
        if target:
            assert (path.parent / target).exists(), f'Broken link in {path.name}: {href}'
print('PASS: manifest paths and documentation links')
