const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const listeners = {};
const nodes = [];
const requests = [];
let fail = false;
let pendingResolve;
let hold = false;
const node = () => {
    const value = { value: 0, setTargetAtTime(v) { this.value = v; } };
    const result = {
        gain: value, pan: value, disconnected: false, started: false,
        connect() { return this; }, disconnect() { this.disconnected = true; },
        start() { this.started = true; }, stop() { this.stopped = true; },
    };
    nodes.push(result);
    return result;
};
const sandbox = {
    AudioContext: class {
        currentTime = 0;
        destination = {};
        createGain = node;
        createStereoPanner = node;
        createBufferSource = node;
        async resume() {}
        async decodeAudioData(data) { return data; }
    },
    window: { addEventListener(name, fn) { listeners[name] = fn; } },
    GetParentResourceName: () => 'creatures',
    AbortController,
    setTimeout: () => 1,
    clearTimeout() {},
    fetch: async (url, options) => {
        requests.push(url);
        if (!url.includes('/sounds/')) return { ok: true };
        if (hold) return new Promise(resolve => { pendingResolve = resolve; });
        return { ok: !fail, status: fail ? 404 : 200, arrayBuffer: async () => new ArrayBuffer(4) };
    },
};
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(__dirname, '../html/audio.js'), 'utf8'), sandbox);
const inspect = code => vm.runInContext(code, sandbox);
const send = data => listeners.message({ data });
const flush = () => new Promise(resolve => setImmediate(resolve));

(async () => {
    send({ action: 'play', id: 'one', url: 'https://local/sounds/one.ogg', duration: 15000 });
    await flush();
    assert.equal(inspect('sounds.size'), 1);
    assert.equal(inspect("sounds.get('one').source.started"), true);
    send({ action: 'update', id: 'one', volume: 0.45, pan: -1 });
    assert.equal(inspect("sounds.get('one').gain.gain.value"), 0.45);
    assert.equal(inspect("sounds.get('one').pan.pan.value"), -1);
    send({ action: 'update', id: 'one', volume: 20, pan: -10 });
    assert.equal(inspect("sounds.get('one').gain.gain.value"), 1);
    assert.equal(inspect("sounds.get('one').pan.pan.value"), -1);
    send({ action: 'play', id: 'two', url: 'https://local/sounds/two.ogg', duration: 15000 });
    await flush();
    assert.equal(inspect('sounds.size'), 2);
    send({ action: 'stop', id: 'one' });
    assert.equal(inspect('sounds.size'), 1);
    inspect("sounds.get('two').source.onended()");
    assert.equal(inspect('sounds.size'), 0);

    hold = true;
    send({ action: 'play', id: 'late', url: 'https://local/sounds/late.ogg', duration: 15000 });
    await flush();
    send({ action: 'stop', id: 'late' });
    const started = nodes.filter(n => n.started).length;
    pendingResolve({ ok: true, arrayBuffer: async () => new ArrayBuffer(4) });
    await flush();
    assert.equal(inspect('sounds.size'), 0);
    assert.equal(nodes.filter(n => n.started).length, started, 'late decode resurrected a stopped sound');

    hold = false;
    fail = true;
    send({ action: 'play', id: 'bad', url: 'https://local/sounds/missing.ogg', duration: 15000 });
    await flush();
    assert.equal(inspect('sounds.size'), 0);
    assert(requests.some(url => url.endsWith('/audioError')));
    assert(nodes.every(n => n.disconnected), 'audio nodes leaked');
    console.log('PASS: audio playback, attenuation/pan updates, concurrent sounds, cleanup, late-load cancellation, errors');
})().catch(error => { console.error(error); process.exitCode = 1; });
