# Changelog

## 2.0.0 — Combined resource

- Consolidated creatures, broadcast werewolf howls, and wing controls under `creatures`.
- Used the newer creature implementation, including its additional race/ability modules.
- Changed all transform, elder-transform, and mutation defaults to base freemode models.
- Made werewolf form checks independent of proprietary model hashes; fixed reverting from freemode forms.
- Replaced the patched xSound howl dependency with built-in NUI audio and configurable recordings.
- Replaced the custom Illenium editor patch with the standard customization export.
- Added explicit script ordering, optional wing adapters, staff ACE checks, input validation, and ability entry-point guards.
- Removed duplicate registrations and an unused QB-Core bridge dependency.
- Added installation, migration, integration, API, race, security, and testing documentation.

Runtime behavior still requires staging-server acceptance testing with the chosen dependencies and audio assets.
