# Source credits and external assets

This resource consolidates the Streets & Sorcery creature, werewolf-howl, and wing-control implementations.

The server copy used as the merge base credited **A big Richarrd**. The wing-controller manifest credited **Streets & Sorcery**. These source credits are preserved here.

The repository does not bundle third-party ped models, clothing meshes, wing assets, flight engines, howl recordings, ox resources, Qbox, Illenium Appearance, or Wasabi Ambulance. Install external resources separately under their own terms. Model names and vendor API names in adapter code identify integrations and do not grant rights to their assets.

No license file or permission to reuse third-party materials is supplied. Publicly viewable source does not itself define a reuse license.
