return {

    Passive = {
        {
            name = "Aetherium Regeneration",
            description = "Magical energy slowly replenishes.",

            tick = (function()

                local lastRegen = 0

                return function()

                    local now = GetGameTimer()

                    if now - lastRegen < 5000 then
                        return
                    end

                    lastRegen = now

                    exports.creatures:AddAetherium(5)
                end
            end)()
        },
        {
            name = "Agility",
            description = "Graceful movement and natural athleticism.",

            tick = function()
            
                local ped = PlayerPedId()
            
                if IsEntityDead(ped) then
                    return
                end
            
                local player = PlayerId()
            
                SetRunSprintMultiplierForPlayer(
                    player,
                    1.10
                )
            
                RestorePlayerStamina(
                    player,
                    0.15
                )
            
                SetPedGravity(
                    ped,
                    0.95
                )
            
                if IsPedRagdoll(ped) then
                
                    CreateThread(function()
                    
                        Wait(500)
                    
                        if DoesEntityExist(ped) then
                            ClearPedTasksImmediately(ped)
                        end
                    end)
                end
            end
        },
        {
            name = "Toughness",
            description = "A supernatural barrier absorbs damage after your armor is depleted.",
            tick = function()
            end
        }
    },
    Active = {
        {
            name = "Healing Rain",
            description = "Summon restorative rainfall.",
            cooldown = 60,

            trigger = function()

                if not exports.creatures:RemoveAetherium(30) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })
                end
            
                local coords =
                    GetEntityCoords(
                        PlayerPedId()
                    )
                
                TriggerServerEvent(
                    'creatures:healingRain',
                    coords
                )
            
                lib.notify({
                    title = "Healing Rain",
                    description = "Restorative rain begins to fall.",
                    type = "success"
                })
            end
        },
        {
            name = "Root",
            description = "Bind a target with living vines.",
            cooldown = 25,

            trigger = function()

                if not exports.creatures:RemoveAetherium(40) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })
                end
            
                local player, distance =
                    lib.getClosestPlayer(
                        GetEntityCoords(PlayerPedId()),
                        10.0
                    )
                
                if not player then
                    return
                end
            
                TriggerServerEvent(
                    'creatures:rootTarget',
                    GetPlayerServerId(player)
                )
            end
        }
    }
}