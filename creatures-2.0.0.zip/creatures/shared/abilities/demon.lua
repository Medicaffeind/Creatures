local dissipateActive = false

return {

    Passive = {
        {
            name = "Aetherium Regeneration",
            description = "Magical energy slowly replenishes.",

            tick = (function()

                local lastRegen = 0

                return function()

                    local now = GetGameTimer()

                    if now - lastRegen < 5000 then
                        return
                    end

                    lastRegen = now

                    exports.creatures:AddAetherium(5)
                end
            end)()
        },
        {
            name = "Disturb",
            description = "Your presence unnerves nearby mortals.",

            tick = (function()
            
                local lastStress = 0
            
                return function()
                
                    if LocalPlayer.state.demonVeiled then
                        return
                    end
                
                    local now = GetGameTimer()
                
                    if now - lastStress < 5000 then
                        return
                    end
                
                    lastStress = now
                
                    local ped = PlayerPedId()
                    local coords = GetEntityCoords(ped)
                
                    for _, playerId in ipairs(GetActivePlayers()) do
                    
                        local targetPed = GetPlayerPed(playerId)
                    
                        if targetPed ~= ped then
                        
                            local dist =
                                #(coords - GetEntityCoords(targetPed))
                        
                            if dist <= 10.0 then
                            
                                TriggerServerEvent(
                                    'creatures:demonDisturb',
                                    GetPlayerServerId(playerId)
                                )
                            end
                        end
                    end
                end
            end)()
        },
        {
            name = "Toughness",
            description = "A supernatural barrier absorbs damage after your armor is depleted.",
            tick = function()
            end
        }
    },
    Active = {
        {
            name = "Veil",
            description = "Suppress your infernal presence.",
            cooldown = 5,

            trigger = function()

                if not exports.creatures:RemoveAetherium(50) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })
                end
            
                LocalPlayer.state.demonVeiled =
                    not LocalPlayer.state.demonVeiled
            
                local enabled =
                    LocalPlayer.state.demonVeiled
            
                lib.notify({
                    title = enabled and "Veil" or "Disturb",
                    description = enabled
                        and "Your infernal aura is concealed."
                        or "Your infernal aura returns.",
                    type = "inform"
                })
            
                TriggerServerEvent(
                    'creatures:setDemonVeil',
                    enabled
                )
            end
        },
        {
            name = "Dissipate",
            description = "Become a cloud of shadow.",
            cooldown = 45,

            trigger = function()

                if not exports.creatures:RemoveAetherium(20) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })
                end

                local ped = PlayerPedId()
                local player = PlayerId()

                -- Toggle Off
                if dissipateActive then

                    dissipateActive = false

                    SetEntityVisible(ped, true, false)
                    SetRunSprintMultiplierForPlayer(player, 1.0)

                    lib.notify({
                        title = "Dissipate Ended",
                        description = "You return to physical form.",
                        type = "inform"
                    })

                    return
                end

                -- Toggle On
                dissipateActive = true

                SetEntityVisible(ped, false, false)
                SetRunSprintMultiplierForPlayer(player, 1.5)

                lib.notify({
                    title = "Dissipated",
                    description = "You become living shadow.",
                    type = "success"
                })

                local endTime = GetGameTimer() + 30000

                CreateThread(function()

                    while dissipateActive
                    and GetGameTimer() < endTime do

                        Wait(1000)

                        if IsEntityDead(ped) then
                            break
                        end
                    end

                    if not dissipateActive then
                        return
                    end

                    dissipateActive = false

                    SetEntityVisible(ped, true, false)
                    SetRunSprintMultiplierForPlayer(player, 1.0)

                    lib.notify({
                        title = "Dissipate Ended",
                        description = "Your shadow form fades.",
                        type = "inform"
                    })
                end)
            end
        },

       {
            name = "Suppression",
            description = "Overwhelm nearby mortals with dread.",
            cooldown = 30,

            trigger = function()

                if not exports.creatures:RemoveAetherium(30) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })
                end
            
                if LocalPlayer.state.demonSuppressing then
                
                    LocalPlayer.state.demonSuppressing = false
                
                    lib.notify({
                        title = "Suppression",
                        description = "Your oppressive aura fades.",
                        type = "inform"
                    })
                
                    return
                end
            
                LocalPlayer.state.demonSuppressing = true
            
                lib.notify({
                    title = "Suppression",
                    description = "Dark dread radiates from your presence.",
                    type = "success"
                })
            
                local endTime = GetGameTimer() + 30000
            
                CreateThread(function()
                
                    while LocalPlayer.state.demonSuppressing
                    and GetGameTimer() < endTime do
                    
                        Wait(5000)
                    
                        local ped = PlayerPedId()
                        local coords = GetEntityCoords(ped)
                    
                        for _, playerId in ipairs(GetActivePlayers()) do
                        
                            local targetPed = GetPlayerPed(playerId)
                        
                            if targetPed ~= ped then
                            
                                local dist =
                                    #(coords - GetEntityCoords(targetPed))
                            
                                if dist <= 15.0 then
                                
                                    TriggerServerEvent(
                                        'creatures:suppressionEffect',
                                        GetPlayerServerId(playerId),
                                        coords
                                    )
                                end
                            end
                        end
                    end
                
                    if not LocalPlayer.state.demonSuppressing then
                        return
                    end
                
                    LocalPlayer.state.demonSuppressing = false
                
                    lib.notify({
                        title = "Suppression Ended",
                        description = "The dread subsides.",
                        type = "inform"
                    })
                end)
            end
        }       
    }
}