return {

    Passive = {

        {
            name = "Aetherium Regeneration",
            description = "Magical energy slowly replenishes.",

            tick = (function()

                local lastRegen = 0

                return function()

                    local now = GetGameTimer()

                    if now - lastRegen < 5000 then
                        return
                    end

                    lastRegen = now

                    exports.creatures:AddAetherium(5)
                end
            end)()
        },
        {
            name = "Toughness",
            description = "A supernatural barrier absorbs damage after your armor is depleted.",
            tick = function()
            end
        }

    },

    Active = {

        {
            name = "Aetherium Shield",
            description = "Convert magic into protection.",
            cooldown = 300,

            trigger = function()

                if not exports.creatures:RemoveAetherium(20) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })
                end

                local ped = PlayerPedId()

                SetPedArmour(
                    ped,
                    math.min(
                        100,
                        GetPedArmour(ped) + 100
                    )
                )

                lib.notify({
                    title = "Aetherium Shield",
                    description = "Magic hardens around you.",
                    type = "success"
                })
            end
        },
        {
            name = "Aetherium Bolt",
            description = "Launch concentrated magical energy.",
            cooldown = 5,

            trigger = function()
            
                if not exports.creatures:RemoveAetherium(10) then
                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })
                end
            
                local ped = PlayerPedId()
            
                RequestAnimDict(
                    "weapons@first_person@aim_rng@generic@projectile@sticky_bomb@"
                )
            
                while not HasAnimDictLoaded(
                    "weapons@first_person@aim_rng@generic@projectile@sticky_bomb@"
                ) do
                    Wait(0)
                end
            
                TaskPlayAnim(
                    ped,
                    "weapons@first_person@aim_rng@generic@projectile@sticky_bomb@",
                    "plant_floor",
                    8.0,
                    -8.0,
                    600,
                    48,
                    0.0,
                    false,
                    false,
                    false
                )
            
                local camRot =
                    GetGameplayCamRot(2)

                local pitch =
                    math.rad(camRot.x)

                local yaw =
                    math.rad(camRot.z)

                local forward = vector3(
                    -math.sin(yaw) * math.cos(pitch),
                    math.cos(yaw) * math.cos(pitch),
                    math.sin(pitch)
                )

                local handCoords =
                    GetPedBoneCoords(
                        ped,
                        57005,
                        0.15,
                        0.0,
                        0.0
                    )
                
                local startCoords =
                    handCoords + (forward * 0.5)
            
                TriggerServerEvent(
                    'creatures:aetheriumBoltCast',
                    startCoords,
                    forward
                )
            
                lib.notify({
                    title = "Aetherium Bolt",
                    description = "Arcane energy surges forward.",
                    type = "success"
                })
            end
        },
        {
            name = "Concussive Blast",
            description = "Repel everyone nearby with magical force.",
            cooldown = 10,

            trigger = function()
            
                local ped = PlayerPedId()
                local coords = GetEntityCoords(ped)
            
                for _, playerId in ipairs(GetActivePlayers()) do
                
                    local targetPed = GetPlayerPed(playerId)
                
                    if targetPed ~= ped then
                    
                        local targetCoords = GetEntityCoords(targetPed)
                        local dist = #(coords - targetCoords)
                    
                        if dist <= 4.0 then
                        
                            local direction = targetCoords - coords
                            local length = #direction
                        
                            if length > 0.0 then
                            
                                direction = direction / length
                            
                                TriggerServerEvent(
                                    'creatures:dragonGustHit',
                                    GetPlayerServerId(playerId),
                                    direction
                                )
                            end
                        end
                    end
                end
            
                ShakeGameplayCam(
                    "LARGE_EXPLOSION_SHAKE",
                    0.5
                )
            
                lib.notify({
                    title = "Concussive Blast",
                    description = "A wave of force erupts around you.",
                    type = "success"
                })
            end
        }
    }
}