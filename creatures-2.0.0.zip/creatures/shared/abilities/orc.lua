return {
    Passive = {
        {
            name = "Enrage",
            description = "Taking damage sends you into a rage, greatly increasing your melee power, jump distance, armor regeneration, and Aether generation.",
            tick = function()
            end
        }
    },

    Active = {}
}