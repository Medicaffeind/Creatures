return {

    Passive = {

        {
            name = "Aetherium Regeneration",
            description = "Magical energy slowly replenishes.",

            tick = (function()

                local lastRegen = 0

                return function()

                    local now = GetGameTimer()

                    if now - lastRegen < 5000 then
                        return
                    end

                    lastRegen = now

                    exports.creatures:AddAetherium(5)
                end
            end)()
        },
        {
            name = "Toughness",
            description = "A supernatural barrier absorbs damage after your armor is depleted.",
            tick = function()
            end
        }
    },

    Active = {
        {
            name = "Self Mend",
            description = "Remove negative effects.",
            cooldown = 10,

            trigger = function()
                local playerData = exports.qbx_core:GetPlayerData()
                if not playerData or not playerData.metadata then
                    return
                end

                TriggerServerEvent('creatures:server:selfMend')
            end
        },
    },
}