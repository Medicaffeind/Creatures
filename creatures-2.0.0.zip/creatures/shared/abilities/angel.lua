return {

    Passive = {

        {
            name = "Calming Presence",
            description = "Your presence brings peace to nearby mortals.",

            tick = (function()

                local lastStress = 0
                return function()

                    local now = GetGameTimer()

                    if now - lastStress < 5000 then
                        return
                    end

                    lastStress = now

                    local ped = PlayerPedId()
                    local coords = GetEntityCoords(ped)

                    for _, playerId in ipairs(GetActivePlayers()) do

                        local targetPed = GetPlayerPed(playerId)

                        if targetPed ~= ped then

                            local dist =
                                #(coords - GetEntityCoords(targetPed))

                            if dist <= 10.0 then

                                TriggerServerEvent(
                                    'creatures:angelDestress',
                                    GetPlayerServerId(playerId)
                                )
                            end
                        end
                    end
                end
            end)()
        },
        {
            name = "Toughness",
            description = "A supernatural barrier absorbs damage after your armor is depleted.",
            tick = function()
            end
        }
    },

    Active = {

       {
            name = "Sanctuary",
            description = "Create a holy sanctuary that protects those within from harm.",
            cooldown = 60,

            trigger = function()

                local playerData =
                    exports.qbx_core:GetPlayerData()

                local race =
                    playerData.metadata.creatureRace

                if race ~= 'angel' then
                    return
                end

                TriggerServerEvent(
                    'creatures:server:angelSanctuary'
                )
            end
        },
        {
            name = "Divine Smite",
            description = "Call down a devastating beam of divine light upon your target.",
            cooldown = 0,

            trigger = function()

                local playerData =
                    exports.qbx_core:GetPlayerData()

                local race =
                    playerData.metadata.creatureRace

                if race ~= 'angel' then
                    return
                end

                local ped =
                    PlayerPedId()

                local camCoords =
                    GetGameplayCamCoord()

                local camRot =
                    GetGameplayCamRot(2)

                local direction =
                    vector3(
                        -math.sin(math.rad(camRot.z)) *
                            math.abs(
                                math.cos(
                                    math.rad(camRot.x)
                                )
                            ),

                        math.cos(math.rad(camRot.z)) *
                            math.abs(
                                math.cos(
                                    math.rad(camRot.x)
                                )
                            ),

                        math.sin(
                            math.rad(camRot.x)
                        )
                    )

                local destination =
                    camCoords +
                    (direction * 1000.0)

                local rayHandle =
                    StartShapeTestRay(
                        camCoords.x,
                        camCoords.y,
                        camCoords.z,
                        destination.x,
                        destination.y,
                        destination.z,
                        -1,
                        ped,
                        0
                    )

                local _, hit, endCoords =
                    GetShapeTestResult(
                        rayHandle
                    )

                if not hit then
                    return
                end

                TriggerServerEvent(
                    'creatures:server:angelDivineSmite',
                    endCoords
                )
            end
        },
        {
            name = "Divine Touch",
            description = "Divine grace mends the wounds of those you bless.",
            cooldown = 10,

            trigger = function()

                local playerData = exports.qbx_core:GetPlayerData()
                local race = playerData.metadata.creatureRace

                if race ~= 'angel' then
                    return
                end

                TriggerServerEvent(
                    'creatures:server:angelDivineTouch'
                )
            end
        },
    }
}