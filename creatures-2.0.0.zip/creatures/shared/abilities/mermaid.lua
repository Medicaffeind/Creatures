return {
    Passive = {
        {
            name = "Aetherium Regeneration",
            description = "Magical energy slowly replenishes.",

            tick = (function()

                local lastRegen = 0

                return function()

                    local now = GetGameTimer()

                    if now - lastRegen < 5000 then
                        return
                    end

                    lastRegen = now

                    exports.creatures:AddAetherium(5)
                end
            end)()
        },
        {
            name = "Aquatic Regeneration",
            description = "Regenerate health while submerged in water.",

            tick = (function()

                local lastRegen = 0

                return function()

                    local ped = PlayerPedId()

                    if IsEntityDead(ped) then
                        return
                    end

                    if not IsEntityInWater(ped) then
                        return
                    end

                    local now = GetGameTimer()

                    if now - lastRegen < 3000 then
                        return
                    end

                    lastRegen = now

                    local health = GetEntityHealth(ped)
                    local maxHealth = GetEntityMaxHealth(ped)

                    if health < maxHealth then
                        SetEntityHealth(
                            ped,
                            math.min(health + 5, maxHealth)
                        )
                    end
                end

            end)()
        },
        {
            name = "Aquatic Grace",
            description = "Move through water with supernatural speed.",

            tick = function()

                local ped = PlayerPedId()

                if IsEntityInWater(ped) then
                    SetSwimMultiplierForPlayer(PlayerId(), 1.75)
                else
                    SetSwimMultiplierForPlayer(PlayerId(), 1.0)
                end
            end
        },
        {
            name = "Waterborn",
            description = "Breathe freely beneath the surface.",

            tick = function()

                local ped = PlayerPedId()

                if IsEntityInWater(ped) then
                    SetPedDiesInWater(ped, false)
                    SetPedMaxTimeUnderwater(ped, 9999.0)
                end
            end
        },
        {
            name = "Call of the Deep",
            description = "The creatures of the sea recognize you as one of their own.",

            tick = (function()

                local lastCheck = 0
                local friendlyCreatures = {}

                return function()

                    local now = GetGameTimer()

                    if now - lastCheck < 2000 then
                        return
                    end

                    lastCheck = now

                    local ped = PlayerPedId()

                    if not DoesEntityExist(ped) or IsEntityDead(ped) then
                        return
                    end

                    local coords = GetEntityCoords(ped)

                    for _, creature in ipairs(GetGamePool("CPed")) do

                        if DoesEntityExist(creature)
                        and creature ~= ped
                        and not IsEntityDead(creature) then

                            local model = GetEntityModel(creature)
                            local isAquatic = false

                            for _, aquaticModel in ipairs(Config.AquaticCreatures or {}) do

                                if model == aquaticModel then
                                    isAquatic = true
                                    break
                                end

                            end

                            if isAquatic then

                                local creatureCoords =
                                    GetEntityCoords(creature)

                                local distance =
                                    #(coords - creatureCoords)

                                if distance <= 30.0 then

                                    if not friendlyCreatures[creature] then

                                        -- Store the creature's original relationship
                                        friendlyCreatures[creature] = {
                                            relationship =
                                                GetPedRelationshipGroupHash(creature)
                                        }

                                        SetRelationshipBetweenGroups(
                                            1,
                                            GetPedRelationshipGroupHash(creature),
                                            joaat('PLAYER')
                                        )

                                        SetRelationshipBetweenGroups(
                                            1,
                                            joaat('PLAYER'),
                                            GetPedRelationshipGroupHash(creature)
                                        )

                                        SetBlockingOfNonTemporaryEvents(
                                            creature,
                                            false
                                        )

                                        if Config.Debug then
                                            print(
                                                ('[Creatures Mermaid] Aquatic creature befriended: %s | Distance: %.1f')
                                                :format(
                                                    creature,
                                                    distance
                                                )
                                            )
                                        end

                                    end

                                elseif friendlyCreatures[creature] then

                                    local original =
                                        friendlyCreatures[creature]

                                    if original.relationship then

                                        SetRelationshipBetweenGroups(
                                            5,
                                            original.relationship,
                                            joaat('PLAYER')
                                        )

                                        SetRelationshipBetweenGroups(
                                            5,
                                            joaat('PLAYER'),
                                            original.relationship
                                        )

                                    end

                                    friendlyCreatures[creature] = nil

                                    if Config.Debug then
                                        print(
                                            '[Creatures Mermaid] Aquatic creature relationship restored.'
                                        )
                                    end
                                end
                            end
                        end
                    end

                    for creature in pairs(friendlyCreatures) do

                        if not DoesEntityExist(creature) then
                            friendlyCreatures[creature] = nil
                        end
                    end
                end
            end)()
        },
        {
            name = "Toughness",
            description = "A supernatural barrier absorbs damage after your armor is depleted.",
            tick = function()
            end
        }
    },
    Active = {

        {
            name = "Hydro Spear",
            description = "Launch a devastating spear of water at your target.",
            cooldown = 7,

            trigger = function()

                local AETHERIUM_COST = 25

                if not exports.creatures:RemoveAetherium(AETHERIUM_COST) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })

                end

                local ped = PlayerPedId()
                local coords = GetEntityCoords(ped)

                local cameraRotation = GetGameplayCamRot(2)

                local pitch = math.rad(cameraRotation.x)
                local yaw = math.rad(cameraRotation.z)

                local direction = vector3(
                    -math.sin(yaw) * math.cos(pitch),
                    math.cos(yaw) * math.cos(pitch),
                    math.sin(pitch)
                )

                TriggerServerEvent(
                    "creatures:hydroSpear",
                    coords,
                    direction
                )
            end
        }
    }
}