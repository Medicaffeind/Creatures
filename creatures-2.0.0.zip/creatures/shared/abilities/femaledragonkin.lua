return {
    Passive = {
            {
            name = "Aetherium Regeneration",
            description = "Magical energy slowly replenishes.",

            tick = (function()

                local lastRegen = 0

                return function()

                    local now = GetGameTimer()

                    if now - lastRegen < 5000 then
                        return
                    end

                    lastRegen = now

                    exports.creatures:AddAetherium(5)
                end
            end)()
        },
        {
            name = "Elemental Resilience",
            description = "Natural resistance to fire and explosions.",

            tick = function()
            
                local ped = PlayerPedId()
            
                SetEntityProofs(
                    ped,
                    false, -- bullets
                    true,  -- fire
                    true,  -- explosion
                    false,
                    false,
                    false,
                    false,
                    false
                )
            end
        },
        {
            name = "Toughness",
            description = "A supernatural barrier absorbs damage after your armor is depleted.",
            tick = function()
            end
        }
    },

    Active = {
       {
            name = "Fire Breath",
            description = "Unleash the dragonfire.",
            cooldown = 300,

            trigger = function()

                if not exports.creatures:RemoveAetherium(30) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })
                end
            
                local ped = PlayerPedId()
            
                local coords = GetEntityCoords(ped)
                local forward = GetEntityForwardVector(ped)
            
                TriggerServerEvent(
                    'creatures:dragonFireBreath',
                    coords,
                    forward
                )
            
                lib.notify({
                    title = "Fire Breath",
                    description = "Flames erupt from your maw.",
                    type = "success"
                })
            end
        },
        {
            name = "Gust",
            description = "Create a powerful gust",
            cooldown = 10,

            trigger = function()

                if not exports.creatures:RemoveAetherium(30) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })
                end
            
                local ped = PlayerPedId()
                local coords = GetEntityCoords(ped)
            
                for _, playerId in ipairs(GetActivePlayers()) do
                
                    local targetPed = GetPlayerPed(playerId)
                
                    if targetPed ~= ped then
                    
                        local targetCoords = GetEntityCoords(targetPed)
                        local dist = #(coords - targetCoords)
                    
                        if dist <= 8.0 then
                        
                            local direction = targetCoords - coords
                            local length = #direction
                        
                            if length > 0.0 then
                            
                                direction = direction / length
                            
                                TriggerServerEvent(
                                    'creatures:dragonGustHit',
                                    GetPlayerServerId(playerId),
                                    direction
                                )
                            end
                        end
                    end
                end
            
                ShakeGameplayCam(
                    "LARGE_EXPLOSION_SHAKE",
                    0.5
                )
            
                lib.notify({
                    title = "Wing Gust",
                    description = "A powerful gust erupts outward.",
                    type = "success"
                })
            end
        }
    }
}