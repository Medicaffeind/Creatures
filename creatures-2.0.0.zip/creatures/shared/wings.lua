Config = Config or {}

-- Optional adapters. Enable only after installing the corresponding pack.
Config.Wings = {
    enabled = true,
    flightResource = 'MathStoreFly',
    noFlyResource = false, -- Optional resource exporting CanStartFlight().
    dampenerResource = false, -- Optional resource exporting IsInsideAetherDampener().
    kitsuneEnabled = false,
    mothEnabled = false,
}

Config.FlightSpeeds = {
    command = 'flightspeed',
    cycleKey = 'K',

    -- Race tier 0-1: speed 1, tier 2-3: speed 2, tier 4-5: speed 3.
    unlockTier = {
        [1] = 0,
        [2] = 2,
        [3] = 4,
    },

    -- MathStore numbering runs in reverse: preset 3 is slowest and preset 1
    -- is fastest. Player-facing levels remain intuitive from 1 through 3.
    levels = {
        [1] = 3,
        [2] = 2,
        [3] = 1,
    },

    races = {
        'fae', 'malefae', 'femalefae',
        'demon', 'maledemon', 'femaledemon',
        'angel', 'maleangel', 'femaleangel',
        'maledragonkin', 'femaledragonkin',
        'malevampire', 'femalevampire',
    },
}

-- Wing ownership is intentionally separate from general flight eligibility.
Config.WingRaceAccess = {
    demon_new = {
        'demon', 'maledemon', 'femaledemon',
    },
    fae_new = {
        'fae', 'malefae', 'femalefae',
    },
    seraphim_new = {
        'angel', 'maleangel', 'femaleangel',
    },
    demon_legacy = {
        'malevampire', 'femalevampire',
        'maledragonkin', 'femaledragonkin',
    },
}


-- Maximum tail count by creature tier; smaller unlocked sets remain usable.
Config.KitsuneTails = {
    resource = 'MathStoreKitsunev2',
    command = 'kitsune',
    races = { 'kitsune' },
    tailsByTier = { [0] = 1, [1] = 1, [2] = 3, [3] = 3, [4] = 5, [5] = 9 },
    stylesByCount = { [1] = 15, [3] = 13, [5] = 13, [9] = 13 },
    nolis = {
        colors = 15,
        animations = 23,
        tailsByTier = { [0] = 1, [1] = 1, [2] = 3, [3] = 5, [4] = 7, [5] = 9 },
        -- Model suffix = prefix followed by color, e.g. 314 is 3 tails/color 14.
        packs = {
            alltails = { [1] = '10', [3] = '3', [5] = '5', [7] = '7', [9] = '' },
            ninetails = { [1] = '10', [3] = '3', [5] = '5', [7] = '7', [9] = '' },
        },
    },
}
