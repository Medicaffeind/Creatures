Config = {}

-- General Settings
Config.Debug = false
-- Qbox is required; this resource uses qbx_core directly.
Config.AdminAce = 'creatures.admin'

-- Define Races & Forms
Config.Races = {
    malevampire = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "Fledgling",
            [1] = "Blooded",
            [2] = "Nightborn",
            [3] = "Elder",
            [4] = "Ancient",
            [5] = "Primordial"
        }
    },
    femalevampire = {
        transformModel = 'mp_f_freemode_01',
        eldertransformModel = 'mp_f_freemode_01',
        mutateModel = 'mp_f_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "Fledgling",
            [1] = "Blooded",
            [2] = "Nightborn",
            [3] = "Elder",
            [4] = "Ancient",
            [5] = "Primordial"
        }
    },
    malewerewolf = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = " New Moon",
            [1] = "Crescent Moon",
            [2] = "Half Moon",
            [3] = "Gibbous Moon",
            [4] = "Full Moon",
            [5] = "Elder"
        }
    },
    femalewerewolf = {
        transformModel = 'mp_f_freemode_01',
        eldertransformModel = 'mp_f_freemode_01',
        mutateModel = 'mp_f_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = " New Moon",
            [1] = "Crescent Moon",
            [2] = "Half Moon",
            [3] = "Gibbous Moon",
            [4] = "Full Moon",
            [5] = "Elder"
        }
    },
    demon = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "Descended",
            [1] = "Shadow",
            [2] = "Thread",
            [3] = "Demon",
            [4] = "Disaster",
            [5] = "Elder"
        }
    },
    angel = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',

        toughness = 100,

        Sanctuary = {
            Radius = 5.0,
            Duration = 20,
            AetherCost = 25
        },

        DivineSmite = {
            Radius = 2.0,
            EffectRadius = 30.0,
            Duration = 6,
            AetherCost = 20,

            Damage = 5,
            TickInterval = 1000,

            DamageMultiplier = 1.25,
            MaxDamageMultiplier = 5.0
        },

        DivineTouch = {

            [0] = {
                AetherCost = 10,

                RandomInjury = true,

                Limbs = {
                    'head',
                    'torso',
                    'left_arm',
                    'right_arm',
                    'left_leg',
                    'right_leg'
                }
            },

            [1] = {
                AetherCost = 15,

                Injuries = {
                    'cut'
                },

                LimbHealth = 25
            },

            [2] = {
                AetherCost = 20,

                Injuries = {
                    'cut',
                    'blunt'
                },

                LimbHealth = 50
            },

            [3] = {
                AetherCost = 25,

                Injuries = {
                    'cut',
                    'blunt',
                    'burn'
                },

                LimbHealth = 75
            },

            [4] = {
                AetherCost = 30,

                Injuries = {
                    'cut',
                    'blunt',
                    'burn',
                    'fist',
                    'taser'
                },

                LimbHealth = 100
            },

            [5] = {
                AetherCost = 40,

                FullHeal = true
            }
        },

        Tiers = {
            [0] = "Awakened",
            [1] = "Ascendant",
            [2] = "Seraph",
            [3] = "Archon",
            [4] = "Elder",
            [5] = "Original"
        }
    },
    maledragonkin = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "Runt",
            [1] = "Wyrmling",
            [2] = "Drake",
            [3] = "Archdrake",
            [4] = "Drakon",
            [5] = "Elder"
        }
    },
    femaledragonkin = {
        transformModel = 'mp_f_freemode_01',
        eldertransformModel = 'mp_f_freemode_01',
        mutateModel = 'mp_f_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "Runt",
            [1] = "Wyrmling",
            [2] = "Drake",
            [3] = "Archdrake",
            [4] = "Drakon",
            [5] = "Elder"
        }
    },
    fae = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "Wisp",
            [1] = "Sprite",
            [2] = "Pixie",
            [3] = "Feykin",
            [4] = "Wildling",
            [5] = "Archfey"
        }
    },
    elf = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 1000,
        Tiers = {
            [0] = "Innate",
            [1] = "Aether Woven",
            [2] = "Refined",
            [3] = "Noble",
            [4] = "High Elf",
            [5] = "Keepers"
        }
    },
    maledwarf = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "set",
            [1] = "set",
            [2] = "set",
            [3] = "set",
            [4] = "set",
            [5] = "set"
        }
    },
    femaledwarf = {
        transformModel = 'mp_f_freemode_01',
        eldertransformModel = 'mp_f_freemode_01',
        mutateModel = 'mp_f_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "set",
            [1] = "set",
            [2] = "set",
            [3] = "set",
            [4] = "set",
            [5] = "set"
        }
    },
    satyr = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "set",
            [1] = "set",
            [2] = "set",
            [3] = "set",
            [4] = "set",
            [5] = "set"
        }
    },
    kitsune = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',

        toughness = 100,

        Dash = {
            AetherCost = 10,
            Speed = 35.0,
            FireDuration = 400,
            EffectRadius = 100.0
        },

        FoxFire = {
            AetherCost = 2,
            DisperseTime = 10,
            MaxOrbs = 10,
            Height = 1,
            OrbRadius = 0.325,
            LightRange = 4.0,
            EffectRadius = 100.0
        },

        Tiers = {
            [0] = "set",
            [1] = "set",
            [2] = "set",
            [3] = "set",
            [4] = "set",
            [5] = "set"
        }
    },
    mermaid = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "Shore Born",
            [1] = "Tide Walker",
            [2] = "Wave Drifter",
            [3] = "The Deep",
            [4] = "The Storm",
            [5] = "The Flood"
        }
    },
    orc = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 1000,
        Enrage = {
            BaseDuration = 10,
            DurationPerTier = 10,
            MaxDuration = 60,

            MeleeMultiplier = 3.0,
            JumpMultiplier = 6.0,
            ArmorRegen = 5,
            AetherPerSecond = 5
        },
        Tiers = {
            [0] = "Whelp",
            [1] = "Raider",
            [2] = "Bloodfang",
            [3] = "Warbringer",
            [4] = "Warchief",
            [5] = "set"
        }
    },
    maleursar = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "Cub",
            [1] = "Tracker",
            [2] = "Mauler",
            [3] = "Guardian",
            [4] = "Kodiak",
            [5] = "Ursa Major"
        }
    },
    femaleursar = {
        transformModel = 'mp_f_freemode_01',
        eldertransformModel = 'mp_f_freemode_01',
        mutateModel = 'mp_f_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "Cub",
            [1] = "Tracker",
            [2] = "Mauler",
            [3] = "Guardian",
            [4] = "Kodiak",
            [5] = "Ursa Major"
        }
    },
    witch = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "Unwoven",
            [1] = "Neophyte",
            [2] = "Practitioner",
            [3] = "Enchanter",
            [4] = "Soverign",
            [5] = "Crone"
        }
    },
    warlock = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "Vessel",
            [1] = "Novice",
            [2] = "Adept",
            [3] = "Arcanist",
            [4] = "Prime",
            [5] = "Archon"
        }
    },
    lunarowl = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "Moonfeather",
            [1] = "Duskwing",
            [2] = "Nightwatcher",
            [3] = "Eclipse Talon",
            [4] = "Moonseer",
            [5] = "Lunar Sovereign"
        }
    },
    werecatfemale = {
        transformModel = 'mp_f_freemode_01',
        eldertransformModel = 'mp_f_freemode_01',
        mutateModel = 'mp_f_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "Kitling",
            [1] = "Prowler",
            [2] = "Stalker",
            [3] = "Shadowclaw",
            [4] = "Pridekeeper",
            [5] = "Pridemarch"
        }
    },   
    werecatmale = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "Kitling",
            [1] = "Prowler",
            [2] = "Stalker",
            [3] = "Shadowclaw",
            [4] = "Pridekeeper",
            [5] = "Pridemarch"
        }
    },     
    ravenfolk = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 100,
        Tiers = {
            [0] = "Fledgling",
            [1] = "Dusk Feather",
            [2] = "Nightcaller",
            [3] = "Dreadtalon",
            [4] = "Omenkeeper",
            [5] = "Corvus Sovereign"
        }
    },      
    bossmob = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 10000,

        SelfMend = {
            AetherCost = 50
        },

        Tiers = {
            [0] = "set",
            [1] = "set",
            [2] = "set",
            [3] = "set",
            [4] = "set",
            [5] = "set"
        }
    },

    standardmob = {
        transformModel = 'mp_m_freemode_01',
        eldertransformModel = 'mp_m_freemode_01',
        mutateModel = 'mp_m_freemode_01',
        toughness = 1000,

        SelfMend = {
            AetherCost = 100
        },

        Tiers = {
            [0] = "set",
            [1] = "set",
            [2] = "set",
            [3] = "set",
            [4] = "set",
            [5] = "set"
        }
    },
}


-- VFX Settings
Config.VFX = {
    EnableScreenFade = true,
    EnableSound = true,
    EnableParticles = true,
    ParticleAsset = "scr_rcbarry2",
    ParticleEffect = "scr_clown_appears",
    TransformSound = "CHARACTER_SELECT",
    MutateSound = "HUD_MINI_GAME_SOUNDSET",
    RevertSound = "DELETE"
}

Config.AbilitySettings = {
    EnablePassiveChecks = true,      -- Automatically loop to apply passive effects
    PassiveCheckInterval = 5000,     -- (ms) how often passives are checked
    KeybindDisplay = true,           -- Show keybinds on screen for active abilities
    NotifyOnUse = true,              -- Notify player when ability is used
    NotifyOnCooldown = true,         -- Notify if trying to use ability on cooldown
    CooldownNotifyStyle = "ox_lib",  -- options: "ox_lib", "chat", "none"
}
-- Activate or deactive Vehicle Tint Protection
Config.VehicleTintProtection = {
    enabled = true,
    -- 0=None, 1=PureBlack, 2=DarkSmoke, 3=LightSmoke, 4=Stock, 5=Limo, 6=Green
    safeTints = { 1, 5 } -- treat PureBlack and Limo as sun-safe
}
Config.SunProtectionItem = {
    femalevampire = {
        "sun_amulet",
    },
    malevampire = {
        "sun_ring",
    }
}

Config.UmbrellaProtection = {
    enabled = true,
    anims = { { dict = "rcmnigel1d", name = "base_club_shoulder" } },
    props = { "p_amb_brolly_01", "umbrella01" }
}

Config.ActiveHours = { start = 6.0, finish = 20.0 }

Config.ActiveWeather = { "EXTRASUNNY", "CLEAR" }

Config.SunDamage = {
    interval = 5000, -- ms
    damage = {
        [0] = 5,
        [1] = 7,
        [2] = 9,
        [3] = 11,
        [4] = 13,
        [5] = 15,
    },
}

Config.AquaticCreatures = {
    joaat('a_c_sharkhammer'),
    joaat('a_c_sharktiger'),
    joaat('a_c_stingray'),
    joaat('a_c_dolphin'),
    joaat('a_c_fish')
}
Config.AbilityKey = 'Z'

Config.AbilityCycleKey = 'X'
