Config.Howl = {
    Enabled = true,
    Command = 'howl',
    -- Supply recordings you have permission to use. Paths are relative to this
    -- resource, e.g. 'sounds/wolf_howl1.ogg'. HTTPS URLs require CORS.
    -- Third-party recordings are not distributed with this repository.
    SoundUrls = {},
    Range = 2000.0,
    Volume = 0.9,
    DurationMs = 15000,
    CooldownSeconds = 20 * 60,
    UpdateMs = 250,
    ListenerBuffer = 250.0,
    GpsPrompt = true,
    AllowedRaces = { malewerewolf = true, femalewerewolf = true },
}

