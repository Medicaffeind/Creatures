# Validation

## Offline checks

Install Python 3 with `lupa` (Lua 5.4), and Node.js. These are development-only dependencies; the FiveM server does not need them.

```sh
python -m pip install lupa
python tests/check_resource.py
node tests/audio.test.cjs
```

The Python checks compile every Lua file, load the combined server with mocked FiveM/Qbox APIs, check unique registration, verify freemode defaults, exercise staff permissions and form saves, test flight/tail access, validate representative ability guards, and test howl range/routing/cooldown/GPS delivery. The Node checks exercise the audio mixer with a mocked AudioContext, including late fetch cancellation and error cleanup.

These checks do not execute GTA natives, verify actual audio output, or load proprietary packs.

## In-game acceptance checklist

Use a staging server with at least two clients and your final dependency versions.

- Confirm startup has no missing script/export errors. Test core startup without optional wing/medical packs.
- Check that ordinary players cannot run the four staff commands, while intended ACE staff can. Reject a fractional or out-of-range tier.
- Assign male and female races. Transform and mutate, save distinct appearances, revert, reconnect, and repeat. Confirm all default models are freemode and the normal saved skin is preserved.
- Change tier to 5 and confirm elder transformation uses the configured model. Try an invalid model in staging and confirm a notification instead of an indefinite loading loop.
- For werewolves, verify form-gated abilities in transform, mutate, and reverted states. The new defaults use form state rather than proprietary model hashes.
- Exercise representative abilities, Aetherium depletion/regeneration, and toughness. Try race changes and character unload while effects are active.
- Configure real howl clips. Test a werewolf and non-werewolf requester, repeated requests, stereo camera rotation, source motion, simultaneous wolves, 1 km/2 km distances, the listener buffer, separate routing buckets, disconnects, and resource restart.
- With two werewolves, verify Yes sets the original howl location, No preserves the old waypoint, and out-of-range/non-werewolf clients receive no GPS prompt.
- Start the configured flight engine. Test speed limits at every tier, wrong-race wing sets, downgrades during flight, landing/deactivation, logout, no-flight zones, and resource restart.
- If enabled, test tail/ear model loading, race/tier changes, pack restart, and removal. Test moth equip, colors, flight, landing, and cleanup with the required bridge installed.
- Verify dependency-specific healing and your door-breach hook only if those integrations are configured.

Record actual server/dependency versions and results when preparing a release. Offline success alone is not an in-game acceptance result.
