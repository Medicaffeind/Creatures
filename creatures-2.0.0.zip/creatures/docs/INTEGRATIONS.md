# Integrations

## Illenium Appearance

The combined resource uses `startPlayerCustomization(callback, config)` directly, disables ped-model selection, and saves the returned appearance to `creatureForms`. `setPedAppearance` applies it; `illenium-appearance:client:reloadSkin` restores the normal saved appearance.

Remove the old forced-clothing-menu patch if you installed it solely for Creatures. Preserve other custom changes in your appearance resource. No `ForceClothMenu` export is required by this version.

## Flight engine and wing packs

The engine must implement these local client events:

| Event | Contract |
| --- | --- |
| `flight:activateWithPresetNoBucketCheck` | Accept a numeric engine preset; defaults map speed 1/2/3 to preset 3/2/1 |
| `flight:deactivate` | End flight; Creatures listens to it to clear its active state |

Set `Config.Wings.flightResource` to the engine's actual resource name (default `MathStoreFly`). The engine and models are external dependencies, not included in this repository. Ensure the engine and desired packs are started before using their controls. Do not make the engine depend on Creatures if you also add it as an Creatures manifest dependency; that creates a dependency cycle.

Use `/wingflight [wingSet] [speed]` for the generic Creatures control, or connect the pack's equip/fly command to the following pattern:

```lua
local allowed = lib.callback.await(
    'creatures:server:canUseWingSet', false, 'fae_new'
)
if not allowed then return end

-- Equip the wing mesh through your pack's own supported API here.
local level = exports.creatures:GetSelectedFlightSpeed()
local ok, preset = exports.creatures:SetFlightSpeed(level, true, false)
if ok then exports.creatures:ActivateFlight(preset) end
```

The final `false` avoids starting flight twice when choosing a speed immediately before activation. Stop with `TriggerEvent('flight:deactivate')`. When the engine lands or cancels flight, it should emit that deactivation event so Creatures does not retain a stale active state.

`ActivateFlight` checks the configured engine, current race/tier access, and optional no-flight restrictions. Race checks must also be applied to a pack's equip command. An unrestricted vendor command or direct vendor event can bypass this adapter; disable it or integrate the access check at the actual vendor entry point.

Legacy vendor commands such as `/fwings`, `/dwings`, `/swings`, `/demonwingsfly`, and `/fairywingsfly` belong to their packs and are not installed by Creatures. Their availability and arguments depend on that pack version.

## MathStore kitsune tails

Set `Config.Wings.kitsuneEnabled = true` after installing the resource configured by `Config.KitsuneTails.resource` (default `MathStoreKitsunev2`). The adapter uses `mathstore:spawnKitsune`, `mathstore:removeKitsune`, and `mathstore:triggerLimpeza` from that pack.

| Command | Action |
| --- | --- |
| `/kitsune [style]` | Equip the maximum tail count unlocked at your tier |
| `/mtskit1 [style]` | Equip one tail |
| `/mtskit3 [style]` | Equip three tails, if unlocked |
| `/mtskit5 [style]` | Equip five tails, if unlocked |
| `/mtskit9 [style]` | Equip nine tails, if unlocked |
| `/rkits` | Remove tails |

Default maximum counts at tiers 0â€“5 are **1, 1, 3, 3, 5, 9**. Style ranges are 1â€“15 for one tail and 1â€“13 for larger sets. The adapter re-registers these command handlers after the vendor starts, but this is not an authorization boundary for unrestricted vendor network events. Tail access refreshes every five seconds and removes/downgrades a set after a race/tier change.

## Nolis tail and fox-ear adapters

These scripts are stored in Creatures but execute inside the corresponding asset pack, which owns its entities. Disable that pack's original unrestricted client command script before loading the adapter.

For `alltails` or `ninetails`, retain the pack's model/animation definitions and use:

```lua
shared_scripts {
    '@ox_lib/init.lua',
    '@creatures/shared/wings.lua',
}
client_script '@creatures/integrations/nolis_client.lua'
dependencies { 'ox_lib', 'creatures' }
```

`ninetails` also needs `alltails` for its lower-count models. The server tail-access callbacks are enabled by `Config.Wings.kitsuneEnabled`; enable this for Nolis tails/ears as well. The MathStore pack itself is not required for Nolis, although its commands will also be registered and report unavailable if used without it.

Commands: `/alltails [color 1-15] [animation 1-23]`, `/ninetails [color 1-15] [animation 1-23]`. Remove with `/alltailsx` or `/ninetailsx`. The Nolis tier progression is **1, 1, 3, 5, 7, 9** tails. The player chooses color/animation; tier chooses count.

For `foxear`, retain asset definitions and load:

```lua
shared_script '@ox_lib/init.lua'
client_script '@creatures/integrations/foxear_client.lua'
dependencies { 'ox_lib', 'creatures' }
```

Commands: `/foxear [color 1-15] [animation 1-6]`, `/foxearx`. Ears require the kitsune race, without a tier requirement. Creatures assets, configuration, and callbacks must be available before these packs start.

## Moth wings

Set `Config.Wings.mothEnabled = true` only after installing `wls_mothwings` with the following bridge exports. Stock vendor versions may not provide them; the Creatures adapter cannot supply proprietary attachment internals.

| Side | Export | Contract |
| --- | --- | --- |
| Server | `RemoveBridgeMoth(playerId)` | Remove that player's wings; return success and optional error |
| Server | `EquipTierFiveMoth(playerId, model)` | Attach the validated model; return success and optional error |
| Client | `PlayBridgeAnimation(state)` | Play the requested moth animation state |

The client has an event fallback for animation, but attachment still requires the server exports. Implement these inside the pack's editable bridge using its supported attachment/animation functions, and do not expose an unrestricted replacement server event.

Only tier-5 fae (including configured male/female aliases) are allowed. `/moth [color]` equips; `/moth off` removes; `/mothfly` toggles flight. Colors: `default`, `blue`, `white`, `red`, `pink`, `green`, `grey`, `yellow`. Left Shift changes the animation while flying, not the flight-engine speed.

## Other optional hooks

- Set `Config.Wings.noFlyResource` to the name of a resource exporting `CanStartFlight()` to enforce its flight restrictions.
- Set `Config.Wings.dampenerResource` to the name of a resource exporting `IsInsideAetherDampener()` to enforce its dampening zones. Both optional resource settings default to `false`.
- `wasabi_ambulance_v2:ApplyHeal` and `getPlayerInjuryTotals` are used by Divine Touch and Self Mend. No medical-resource code is bundled.
- Werewolf door breach emits the local server event `creatures:server:breachDoor(playerId, door)` after its checks. Connect this to your door system if desired. No universal door-lock adapter is included. Blood-moon gating uses `GlobalState.bloodMoon` and needs an external controller to set that state.
