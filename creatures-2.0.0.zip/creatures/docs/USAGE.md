# Creatures: full usage guide

**Supernatural roleplay for FiveM and Qbox.**

Creatures brings race progression, alternate appearances, active and passive abilities, directional werewolf howls, and tiered wing control into one resource.

Race abilities, werewolf howls, and wing controls are included in **one resource: `creatures`**.

## Features

- Persistent races, six progression tiers, and separate transform/mutation appearances.
- Race-specific abilities, Aetherium reserves, cooldowns, and toughness.
- Vampire sunlight weaknesses and configurable protection.
- Werewolf broadcast howls with distance-based volume, camera-relative stereo direction, and optional GPS prompts for nearby werewolves.
- Flight-speed progression, race-based wing access, and optional kitsune-tail and moth-wing adapters.
- ox_lib menus, notifications, dialogs, and rebindable ability controls.
- ACE-protected race/tier management and integration exports.

**All transformation, elder transformation, and mutation models default to GTA freemode peds.** Explicitly female race IDs use `mp_f_freemode_01`; other IDs use `mp_m_freemode_01`. Custom creature models are optional. These defaults provide customizable humanoid appearances, not animal-shaped models.

## Requirements

| Dependency | Used for |
| --- | --- |
| FiveM server with OneSync | Networked players and authoritative howl coordinates |
| `qbx_core` | Player data and metadata persistence |
| `ox_lib` | Menus, notifications, callbacks, and asset loading |
| `ox_inventory` | Sun-protection item checks |
| `illenium-appearance` | Standard customization exports and restoring the saved character skin |

This implementation targets **Qbox**. It does not include ESX, standalone, or direct QB-Core framework adapters. Install the dependencies and their own requirements first; Qbox's database setup still applies. Creatures has no additional SQL migration, npm build, or xSound requirement.

Optional integrations:

- A compatible MathStore-style flight engine and separately installed wing/clothing assets.
- MathStore kitsune tails, Nolis tail/ear packs, and a moth-wing pack with the documented bridge exports.
- `wasabi_ambulance_v2` for Divine Touch and mob Self Mend. These abilities report that they are unavailable when it is absent.
- Optional flight-blocking resources can be configured through `Config.Wings.noFlyResource` and `Config.Wings.dampenerResource`.

## Quick start

1. Put this folder in your server's resources directory, named **`creatures`**.
2. Start it after the dependencies. The following is the relevant portion of a server configuration; preserve the dependencies' own installation requirements:

   ```cfg
   ensure oxmysql
   ensure ox_lib
   ensure qbx_core
   ensure ox_inventory
   ensure illenium-appearance
   ensure creatures

   # Give only your intended staff group creature-management permission.
   add_ace group.admin creatures.admin allow
   ```

   `group.admin` must already contain the intended staff identifiers through your server's ACE setup. The permission name is configurable as `Config.AdminAce`.

3. In-game, as authorized staff, assign a race and tier:

   ```text
   /setrace 12 malewerewolf
   /settier 12 2
   ```

4. As that player, use `/transform`. The first use opens the appearance editor. Save the form, try `/mutate`, then `/revert` to restore the normal saved character appearance.
5. Press **X** to choose an ability and **Z** to use it. `/showtier` and `/mana` show progression and reserves.
6. To enable audible howls, add recordings and configure [shared/howl.lua](../shared/howl.lua) as described below. For flight, follow [the wing integration guide](../docs/INTEGRATIONS.md).

No Illenium source patch is needed. Creatures uses its `startPlayerCustomization` export with model selection disabled and saves form appearances into Qbox metadata.

## Commands

### Player commands

| Command | Usage |
| --- | --- |
| `/race` | Show your assigned race |
| `/showtier` | Show your tier name |
| `/raceform` | Open the transform/mutate/revert menu |
| `/transform` | Enter your transformation form; tier 5 uses the elder model |
| `/mutate` | Enter your mutation form |
| `/revert` | Return to your saved normal appearance |
| `/editform transform` | Customize your active transformation form |
| `/editform mutate` | Customize your active mutation form |
| `/mana` | Display Aetherium reserves |
| `/cycleAbility` | Select the next active ability |
| `/useAbility` | Use the selected ability |
| `/howl` | Request a broadcast howl as a male/female werewolf |
| `/flightspeed [1-3]` | Select an unlocked speed, or omit the number to cycle |
| `/wingflight [wingSet] [speed]` | Start the external flight engine for an allowed wing set; use again to stop |

Transforming or mutating costs **25 stamina**. Edit the currently active form so its appearance is saved to the correct slot. Appearance slots are per race and form; the elder transformation shares the transform slot.

Default key bindings: **Z** uses an ability, **X** cycles abilities, and **K** cycles flight speeds. Players can change these in FiveM's key-binding settings. Optional moth controls also map Left Shift to fast wing animation.

### Staff commands

| Command | Usage |
| --- | --- |
| `/setrace [playerId] [raceId]` | Assign a configured race |
| `/removerace [playerId]` | Clear a race |
| `/settier [playerId] [0-5]` | Assign an integer tier |
| `/removetier [playerId]` | Clear a tier |

These commands require `creatures.admin` ACE permission and an in-game player source. Race and tier are separate metadata fields: clearing or changing a race does not erase its saved appearances or automatically clear its tier. Use `/removetier` when resetting progression.

## Werewolf howls

Audio playback is built into this resource. **Recordings are not bundled.** Put audio you have permission to use in `sounds/`, then edit [shared/howl.lua](../shared/howl.lua):

```lua
Config.Howl = {
    Enabled = true,
    Command = 'howl',
    SoundUrls = {
        'sounds/wolf_howl1.ogg',
        'sounds/wolf_howl2.mp3',
    },
    Range = 2000.0,
    Volume = 0.9,
    DurationMs = 15000,
    CooldownSeconds = 20 * 60,
    UpdateMs = 250,
    ListenerBuffer = 250.0,
    GpsPrompt = true,
    AllowedRaces = { malewerewolf = true, femalewerewolf = true },
}
```

Use flat `.mp3`, `.ogg`, or `.wav` files in `sounds/`; those extensions are included in the manifest. HTTPS audio URLs also work if their server permits cross-origin fetching. Set `DurationMs` longer than the longest clip, at most 120000 ms. Restart `creatures` after configuration changes.

The server selects one clip for each howl and sends the same selection to listeners in the same routing bucket. Default source volume is 90%, falling linearly to 45% at 1 km and silence at 2 km. Direction follows the listener's camera; stereo output is needed to hear left/right placement.

Listeners within range plus the 250 m buffer at howl start receive the clip. Moving into hearing range from that buffer changes its volume. Players who arrive from outside the buffer do not join an already playing howl. The sound source follows the howler even beyond ped streaming range. Disconnects, routing-bucket changes, expiry, and resource stops clean up playback. Cooldowns reset on disconnect/restart.

Other werewolves inside the actual hearing radius receive a Yes/No GPS prompt. Yes sets a waypoint to the original howl location; No or timeout preserves the current waypoint. The howler and non-werewolves do not receive this prompt. The audio is stereo panning and distance attenuation, without terrain occlusion or full 3D/HRTF simulation.

The `/howl` broadcast is separate from the **Blood Howl** combat ability. Blood Howl retains its own ability cost, cooldown, and melee effect.

## Configuration and races

| File | Purpose |
| --- | --- |
| [shared/config.lua](../shared/config.lua) | Race models, tier labels, toughness, race-specific settings, sunlight, and controls |
| [shared/wings.lua](../shared/wings.lua) | Flight integration, wing ownership, tail progression, and optional adapter toggles |
| [shared/howl.lua](../shared/howl.lua) | Broadcast audio, range, cooldown, and eligible races |
| [shared/abilities](../shared/abilities) | Per-race passive and active ability modules |

See [the race and ability reference](../docs/RACES.md) for all configured IDs and their implemented abilities. A race entry can exist without an ability module. `bossmob` and `standardmob` are encounter-oriented presets with much higher toughness than player races; staff should assign them deliberately.

Default Aetherium maximum is 100, with base regeneration of 5 every 5 seconds. Some passives add regeneration. Costs and cooldowns live in each ability module; base reserve behavior lives in `client/client_aetherium.lua` and `server/server_aetherium.lua`.

Sun-protection items default to `sun_ring` and `sun_amulet`. Add matching items to ox_inventory or replace those names with items your server already defines. The item definitions and images are not bundled. Protection can also use configured umbrella animations/props and safe vehicle window tints.

## Flight and cosmetic packs

Wing controls are available by default; actual flight requires the separately installed engine configured by `Config.Wings.flightResource`. `/wingflight` starts movement and does not equip a wing model. Cosmetic packs own their wing meshes and equip events.

| Tier | Maximum speed | External preset |
| --- | --- | --- |
| 0â€“1 | 1 | 3 |
| 2â€“3 | 2 | 2 |
| 4â€“5 | 3 | 1 |

Wing-set IDs: `demon_new` for demons, `fae_new` for fae, `seraphim_new` for angels, and `demon_legacy` for vampires/dragonkin. Alias race names are listed in the wing configuration, but `/setrace` accepts only actual entries in `Config.Races`.

Example for a fae with a compatible engine started:

```text
/wingflight fae_new 1
/flightspeed 2
/wingflight
```

Speed 2 requires tier 2 or higher. See [INTEGRATIONS.md](../docs/INTEGRATIONS.md) for vendor hooks, kitsune commands, moth bridges, and optional no-flight integrations.

## Developer API

Server examples:

```lua
local race = exports.creatures:GetPlayerRace(source)
local allowed = exports.creatures:HasRequiredRace(source, { 'fae', 'elf' })
local progressed = exports.creatures:HasRequiredTier(source, { min = 2 })
```

Client examples:

```lua
exports.creatures:Howl()
local tier = exports.creatures:GetCurrentTier()
local form = exports.creatures:GetCurrentForm()
if exports.creatures:RemoveAetherium(20) then
    -- Your local ability effect.
end
```

See [API.md](../docs/API.md) for export signatures, callback contracts, ability module format, and persistence details.

## Upgrading from the separate resources

Follow [MIGRATION.md](../docs/MIGRATION.md). Stop/remove the old howl and wing-controller resources from your startup configuration, update references in other resources, and start only the combined `creatures`. Do not run both implementations at once.

## Troubleshooting and testing

| Symptom | Check |
| --- | --- |
| Staff commands say access denied | Staff ACE membership and `Config.AdminAce` |
| No howl audio | `SoundUrls`, actual file names, duration, and F8/NUI audio errors |
| Form editing fails | `illenium-appearance` is started and provides `startPlayerCustomization` |
| Old appearance does not apply | Its saved model differs from the new default; enter the form and use `/editform` |
| Missing abilities | A module exists for that race; check `[Creatures]` loader messages |
| Flight unavailable | Engine resource name, start state, race, tier, and no-flight restrictions |
| Moth or healing export missing | The documented optional vendor bridge/export must be installed |

Offline checks cover Lua syntax, server registration, permissions, form validation, tier access, howl delivery rules, and audio lifecycle. They do not replace multiplayer testing in FiveM. Run the checks and the [in-game test checklist](../docs/TESTING.md) before deployment.

Review [SECURITY.md](../SECURITY.md) for the inherited client/server trust boundary and [THIRD_PARTY.md](../THIRD_PARTY.md) for excluded assets and source credits. No license file is supplied with this repository.
