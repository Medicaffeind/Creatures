# Migrating to `creatures`

1. Back up the old creature, howl, and wing-controller resources, startup configuration, and player database.
2. Stop the old resources and remove their startup entries. Move obsolete folders outside any automatically started resource category.
3. Install the combined folder as **`creatures`** and start it with `ensure creatures` after its dependencies.
4. Merge your race, wing, and howl configuration into `shared/config.lua`, `shared/wings.lua`, and `shared/howl.lua`.
5. Change references in menus, abilities, and vendor bridges to the new API below. Legacy resource names and event aliases are not registered by this release.
6. Grant intended staff the **`creatures.admin`** ACE permission. Key mappings now use the new resource identifiers; players may need to reapply custom key bindings.
7. Configure licensed recordings using resource-relative paths such as `sounds/wolf_howl1.ogg`. Old resource-hosted URLs no longer work. Built-in audio replaces the customized xSound dependency.
8. Optional flight-blocking resources must be named explicitly in `Config.Wings.noFlyResource` / `Config.Wings.dampenerResource`; both default to false.
9. Follow the [testing checklist](TESTING.md) on a staging server before deployment.

## Integration references

| Integration | New reference |
| --- | --- |
| Resource name / dependency | `creatures` |
| Client howl export | `exports.creatures:Howl()` |
| Local howl event | `creatures:howl` |
| Flight exports | `exports.creatures:GetSelectedFlightSpeed()`, `SetFlightSpeed(...)`, `ActivateFlight(...)` |
| Creature and wing callbacks | `creatures:server:*` |
| Creature and wing client events | `creatures:client:*` |
| Fae effect events | `creatures_fae:*` |
| Vampire stumble event | `creatures:vampire:stumbleVictim` |
| Wing configuration import | `@creatures/shared/wings.lua` |
| Nolis adapter import | `@creatures/integrations/nolis_client.lua` |
| Fox-ear adapter import | `@creatures/integrations/foxear_client.lua` |

Consult [API.md](API.md) for exact export and callback signatures. Update custom ability event callers to match the implementations in this release.

## Appearance and persistence

All transform, elder-transform, and mutation models default to base freemode. A saved appearance tied to an old model is skipped; enter the form and use `/editform transform` or `/editform mutate` to save a replacement. Existing metadata is not deleted.

The `creatureRace`, `creatureTier`, `creatureForms`, and `aetherium` metadata keys remain unchanged. No database migration is required. The normal character appearance remains separate from creature forms. The standard Illenium customization export replaces the old forced-clothing-menu patch.

Rollback by stopping `creatures` and restoring the backed-up resources, startup entries, and integration references. Preserve a database backup to recover any appearances edited during testing.
