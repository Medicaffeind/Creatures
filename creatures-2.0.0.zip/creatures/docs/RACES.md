# Race and ability reference

Race IDs are case-sensitive. Use these IDs with `/setrace`. Every configured race has tiers 0–5; labels, toughness, and models are editable in [shared/config.lua](../shared/config.lua).

| Race ID | Active abilities supplied |
| --- | --- |
| `malevampire` | Blood Dash, Mist Form, Feed |
| `femalevampire` | Blood Dash, Mist Form, Feed |
| `malewerewolf` | Blood Howl, Lupine Leap, Blood Moon Breach, Feral Rend, Predator's Sight |
| `femalewerewolf` | Blood Howl, Lupine Leap, Blood Moon Breach, Feral Rend, Predator's Sight |
| `demon` | Veil, Dissipate, Suppression |
| `angel` | Sanctuary, Divine Smite, Divine Touch |
| `maledragonkin` | Fire Breath, Gust |
| `femaledragonkin` | Fire Breath, Gust |
| `fae` | Glamour, Mischief, Fairy Dust |
| `elf` | Healing Rain, Root |
| `maledwarf` | Passives only |
| `femaledwarf` | Passives only |
| `satyr` | No ability module supplied |
| `kitsune` | Kitsune Dash, Fox Fire |
| `mermaid` | Hydro Spear |
| `orc` | Passives only |
| `maleursar` | Maul, Roar |
| `femaleursar` | Maul, Roar |
| `witch` | Aetherium Shield, Aetherium Bolt, Concussive Blast |
| `warlock` | Aetherium Shield, Aetherium Bolt, Concussive Blast |
| `lunarowl` | No ability module supplied |
| `werecatfemale` | No ability module supplied |
| `werecatmale` | No ability module supplied |
| `ravenfolk` | No ability module supplied |
| `bossmob` | Self Mend |
| `standardmob` | Self Mend |

All form-model defaults are freemode. Explicitly female IDs use the female freemode model; other IDs use male freemode. Set any model field to a different streamed ped name if desired. Custom model assets are not bundled.

Entries without an ability module still support configured forms and tiers. Some modules contain passives in addition to the listed active abilities; read the matching file in [shared/abilities](../shared/abilities) for effects, costs, and cooldowns.

Werewolf `transform` corresponds to wolf-form ability gating and `mutate` to humanoid-wolf gating, regardless of their configured model. `/howl` broadcasting is available in any form to the two configured werewolf races; Blood Howl is a separate combat ability.

Divine Touch and Self Mend depend on the documented medical integration. Door breach requires a door-system handler and blood-moon state. Mob presets use higher toughness and are intended for controlled encounters.
