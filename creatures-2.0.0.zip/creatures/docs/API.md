# Developer API

Keep the resource named `creatures`. Client and server exports are separate APIs.

## Server exports

| Export | Return / meaning |
| --- | --- |
| `GetPlayerRace(source)` | Race ID; `human` if absent |
| `HasRequiredRace(source, requirement)` | Boolean; exact race matching |
| `HasRequiredTier(source, requirement)` | Boolean; checks the configured race/tier |
| `GetPlayerAetherium(source)` | Reserve value, clamped to 0–100 |
| `SetPlayerAetherium(source, value)` | Boolean success; clamps finite numeric input to 0–100 and synchronizes the client |
| `GetPlayerToughness(source)` | Configured maximum toughness for the race |
| `SetPlayerToughness(source)` | Sends configured maximum toughness to the client and returns it |

Race requirements accept a string, an array of IDs, `{ allow = {...} }`, or `{ deny = {...} }`. A nil requirement passes for an existing player. Tier requirements accept a number/numeric string, an array, allow/deny lists, or `{ min = 2, max = 4 }`. Invalid race/tier combinations fail a non-nil tier requirement.

## Client exports

| Export | Return / meaning |
| --- | --- |
| `GetAetherium()` | Current local reserve |
| `SetAetherium(value)` | Clamped value, or false for invalid input |
| `AddAetherium(amount)` | Updated clamped value, or false |
| `RemoveAetherium(amount)` | True after deduction; false if invalid or insufficient |
| `HasRequiredRaceClient(requirement)` | Local race check; not a server authorization boundary |
| `GetCurrentTier()` | Local tier, default 0 |
| `GetCurrentForm()` | `transform`, `mutate`, or nil |
| `GetCurrentToughness()` / `GetMaxToughness()` | Local current / maximum toughness |
| `StartRaceAbilities(race)` | Reset the old module and load the new one |
| `StopCurrentRaceAbilities()` | Clear loaded abilities/cooldowns and reset selected effects |
| `LoadRaceAbilities(race)` | Load a configured race module |
| `Howl()` | Request an authorized broadcast howl; requires `Config.Howl.Enabled` |
| `GetSelectedFlightSpeed()` | Selected level, maximum allowed level, mapped engine preset |
| `SetFlightSpeed(level, silent, applyWhileFlying)` | Success boolean and preset on success |
| `ActivateFlight(preset)` | Boolean; activate an allowed preset through the configured engine |

Flight exports exist when `Config.Wings.enabled` is true. `SetFlightSpeed(nil)` cycles through unlocked speeds. Pass `applyWhileFlying = false` when preparing a preset for a subsequent `ActivateFlight` call. Energy setters retain compatibility with client-driven abilities; see [SECURITY.md](../SECURITY.md).

## ox_lib server callbacks

| Callback | Parameters after source | Return |
| --- | --- | --- |
| `creatures:server:getSavedRace` | none | Race ID |
| `creatures:server:getSavedTier` | none | Tier |
| `creatures:server:getToughness` | none | Configured toughness |
| `creatures:server:saveFormAppearance` | race, form, appearance | Success boolean |
| `creatures:server:getFormAppearance` | race, form | Model/appearance table or nil |
| `creatures:server:hasFormAppearance` | race, form | Whether a saved appearance exists |
| `creatures:server:getFlightSpeedAccess` | none | Maximum speed level, tier |
| `creatures:server:canUseWingSet` | wing-set ID | Boolean |
| `creatures:server:getKitsuneTailAccess` | optional Nolis pack name | Maximum tail count |
| `creatures:server:canUseKitsuneEars` | none | Boolean |
| `creatures:server:mothEquip` | color or `off` | Success, optional reason |
| `creatures:server:mothFlightAccess` | none | Boolean |

Optional feature callbacks exist only when the relevant adapter is enabled. Form callbacks are scoped to the caller's current race. Appearance saves accept only transform/mutate slots and the configured model, with a 64 KiB encoded payload limit.

## Ability modules

Add the race to `Config.Races`, then create `shared/abilities/<raceId>.lua`. The loader evaluates the file on the client and expects a returned table:

```lua
return {
    Passive = {
        { name = 'Example passive', tick = function()
            -- Runs on the passive loop; keep work bounded.
        end },
    },
    Active = {
        { name = 'Example ability', description = 'Describe the effect.', cooldown = 10,
          trigger = function()
              if not exports.creatures:RemoveAetherium(20) then return end
              -- Apply a local effect or request a validated server action.
          end },
    },
}
```

Existing passive modules use `tick`, `fastTick`, and other callbacks supported by the loops in `client/client_abilities.lua`; follow a matching existing module when adding effects. Cooldowns in module tables are seconds. Always validate race, targets, range, costs, and cooldowns on the server for effects that affect other players. New network entries in `server/server_abilities.lua` also need a policy in `server/ability_guard.lua`.

## Persistence

- `creatureRace`: configured race ID.
- `creatureTier`: tier number.
- `creatureForms[race][form]`: model plus JSON-encoded appearance.
- `aetherium`: current reserve.

Qbox owns persistence of these metadata fields. Creatures forces a player save after saving a form. Avoid writing a form into the normal character appearance record.
