fx_version 'cerulean'
game 'gta5'

author 'Streets & Sorcery contributors'
description 'Supernatural races, abilities, directional howls, and wing controls for Qbox'
version '2.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'shared/config.lua',
    'shared/wings.lua',
    'shared/howl.lua',
}
server_scripts {
    'server/server_main.lua',
    'server/server_aetherium.lua',
    'server/ability_guard.lua',
    'server/server_abilities.lua',
    'server/flight_speed.lua',
    'server/kitsune.lua',
    'server/moth.lua',
    'server/howl.lua',
}
client_scripts {
    '@qbx_core/modules/playerdata.lua',
    'client/utils.lua',
    'client/client_aetherium.lua',
    'client/client_abilities.lua',
    'client/client_main.lua',
    'client/ui.lua',
    'client/flight_speed.lua',
    'client/wing_commands.lua',
    'client/kitsune.lua',
    'client/moth.lua',
    'client/howl.lua',
}
ui_page 'html/index.html'
files {
    'shared/abilities/*.lua',
    'html/index.html',
    'html/audio.js',
    'sounds/*.mp3',
    'sounds/*.ogg',
    'sounds/*.wav',
    'integrations/*.lua',
}
dependencies {
    'ox_lib',
    'qbx_core',
    'ox_inventory',
    'illenium-appearance',
    '/onesync',
}

