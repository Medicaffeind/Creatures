# Howl recordings

Place recordings you have permission to use here. No audio is bundled.

Supported manifest patterns are `sounds/*.mp3`, `sounds/*.ogg`, and `sounds/*.wav`. Configure resource-relative paths in `Config.Howl.SoundUrls` in [shared/howl.lua](../shared/howl.lua), for example `sounds/wolf_howl1.ogg`. Set the safety duration longer than the longest clip and restart the resource.

Audio is ignored by Git by default to avoid accidentally publishing third-party recordings. Add a file deliberately only after establishing redistribution rights.
