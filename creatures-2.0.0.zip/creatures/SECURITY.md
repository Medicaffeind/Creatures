# Security and trust boundaries

This combined resource includes ACE checks for race/tier administration, validation of form-save ownership/model/payload size, finite Aetherium bounds, race/target/range checks on ability entry points, and server-controlled howl race, cooldown, position, recipient, and sound selection.

It is **not a complete server-authoritative combat or anti-cheat system**. The inherited ability implementation still uses client-side reserve updates, local cooldowns, damage, movement, and toughness effects. In particular, the compatibility `creatures:server:update` event accepts a bounded reserve value from the owning client; clamping a value is not proof that it was earned. Some area effects and visual broadcasts also retain legacy broadcast behavior. Individual-target guards reject targets in other routing buckets, but this does not establish complete bucket isolation for every ability.

If your server requires stronger enforcement, move reserve spending, regeneration, ability state, hit validation, and area-effect recipient selection to authoritative server transactions before enabling competitive combat. Keep client race/tier checks for UI only.

Wing access callbacks enforce Creatures policy, but a vendor's independent equip/flight commands or network events can bypass an adapter. Validate access in the actual vendor entry point and disable duplicate unrestricted handlers. Optional vendor scripts/assets are outside this repository's control.

Report reproducible issues privately to the repository maintainer using the contact channel they provide. Include the affected event/export, dependency versions, and minimal reproduction steps. Do not post credentials, player identifiers, or production database dumps in public issues.
