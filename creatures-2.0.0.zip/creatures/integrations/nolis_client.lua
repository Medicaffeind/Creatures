-- Loaded by the Nolis packs in place of their unrestricted client.lua.
-- Each pack owns its entities; policy remains in creatures.
local resource = GetCurrentResourceName()
local settings = Config.KitsuneTails.nolis
local prefixes = assert(settings.packs[resource], 'Unknown Nolis tail resource')
local equipped
local generation = 0
local busy = false
local clearEvent = 'creatures:client:clearKitsuneTails'

local function notify(message)
    lib.notify({ title = 'Kitsune Tails', description = message, type = 'error' })
end

local function removeTails()
    generation = generation + 1
    if equipped then
        DeleteEntity(equipped.object)
        RemoveAnimDict(equipped.dict)
        equipped = nil
    end
end

local function getAccess()
    if GetResourceState('creatures') ~= 'started' then return 0 end
    return tonumber(lib.callback.await('creatures:server:getKitsuneTailAccess', false, resource)) or 0
end

local function loadAsset(request, loaded, token)
    local deadline = GetGameTimer() + 5000
    request()
    while not loaded() do
        if token ~= generation or GetGameTimer() >= deadline then return false end
        Wait(10)
    end
    return token == generation
end

local function spawnTails(count, color, animation)
    local model = joaat('ninetails' .. prefixes[count] .. color)
    local dict = ('ninetailsanim%d@animation'):format(animation)
    if not IsModelInCdimage(model) or not IsModelValid(model) then
        notify('This tail model is unavailable. Check that its clothing pack is started.')
        return
    end

    -- Remove tails from the other packs as well so sets never stack.
    TriggerEvent(clearEvent)
    local token = generation
    local modelLoaded = loadAsset(function() RequestModel(model) end,
        function() return HasModelLoaded(model) end, token)
    local animLoaded = modelLoaded and loadAsset(function() RequestAnimDict(dict) end,
        function() return HasAnimDictLoaded(dict) end, token)
    if not animLoaded then
        SetModelAsNoLongerNeeded(model)
        RemoveAnimDict(dict)
        if token == generation then notify('The tail model or animation failed to load.') end
        return
    end

    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local object = CreateObject(model, coords.x, coords.y, coords.z, true, true, true)
    SetModelAsNoLongerNeeded(model)
    if object == 0 then
        RemoveAnimDict(dict)
        notify('Unable to create the tail object.')
        return
    end
    AttachEntityToEntity(object, ped, GetPedBoneIndex(ped, 11816),
        -0.09, -0.02, 0.0, 0.0, -90.0, 180.0, true, true, false, true, 1, true)
    PlayEntityAnim(object, ('ninetailsanim%d_clip'):format(animation), dict,
        1000.0, true, true, true, 0.0, false)
    equipped = { object = object, dict = dict, count = count, color = color, animation = animation }
end

RegisterCommand(resource, function(_, args)
    if busy then return end
    local color = tonumber(args[1] or 1)
    local animation = tonumber(args[2] or 1)
    if not color or color ~= math.floor(color) or color < 1 or color > settings.colors
        or not animation or animation ~= math.floor(animation)
        or animation < 1 or animation > settings.animations then
        notify(('Use /%s [color 1-%d] [animation 1-%d].'):format(resource, settings.colors, settings.animations))
        return
    end
    busy = true
    local token = generation
    local ok, maximum = pcall(getAccess)
    if token == generation then
        if not ok then
            notify('Unable to check your kitsune tier. Please try again.')
        elseif maximum < 1 then
            notify('Only kitsune players with a valid tier can use these tails.')
        elseif not prefixes[maximum] then
            notify(('Your tier allows up to %d tails.'):format(maximum))
        else
            -- The player selects only color/animation; tier selects the count.
            spawnTails(maximum, color, animation)
        end
    end
    busy = false
end, false)

RegisterCommand(resource .. 'x', removeTails, false)
AddEventHandler(clearEvent, removeTails)
RegisterNetEvent('QBCore:Client:OnPlayerUnload', removeTails)

local function refreshTails()
    if not equipped or busy then return end
    busy = true
    local previous = equipped
    local ok, maximum = pcall(getAccess)
    if equipped == previous then
        if not ok or maximum < 1 then
            removeTails()
        elseif previous.count ~= maximum then
            if prefixes[maximum] then
                spawnTails(maximum, previous.color, previous.animation)
            else
                -- Remove the set if a configured tier has no model mapping.
                removeTails()
            end
        end
    end
    busy = false
end

CreateThread(function()
    while true do
        Wait(5000)
        refreshTails()
    end
end)

for _, event in ipairs({ 'creatures:client:setTier', 'creatures:client:clearTier' }) do
    RegisterNetEvent(event, function()
        CreateThread(function()
            Wait(250)
            refreshTails()
        end)
    end)
end

AddEventHandler('onClientResourceStop', function(stopped)
    if stopped == resource or stopped == 'creatures'
        or (equipped and equipped.count == 9 and stopped == 'ninetails')
        or (equipped and equipped.count < 9 and stopped == 'alltails') then
        removeTails()
    end
end)
