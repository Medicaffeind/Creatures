-- Runs inside foxear instead of the vendor's unrestricted client script.
local object, dictionary
local busy = false
local generation = 0

local function notify(message)
    lib.notify({ title = 'Kitsune Ears', description = message, type = 'error' })
end

local function removeEars()
    generation = generation + 1
    if object then DeleteEntity(object) end
    if dictionary then RemoveAnimDict(dictionary) end
    object, dictionary = nil, nil
end

local function hasAccess()
    if GetResourceState('creatures') ~= 'started' then return false end
    return lib.callback.await('creatures:server:canUseKitsuneEars', false) == true
end

RegisterCommand('foxear', function(_, args)
    if busy then return end
    local color, animation = tonumber(args[1]), tonumber(args[2] or 1)
    if not color or color ~= math.floor(color) or color < 1 or color > 15
        or not animation or animation ~= math.floor(animation) or animation < 1 or animation > 6 then
        notify('Use /foxear [color 1-15] [animation 1-6].')
        return
    end
    busy = true
    local token = generation
    local ok, allowed = pcall(hasAccess)
    if token ~= generation then busy = false; return end
    if not ok or not allowed then
        notify(ok and 'Only kitsune players can wear fox ears.' or 'Unable to check your race. Please try again.')
        busy = false
        return
    end
    local model = joaat('fox_ear_' .. color)
    local dict = ('fox_ear_anim%d@animation'):format(animation)
    if not IsModelInCdimage(model) or not IsModelValid(model) then
        notify('This fox ear model is unavailable.')
        busy = false
        return
    end
    removeEars()
    token = generation
    RequestModel(model)
    RequestAnimDict(dict)
    local deadline = GetGameTimer() + 5000
    while token == generation and GetGameTimer() < deadline
        and (not HasModelLoaded(model) or not HasAnimDictLoaded(dict)) do
        Wait(10)
    end
    if token ~= generation or not HasModelLoaded(model) or not HasAnimDictLoaded(dict) then
        SetModelAsNoLongerNeeded(model)
        RemoveAnimDict(dict)
        if token == generation then notify('The fox ears failed to load.') end
        busy = false
        return
    end
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    object = CreateObject(model, coords.x, coords.y, coords.z, true, true, true)
    SetModelAsNoLongerNeeded(model)
    if object == 0 then
        object = nil
        RemoveAnimDict(dict)
        notify('Unable to create the fox ears.')
        busy = false
        return
    end
    dictionary = dict
    AttachEntityToEntity(object, ped, GetPedBoneIndex(ped, 31086),
        0.12, -0.02, 0.0, 0.0, 90.0, 180.0, true, true, false, true, 1, true)
    PlayEntityAnim(object, ('fox_ear_anim%d_clip'):format(animation), dict,
        1000.0, true, true, true, 0.0, false)
    busy = false
end, false)

RegisterCommand('foxearx', removeEars, false)
RegisterNetEvent('QBCore:Client:OnPlayerUnload', removeEars)
CreateThread(function()
    while true do
        Wait(5000)
        if object and not busy then
            local previous = object
            local ok, allowed = pcall(hasAccess)
            if object == previous and (not ok or not allowed) then removeEars() end
        end
    end
end)
AddEventHandler('onClientResourceStop', function(resource)
    if resource == GetCurrentResourceName() or resource == 'creatures' then removeEars() end
end)
