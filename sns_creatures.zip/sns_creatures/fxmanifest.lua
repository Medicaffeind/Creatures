fx_version 'cerulean'
game 'gta5'

description 'Creatures — Race Transformation System'
author 'A big Richarrd'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'shared/config.lua',
    'shared/abilities/*'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/*'
}

client_scripts {
    '@qbx_core/modules/playerdata.lua',
    'client/*'

}

exports {
    'GetAetherium',
    'SetAetherium',
    'AddAetherium',
    'RemoveAetherium'
}
