FeedConfig = {}

FeedConfig.MaxDistance = 1.5
FeedConfig.TickRate = 1000

FeedConfig.HealPerTick = 10
FeedConfig.DamagePerTick = 8

FeedConfig.QuickBiteHeal = 20
FeedConfig.QuickBiteDamage = 15

FeedConfig.AllowPlayerFeeding = true
FeedConfig.AllowNPCFeeding = true

FeedConfig.RequireDeadVictim = false
FeedConfig.RequireRestrainedPlayers = false

FeedConfig.CancelKey = 73 -- X

FeedConfig.VampireAnimDict = 'anim@gangops@hostage@'
FeedConfig.VampireAnim = 'perp_idle'

FeedConfig.VictimAnimDict = 'anim@gangops@hostage@'
FeedConfig.VictimAnim = 'victim_idle'

FeedConfig.StumbleDuration = 15000