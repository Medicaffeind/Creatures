local NIGHT_START = 20
local NIGHT_END = 6

local HUMAN_WOLF_MODELS = {
    [`Overseer_male`] = true,
    [`Overseer_female`] = true,
}

local REGULAR_WOLF_MODELS = {
    [`Direwolves_base`] = true,
}

local function IsNight()
    local hour = GetClockHours()
    return hour >= NIGHT_START or hour < NIGHT_END
end

local function GetWerewolfForm()
    local ped = PlayerPedId()
    local model = GetEntityModel(ped)

    if HUMAN_WOLF_MODELS[model] then
        return "humanwolf"
    end

    if REGULAR_WOLF_MODELS[model] then
        return "wolf"
    end

    return false
end

local function IsWerewolf()
    return GetWerewolfForm() ~= false
end

return {

    Passive = {

        {
            name = "Moonlit Regeneration",
            description = "Your body rapidly regenerates beneath the night sky.",

            tick = (function()

                local lastRegen = 0

                return function()

                    if not IsWerewolf() then
                        return
                    end

                    if not IsNight() then
                        return
                    end

                    local now = GetGameTimer()

                    if now - lastRegen < 3000 then
                        return
                    end

                    lastRegen = now

                    local ped = PlayerPedId()

                    if IsEntityDead(ped) then
                        return
                    end

                    local health = GetEntityHealth(ped)
                    local maxHealth = GetEntityMaxHealth(ped)

                    if health < maxHealth then

                        SetEntityHealth(
                            ped,
                            math.min(
                                maxHealth,
                                health + 2
                            )
                        )

                    end

                end

            end)()
        },
        {
            name = "Hunter's Pace",
            description = "Werewolf physiology grants increased speed during the night.",

            tick = (function()

                return function()

                    local ped = PlayerPedId()

                    if not IsWerewolf() or not IsNight() then

                        SetPedMoveRateOverride(
                            ped,
                            1.0
                        )

                        SetRunSprintMultiplierForPlayer(
                            PlayerId(),
                            1.0
                        )

                        return
                    end

                    SetPedMoveRateOverride(
                        ped,
                        1.15
                    )

                    SetRunSprintMultiplierForPlayer(
                        PlayerId(),
                        1.15
                    )

                end

            end)()
        },
        {
            name = "Toughness",
            description = "A supernatural barrier absorbs damage after your armor is depleted.",
            tick = function()
            end
        }
    },

    Active = {
        {
            name = "Blood Howl",
            description = "Unleash a terrifying howl that temporarily increases melee damage.",
            cooldown = 30,

            trigger = function()

                if not IsWerewolf() then

                    return lib.notify({
                        title = "Blood Howl",
                        description = "You must be in Werewolf form.",
                        type = "error"
                    })

                end

                if not exports.sns_creatures:RemoveAetherium(25) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })

                end

                TriggerServerEvent(
                    "sns_creatures:werewolfHowl"
                )

            end
        },
        {
            name = "Lupine Leap",
            description = "Channel your lupine strength to leap farther and higher.",
            cooldown = 18,

            trigger = function()

                if GetWerewolfForm() ~= "humanwolf" then

                    return lib.notify({
                        title = "Lupine Leap",
                        description = "This ability requires your human-wolf form.",
                        type = "error"
                    })

                end

                if not exports.sns_creatures:RemoveAetherium(15) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })

                end

                TriggerEvent(
                    "sns_creatures:client:lupineLeap"
                )

            end
        },
        {
            name = "Blood Moon Breach",
            description = "Shatter a locked door with brute force during a Blood Moon.",
            cooldown = 60,

            trigger = function()

                if not IsWerewolf() then

                    return lib.notify({
                        title = "Blood Moon Breach",
                        description = "You must be in Werewolf form.",
                        type = "error"
                    })

                end

                if not GlobalState.bloodMoon then

                    return lib.notify({
                        title = "Blood Moon Breach",
                        description = "The Blood Moon is not in the sky.",
                        type = "error"
                    })

                end

                local tier = lib.callback.await(
                    "sns_creatures:server:getSavedTier",
                    false
                )

                tier = tonumber(tier) or 0

                if tier < 4 then

                    return lib.notify({
                        title = "Blood Moon Breach",
                        description = "Only Full Moon and Elder Lycans possess enough strength to breach doors.",
                        type = "error"
                    })

                end

                if not exports.sns_creatures:RemoveAetherium(30) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })

                end

                TriggerEvent(
                    "sns_creatures:client:attemptDoorBreach"
                )

            end
        },
        {
            name = "Feral Rend",
            description = "Savage a nearby target with a devastating claw attack.",
            cooldown = 15,

            trigger = function()

                if not IsWerewolf() then

                    return lib.notify({
                        title = "Feral Rend",
                        description = "You must be in Werewolf form.",
                        type = "error"
                    })

                end

                if not exports.sns_creatures:RemoveAetherium(20) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })

                end

                local player = lib.getClosestPlayer(
                    GetEntityCoords(PlayerPedId()),
                    2.5
                )

                if not player then

                    return lib.notify({
                        title = "Feral Rend",
                        description = "There is nobody close enough.",
                        type = "error"
                    })

                end

                TriggerServerEvent(
                    "sns_creatures:werewolfRend",
                    GetPlayerServerId(player)
                )

            end
        },
        {
            name = "Predator's Sight",
            description = "Toggle your wolf senses to reveal nearby heat signatures.",
            cooldown = 0,

            trigger = function()

                TriggerEvent(
                    "sns_creatures:client:predatorSight"
                )

            end
        },
    }
}