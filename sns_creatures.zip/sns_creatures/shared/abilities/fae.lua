return {
    Passive = {
        {
            name = "Toughness",
            description = "A supernatural barrier absorbs damage after your armor is depleted.",
            tick = function()
            end
        }
    },

    Active = {
        {
            name = "Glamour",
            description = "Alter your appearance through fae magic.",
            cooldown = 10,

            trigger = function()

                if not exports.sns_creatures:RemoveAetherium(20) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })
                end

                TriggerEvent("illenium-appearance:client:openClothingShopMenu", true)
            end
        },
       {
            name = "Mischief",
            description = "Transform into a random object.",
            cooldown = 30,

            trigger = function()
            
                if not exports.sns_creatures:RemoveAetherium(30) then
                
                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })
                end
            
                local props = {
                    "prop_box_ammo07a",
                    "prop_bush_neat_06",
                    "prop_couch_sm_02",
                    "prop_recyclebin_04_b",
                    "prop_barrel_exp_01a",
                    "prop_cs_panties_03",
                    "prop_bush_neat_02",
                    "prop_bush_med_06",
                    "prop_pot_plant_05d",
                    "prop_roadcone01b",
                    "prop_mc_conc_barrier_01",
                    "prop_barrier_wat_03b",
                    "prop_sign_road_01a"
                }
            
                TriggerServerEvent(
                    'sns_fae:mischief',
                    props[math.random(#props)]
                )
            end
        }      , 
        {
            name = "Fairy Dust",
            description = "Overwhelm nearby mortals with bewildering fae magic.",
            cooldown = 900,

            trigger = function()

                if not exports.sns_creatures:RemoveAetherium(80) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })
                end
            
                local ped = PlayerPedId()
                local coords = GetEntityCoords(ped)
            
                for _, playerId in ipairs(GetActivePlayers()) do
                
                    local targetPed = GetPlayerPed(playerId)
                
                    if targetPed ~= ped then
                    
                        local dist = #(coords - GetEntityCoords(targetPed))
                    
                        if dist <= 10.0 then
                        
                            TriggerServerEvent(
                                'sns_fae:fairydust',
                                GetPlayerServerId(playerId)
                            )
                        end
                    end
                end
            
                lib.notify({
                    title = 'Fairy Dust',
                    description = 'The veil between worlds grows thin...',
                    type = 'success'
                })
            end
        }
    }
}