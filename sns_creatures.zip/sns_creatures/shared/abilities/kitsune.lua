return {
    Passive = {
        {
            name = "Aetherium Regeneration",
            description = "Magical energy slowly replenishes.",

            tick = (function()

                local lastRegen = 0

                return function()

                    local now = GetGameTimer()

                    if now - lastRegen < 5000 then
                        return
                    end

                    lastRegen = now

                    exports.sns_creatures:AddAetherium(5)
                end
            end)()
        },
        {
            name = "Toughness",
            description = "A supernatural barrier absorbs damage after your armor is depleted.",
            tick = function()
            end
        }
    },
    Active = {
        {
            name = 'Kitsune Dash',
            description = 'Burst in the direction you are facing with supernatural speed.',
            cooldown = 0,
            trigger = function()
                TriggerServerEvent('sns_creatures:server:kitsuneDash')
            end
        },
        {
            name = 'Fox Fire',
            description = 'Summon a glowing fox flame that lingers before dispersing.',
            cooldown = 0,
            trigger = function()
                TriggerServerEvent('sns_creatures:server:kitsuneFoxFire')
            end
        },
    }
}