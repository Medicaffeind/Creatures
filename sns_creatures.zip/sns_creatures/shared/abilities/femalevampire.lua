return {
    Passive = {
        {
            name = "Aetherium Regeneration",
            description = "Magical energy slowly replenishes.",

            tick = (function()

                local lastRegen = 0

                return function()

                    local now = GetGameTimer()

                    if now - lastRegen < 5000 then
                        return
                    end

                    lastRegen = now

                    exports.sns_creatures:AddAetherium(5)
                end
            end)()
        },
        {
            name = "Night Strength",
            description = "Increased strength at night",

            tick = function()
                local hour = GetClockHours()

                if hour >= 20 or hour <= 6 then
                    SetRunSprintMultiplierForPlayer(PlayerId(), 1.3)
                else
                    SetRunSprintMultiplierForPlayer(PlayerId(), 1.0)
                end
            end
        },
        {
            name = "Eternal Hunger",
            description = "Never get hungry for mortal food",

            tick = function()
                local playerData = exports.qbx_core:GetPlayerData()

                if not playerData or not playerData.metadata then
                    return
                end

                local hunger = playerData.metadata.hunger or 100

                if hunger < 99 then
                    TriggerServerEvent('hud:server:RelieveNeeds', 10, 0)
                end
            end
        },
        {
            name = "Sun Weakness",
            description = "The sun is your weakness",

            tick = (function()
                local lastBurn = 0

                return function()
                    local ped = PlayerPedId()

                    if IsEntityDead(ped) then
                        return
                    end

                    local now = GetGameTimer()

                    if now - lastBurn < (Config.SunDamage.interval or 5000) then
                        return
                    end

                    local hour = GetClockHours() + (GetClockMinutes() / 60)

                    if hour < Config.ActiveHours.start
                    or hour > Config.ActiveHours.finish then
                        return
                    end

                    local weather = GetPrevWeatherTypeHashName()
                    local activeWeather = false

                    for _, w in ipairs(Config.ActiveWeather) do
                        if GetHashKey(w) == weather then
                            activeWeather = true
                            break
                        end
                    end

                    if not activeWeather then
                        return
                    end

                    if IsPedInAnyVehicle(ped, false)
                    and IsVehicleSunProtected(ped) then
                        return
                    end

                    if IsUsingUmbrella(ped, Config.UmbrellaProtection) then
                        return
                    end

                    local race = lib.callback.await('sns_creatures:server:getSavedRace', false)
                    local protectionItem = Config.SunProtectionItem[race]

                    if protectionItem then
                        if type(protectionItem) == "table" then
                            for _, item in ipairs(protectionItem) do
                                if HasProtectionItem(item) then
                                    return
                                end
                            end
                        elseif HasProtectionItem(protectionItem) then
                            return
                        end
                    end

                    if IsSunscreenActive() then
                        return
                    end


                    if IsExposedToSun(ped) then
                        lastBurn = now

                        local tier = exports['sns_creatures']:GetCurrentTier()

                        local damageTable = Config.SunDamage.damage or {}
                        local damage = damageTable[tier] or 10

                        ApplyDamageToPed(ped, damage, false)

                        BurnEffect(ped, {
                            particleDict = "core",
                            particleName = "ent_sht_flame",
                            scale = 0.5,
                            duration = 500
                        })
                    end
                end
            end)()
        },
        {
            name = "Toughness",
            description = "A supernatural barrier absorbs damage after your armor is depleted.",
            tick = function()
            end
        }
    },

    Active = {

        {
            name = "Blood Dash",
            description = "Dash forward quickly",
            cooldown = 10,

            trigger = function()

                if not exports.sns_creatures:RemoveAetherium(30) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })
                end

                local ped = PlayerPedId()
                local health = GetEntityHealth(ped)

                if health <= 110 then
                    return lib.notify({
                        title = "Too Weak",
                        description = "You don't have enough health to use this ability.",
                        type = "error"
                    })
                end

                SetEntityHealth(ped, health - 10)

                local forward = GetEntityForwardVector(ped)

                SetEntityVelocity(
                    ped,
                    forward.x * 30.0,
                    forward.y * 30.0,
                    0.5
                )
            end
        },

        {
            name = "Mist Form",
            description = "Temporary invisibility",
            cooldown = 30,

            trigger = function()

                if not exports.sns_creatures:RemoveAetherium(30) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })
                end
                
                local ped = PlayerPedId()
                local health = GetEntityHealth(ped)

                if health <= 110 then
                    return lib.notify({
                        title = "Too Weak",
                        description = "You don't have enough health to use this ability.",
                        type = "error"
                    })
                end

                SetEntityHealth(ped, health - 10)

                SetEntityVisible(ped, false, false)

                Wait(5000)

                SetEntityVisible(ped, true, false)
            end
        },

        {
            name = "Feed",
            description = "Drink blood from nearby victims",
            cooldown = 15,

            trigger = function()
                local ped = PlayerPedId()

                if IsPedDeadOrDying(ped) then
                    return
                end

                local coords = GetEntityCoords(ped)
                local closestPed = nil
                local closestDistance = 1.5

                for _, target in ipairs(GetGamePool('CPed')) do
                    if target ~= ped then
                        local dist = #(coords - GetEntityCoords(target))

                        if dist < closestDistance then
                            closestDistance = dist
                            closestPed = target
                        end
                    end
                end

                if not closestPed then
                    return lib.notify({
                        title = "No Victim",
                        description = "Nobody is close enough to feed on.",
                        type = "error"
                    })
                end

                if IsPedDeadOrDying(closestPed) then
                    return lib.notify({
                        title = "Dead Target",
                        description = "This victim has no fresh blood left.",
                        type = "error"
                    })
                end

                lib.registerContext({
                    id = 'vampire_feed_menu',
                    title = 'Vampire Feed',

                    options = {

                        {
                            title = 'Quick Bite',
                            description = 'Small heal and damage',

                            onSelect = function()
                                local health = GetEntityHealth(ped)
                                local maxHealth = GetEntityMaxHealth(ped)

                                RequestAnimDict('anim@gangops@hostage@')

                                while not HasAnimDictLoaded('anim@gangops@hostage@') do
                                    Wait(0)
                                end

                                TaskPlayAnim(
                                    ped,
                                    'anim@gangops@hostage@',
                                    'perp_idle',
                                    8.0,
                                    -8.0,
                                    3000,
                                    49,
                                    0,
                                    false,
                                    false,
                                    false
                                )

                                ApplyDamageToPed(closestPed, 15, false)

                                SetEntityHealth(
                                    ped,
                                    math.min(maxHealth, health + 20)
                                )

                                TriggerEvent(
                                    'sns:vampire:stumbleVictim',
                                    closestPed
                                )

                                lib.notify({
                                    title = 'Feed Successful',
                                    description = 'You drink fresh blood.',
                                    type = 'success'
                                })
                            end
                        },

                        {
                            title = 'Feed Until Full',
                            description = 'Drain continuously until fully healed',

                            onSelect = function()
                                local feeding = true

                                RequestAnimDict('anim@gangops@hostage@')

                                while not HasAnimDictLoaded('anim@gangops@hostage@') do
                                    Wait(0)
                                end

                                TaskPlayAnim(
                                    ped,
                                    'anim@gangops@hostage@',
                                    'perp_idle',
                                    8.0,
                                    -8.0,
                                    -1,
                                    49,
                                    0,
                                    false,
                                    false,
                                    false
                                )

                                lib.notify({
                                    title = "Feeding",
                                    description = "Press X to stop feeding.",
                                    type = "inform"
                                })

                                CreateThread(function()

                                    while feeding do
                                        Wait(1000)

                                        if IsControlJustPressed(0, 73) then
                                            break
                                        end

                                        if not DoesEntityExist(closestPed)
                                        or IsEntityDead(closestPed) then
                                            break
                                        end

                                        local distance = #(
                                            GetEntityCoords(ped)
                                            - GetEntityCoords(closestPed)
                                        )

                                        if distance > 2.0 then
                                            break
                                        end

                                        local health = GetEntityHealth(ped)
                                        local maxHealth = GetEntityMaxHealth(ped)

                                        SetEntityHealth(
                                            ped,
                                            math.min(maxHealth, health + 10)
                                        )

                                        ApplyDamageToPed(closestPed, 8, false)

                                        if GetEntityHealth(ped) >= maxHealth then
                                            break
                                        end
                                    end

                                    ClearPedTasks(ped)

                                    if DoesEntityExist(closestPed)
                                    and not IsEntityDead(closestPed) then
                                        TriggerEvent(
                                            'sns:vampire:stumbleVictim',
                                            closestPed
                                        )
                                    end

                                    lib.notify({
                                        title = 'Feed Ended',
                                        description = 'You release the victim.',
                                        type = 'inform'
                                    })
                                end)
                            end
                        }
                    }
                })

                lib.showContext('vampire_feed_menu')
            end
        }
    }
}