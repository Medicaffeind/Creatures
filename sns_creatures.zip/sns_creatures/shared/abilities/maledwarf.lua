return {
    Passive = {
            {
            name = "Aetherium Regeneration",
            description = "Magical energy slowly replenishes.",

            tick = (function()

                local lastRegen = 0

                return function()

                    local now = GetGameTimer()

                    if now - lastRegen < 5000 then
                        return
                    end

                    lastRegen = now

                    exports.sns_creatures:AddAetherium(5)
                end
            end)()
        },
        {
            name = "Heavy Strider",
            description = "Short bursts of speed, poor endurance.",

            tick = (function()

                local exhausted = false

                return function()

                    local ped = PlayerPedId()
                
                    if IsEntityDead(ped) then
                        return
                    end
                
                    local player = PlayerId()
                
                    local stamina =
                        GetPlayerSprintStaminaRemaining(player)
                    
                    if not exhausted
                    and stamina >= 90.0 then
                    
                        exhausted = true
                    
                        RequestAnimSet(
                            "move_m@injured"
                        )
                    
                        while not HasAnimSetLoaded(
                            "move_m@injured"
                        ) do
                            Wait(0)
                        end
                    
                        SetPedMovementClipset(
                            ped,
                            "move_m@injured",
                            1.0
                        )
                    
                        lib.notify({
                            title = "Exhausted",
                            description = "You have overextended yourself.",
                            type = "error"
                        })
                    end

                    if exhausted
                    and stamina <= 20.0 then
                    
                        exhausted = false
                    
                        ResetPedMovementClipset(
                            ped,
                            0.5
                        )
                    
                        lib.notify({
                            title = "Recovered",
                            description = "Your strength returns.",
                            type = "success"
                        })
                    end

                    if exhausted then
                        return
                    end

                    SetRunSprintMultiplierForPlayer(
                        player,
                        1.20
                    )
                
                end
            end)()
        },
        {
            name = "Mountain Soul",
            description = "Naturally resistant to damage and knockdowns",

            tick = function()
            
                local ped = PlayerPedId()
            
                if IsEntityDead(ped) then
                    return
                end
            
                SetPlayerMeleeWeaponDamageModifier(
                    PlayerId(),
                    1.15
                )
            
                SetPlayerWeaponDamageModifier(
                    PlayerId(),
                    0.90
                )
            end
        },
        {
            name = "Liquid Courage",
            description = "Alcohol strengthens a dwarf."
        },
        {
            name = "Toughness",
            description = "A supernatural barrier absorbs damage after your armor is depleted.",
            tick = function()
            end
        }
    }
}