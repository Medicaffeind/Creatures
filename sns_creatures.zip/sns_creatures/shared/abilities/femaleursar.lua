return {

    Passive = {
                {
            name = "Aetherium Regeneration",
            description = "Magical energy slowly replenishes.",

            tick = (function()

                local lastRegen = 0

                return function()

                    local now = GetGameTimer()

                    if now - lastRegen < 5000 then
                        return
                    end

                    lastRegen = now

                    exports.sns_creatures:AddAetherium(5)
                end
            end)()
        },
        {
            name = "Hibernate",
            description = "Rest and recover while remaining still.",

            tick = (function()
            
                local stillTime = 0
            
                return function()
                
                    local ped =
                        PlayerPedId()
                
                    local speed =
                        GetEntitySpeed(ped)
                
                    if speed < 0.05 then
                    
                        stillTime =
                            stillTime + 1
                    
                        if stillTime >= 50 then
                        
                            SetEntityHealth(
                                ped,
                                math.min(
                                    GetEntityMaxHealth(ped),
                                    GetEntityHealth(ped) + 1
                                )
                            )
                        
                            SetPedArmour(
                                ped,
                                math.min(
                                    100,
                                    GetPedArmour(ped) + 1
                                )
                            )
                        end
                    else
                        stillTime = 0
                    end
                end
            end)()
        },
        {
            name = "Toughness",
            description = "A supernatural barrier absorbs damage after your armor is depleted.",
            tick = function()
            end
        }
    },
    Active = {
        {
            name = "Maul",
            description = "A devastating Ursar strike.",
            cooldown = 20,

            trigger = function()

                if not exports.sns_creatures:RemoveAetherium(30) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })
                end
            
                local player =
                    lib.getClosestPlayer(
                        GetEntityCoords(
                            PlayerPedId()
                        ),
                        2.5
                    )
                
                if not player then
                    return
                end
            
                TriggerServerEvent(
                    'sns_creatures:maulTarget',
                    GetPlayerServerId(player)
                )
            end
        },
        {
            name = "Roar",
            description = "A terrifying Ursar roar.",
            cooldown = 30,

            trigger = function()

                if not exports.sns_creatures:RemoveAetherium(30) then

                    return lib.notify({
                        title = "Insufficient Aetherium",
                        description = "You lack the magical energy.",
                        type = "error"
                    })
                end
            
                local coords =
                    GetEntityCoords(
                        PlayerPedId()
                    )
                
                TriggerServerEvent(
                    'sns_creatures:ursarRoar',
                    coords
                )
            
                ShakeGameplayCam(
                    "LARGE_EXPLOSION_SHAKE",
                    1.0
                )
            end
        }
    }
}