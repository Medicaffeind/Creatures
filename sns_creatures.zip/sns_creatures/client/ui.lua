local selectedIndex = 1

RegisterCommand("useAbility", function()

    local ability =
        ActiveAbilities[selectedIndex]

    if not ability then
        return
    end

    local now =
        GetGameTimer()

    if Cooldowns[selectedIndex]
        and Cooldowns[selectedIndex] > now then

        lib.notify({
            title = "Cooldown",
            description = "Ability is on cooldown",
            type = "error"
        })

        return
    end

    ability.trigger()

    Cooldowns[selectedIndex] =
        now + (ability.cooldown * 1000)

    local playerData =
        exports.qbx_core:GetPlayerData()

    local race =
        playerData.metadata.creatureRace

    -- Kitsune handles its own notifications.
    if race == 'kitsune' then
        return
    end

    lib.notify({
        title = ability.name,
        description = "Activated",
        type = "success"
    })

end)

RegisterCommand("cycleAbility", function()
    if not ActiveAbilities or #ActiveAbilities == 0 then
        -- lib.notify({
        --     title = "Abilities",
        --     description = "No active abilities available for this race.",
        --     type = "error"
        -- })
        return
    end

    selectedIndex = selectedIndex + 1
    if selectedIndex > #ActiveAbilities then
        selectedIndex = 1
    end

    local ability = ActiveAbilities[selectedIndex]

    if not ability then
        lib.notify({
            title = "Abilities",
            description = "Failed to select ability.",
            type = "error"
        })
        return
    end

    lib.notify({
        title = "Selected Ability",
        description = ability.name or "Unknown Ability",
        type = "inform"
    })
end)

RegisterKeyMapping("useAbility", "Use Ability", "keyboard", Config.AbilityKey)
RegisterKeyMapping("cycleAbility", "Cycle Ability", "keyboard", Config.AbilityCycleKey)