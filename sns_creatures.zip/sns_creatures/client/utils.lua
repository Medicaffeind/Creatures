-- Vampires

local sunscreenActive = false
local sunscreenExpire = 0

function HasProtectionItem(item)
    if not item then return false end

    local count = exports.ox_inventory:Search('count', item)
    return count and count > 0
end

local oldHasProtectionCream= HasProtectionCream

function IsSunscreenActive()
    if not sunscreenActive then return false end
    if GetGameTimer() > sunscreenExpire then return false end

    local playerData = exports.qbx_core:GetPlayerData()
    local race = playerData?.metadata?.creatureRace

    if race == 'malevampire' or race == 'femalevampire' then
        return true
    end

    return false
end

function IsUsingUmbrella(ped, umbrella)
    if not umbrella or not umbrella.enabled then return false end

    local coords = GetEntityCoords(ped)

    for _, anim in ipairs(umbrella.anims or {}) do
        if IsEntityPlayingAnim(ped, anim.dict, anim.name, 3) then

            for _, prop in ipairs(umbrella.props or {}) do
                local hash = GetHashKey(prop)

                local obj = GetClosestObjectOfType(coords, 1.5, hash, false)

                if obj ~= 0 and DoesEntityExist(obj) then
                    if Config.Debug then
                        print("[Passive] Umbrella detected:", prop)
                    end
                    return true
                end
            end

        end
    end

    return false
end

function IsExposedToSun(ped)
    local pos = GetEntityCoords(ped)
    local ray = StartShapeTestRay(pos.x, pos.y, pos.z + 1.0, pos.x, pos.y, pos.z + 50.0, 1, ped, 0)
    local _, hit = GetShapeTestResult(ray)
    return hit == 0
end

function IsVehicleSunProtected(ped)
    local veh = GetVehiclePedIsIn(ped, false)
    if not veh or veh == 0 then return false end
    if not Config.VehicleTintProtection.enabled then return false end

    local safeTints = Config.VehicleTintProtection.safeTints or {}
    local windowIndexes = {0, 1, 2, 3} -- front-left, front-right, rear-left, rear-right

    for _, idx in ipairs(windowIndexes) do
        -- Only check windows that exist
        if DoesVehicleHaveDoor(veh, idx + 1) then  -- +1 because DoesVehicleHaveDoor uses 1-indexed doors
            -- If window is broken or rolled down
            if not IsVehicleWindowIntact(veh, idx) then
                return false
            end

            -- Check tint
            local tint = GetVehicleWindowTint(veh)
            local tintSafe = false
            for _, safe in ipairs(safeTints) do
                if tint == safe then
                    tintSafe = true
                    break
                end
            end

            if not tintSafe then
                return false
            end
        end
    end

    return true
end

function BurnEffect(ped, fx)
    if not fx then return end
    local pos = GetEntityCoords(ped)
    RequestNamedPtfxAsset(fx.particleDict)
    while not HasNamedPtfxAssetLoaded(fx.particleDict) do Wait(10) end
    UseParticleFxAssetNextCall(fx.particleDict)
    local effect = StartParticleFxLoopedAtCoord(
        fx.particleName, pos.x, pos.y, pos.z + (fx.offsetZ or 0.5),
        0.0, 0.0, 0.0, fx.scale or 1.0, false, false, false, false
    )
    Wait(fx.duration or 500)
    StopParticleFxLooped(effect, false)
    RemoveNamedPtfxAsset(fx.particleDict)
end

RegisterNetEvent('sns:vampire:stumbleVictim', function(target)

    if not DoesEntityExist(target) then return end

    RequestAnimSet('move_m@drunk@slightlydrunk')

    while not HasAnimSetLoaded('move_m@drunk@slightlydrunk') do
        Wait(0)
    end

    SetPedMovementClipset(
        target,
        'move_m@drunk@slightlydrunk',
        1.0
    )

    ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.2)

    CreateThread(function()

        Wait(15000)

        if DoesEntityExist(target) then
            ResetPedMovementClipset(target, 0.0)
        end

        StopGameplayCamShaking(true)
    end)
end)

-- Dwarves

RegisterNetEvent('sns_creatures:client:drinkBeer', function()
    local ped = PlayerPedId()
    local race = currentRace or exports['sns_creatures']:GetPlayerRace()

    if race ~= "maledwarf" and race ~= "femaledwarf" then
        return
    end

    local armor = GetPedArmour(ped)
    SetPedArmour(ped, math.min(armor + 25, 100))

    lib.notify({
        title = "Beer Drank",
        description = "+25 Armor (Dwarven Fortitude)",
        type = "success"
    })
end)

