local defaultMaxAetherium = 100

CreateThread(function()

    while not LocalPlayer.state.isLoggedIn do
        Wait(1000)
    end

    LocalPlayer.state.maxAetherium =
        LocalPlayer.state.maxAetherium or defaultMaxAetherium

    LocalPlayer.state.aetherium =
        LocalPlayer.state.aetherium or defaultMaxAetherium
end)

exports('GetAetherium', function()
    return LocalPlayer.state.aetherium or 0
end)

exports('SetAetherium', function(value)

    value = math.max(
        0,
        math.min(
            LocalPlayer.state.maxAetherium or 100,
            value
        )
    )

    LocalPlayer.state.aetherium = value

    TriggerServerEvent(
        'sns_creatures:server:update',
        value
    )

    return value
end)

exports('AddAetherium', function(amount)

    local current =
        LocalPlayer.state.aetherium or 0

    return exports.sns_creatures:SetAetherium(
        current + amount
    )
end)

exports('RemoveAetherium', function(amount)

    local current =
        LocalPlayer.state.aetherium or 0

    if current < amount then
        return false
    end

    exports.sns_creatures:SetAetherium(
        current - amount
    )

    return true
end)

RegisterNetEvent(
    'sns_creatures:client:set',
    function(value)

        LocalPlayer.state.aetherium = value
    end
)

RegisterCommand('mana', function()

    local current =
        LocalPlayer.state.aetherium or 0

    local max =
    LocalPlayer.state.maxAetherium or 100

    if LocalPlayer.state.demonVeiled then
            max = 50
    end

    lib.notify({
        title = "Aetherium Reserves",
        description = ("Your magical reserves are at %s / %s."):format(
            current,
            max
        ),
        type = "inform"
    })

end)

-- Regeneration
CreateThread(function()

    while true do
        Wait(5000)

        local current =
            LocalPlayer.state.aetherium or 100

        local max =
            LocalPlayer.state.maxAetherium or 100

        if LocalPlayer.state.demonVeiled then
            max = 50
        end

        if current < max then

            exports.sns_creatures:SetAetherium(
                math.min(max, current + 5)
            )
        end
    end
end)