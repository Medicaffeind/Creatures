PassiveAbilities = PassiveAbilities or {}
ActiveAbilities = ActiveAbilities or {}
Cooldowns = Cooldowns or {}
print("[SNS] abilities.lua LOADED")

local predatorSightEnabled = false

local function StopPredatorSight()

    predatorSightEnabled = false

    SetSeethrough(false)

end

function StopCurrentRaceAbilities()
    PassiveAbilities = {}
    ActiveAbilities = {}
    Cooldowns = {}

    StopPredatorSight()

    local player = PlayerId()
    SetRunSprintMultiplierForPlayer(player, 1.0)
    RestorePlayerStamina(player, 100.0)
end

exports('StopCurrentRaceAbilities', StopCurrentRaceAbilities)

function StartRaceAbilities(race)
    print("[SNS] StartRaceAbilities triggered:", race)

    StopCurrentRaceAbilities()
    LoadRaceAbilities(race)
end

exports('StartRaceAbilities', StartRaceAbilities)

function LoadRaceAbilities(race)
    if not race then return end

    race = string.lower(race)

    local abilityModule = LoadResourceFile(
        GetCurrentResourceName(),
        ("shared/abilities/%s.lua"):format(race)
    )

    if not abilityModule then
        print("[SNS] No ability file found for:", race)
        return
    end

    local fn, err = load(abilityModule)
    if not fn then
        print("[SNS] Load error:", err)
        return
    end

    local success, result = pcall(fn)
    if not success then
        print("[SNS] Runtime error:", result)
        return
    end

    PassiveAbilities = result.Passive or {}
    ActiveAbilities = result.Active or {}

    print("[SNS] Loaded race:", race)
end

exports('LoadRaceAbilities', LoadRaceAbilities)

-- Threads

-- Fast loop
CreateThread(function()
    while true do
        Wait(500)
        for _, ability in pairs(PassiveAbilities) do
            if ability.fastTick then
                ability.fastTick()
            end
        end
    end
end)

-- Slow loop
CreateThread(function()
    while true do
        Wait(5000)
        --print("[DEBUG] Passive count:", #PassiveAbilities)

        for _, ability in pairs(PassiveAbilities) do
            if ability.tick then
                ability.tick()
            end
        end
    end
end)

-- Demons

LocalPlayer.state.demonDisturb = true

local suppressionFearActive = false

RegisterNetEvent(
    'sns_creatures:client:suppressionEffect',
    function(demonCoords)

        if suppressionFearActive then
            return
        end

        local ped = PlayerPedId()

        if IsPedDeadOrDying(ped) then
            return
        end

        suppressionFearActive = true

        local myCoords = GetEntityCoords(ped)

        local direction = vector3(
            myCoords.x - demonCoords.x,
            myCoords.y - demonCoords.y,
            0.0
        )

        local length = math.sqrt(
            direction.x * direction.x +
            direction.y * direction.y
        )

        if length <= 0.0 then
            suppressionFearActive = false
            return
        end

        direction = vector3(
            direction.x / length,
            direction.y / length,
            0.0
        )

        local fleeCoords = vector3(
            myCoords.x + (direction.x * 40.0),
            myCoords.y + (direction.y * 40.0),
            myCoords.z
        )

        lib.notify({
            title = "Overwhelming Dread",
            description = "Your instincts scream at you to flee!",
            type = "error"
        })

        DoScreenFadeOut(150)
        Wait(250)
        DoScreenFadeIn(300)

        ShakeGameplayCam(
            "DRUNK_SHAKE",
            0.75
        )

        TaskGoStraightToCoord(
            ped,
            fleeCoords.x,
            fleeCoords.y,
            fleeCoords.z,
            4.0,
            10000,
            0.0,
            0.0
        )

        CreateThread(function()

            local endTime = GetGameTimer() + 10000

            while GetGameTimer() < endTime do

                Wait(0)

                DisableControlAction(0, 30, true) -- Left/Right
                DisableControlAction(0, 31, true) -- Forward/Back
                DisableControlAction(0, 21, true) -- Sprint
                DisableControlAction(0, 22, true) -- Jump
                DisableControlAction(0, 24, true) -- Attack
                DisableControlAction(0, 25, true) -- Aim
                DisableControlAction(0, 140, true)
                DisableControlAction(0, 141, true)
                DisableControlAction(0, 142, true)
            end

            ClearPedTasksImmediately(ped)

            StopGameplayCamShaking(true)

            suppressionFearActive = false
        end)
    end
)


RegisterNetEvent(
    'sns_creatures:alcoholConsumed',
    function(itemName)

        local playerData =
            exports.qbx_core:GetPlayerData()

        local race =
            playerData.metadata.creatureRace

        if race ~= 'maledwarf'
        and race ~= 'femaledwarf' then
            return
        end

        local armorGain = {
            beer = 25,
            whiskey = 50,
            mead = 75
        }

        local amount =
            armorGain[itemName]

        if not amount then
            return
        end

        local ped = PlayerPedId()

        SetPedArmour(
            ped,
            math.min(
                100,
                GetPedArmour(ped) + amount
            )
        )

        lib.notify({
            title = "Liquid Courage",
            description = "The drink steels your resolve.",
            type = "success"
        })
    end
)

CreateThread(function()

    while true do

        Wait(0)

        local playerData =
            exports.qbx_core:GetPlayerData()

        local race =
            playerData?.metadata?.creatureRace

        if race == 'maledwarf'
        or race == 'femaledwarf' then

            local ped = PlayerPedId()

            SetPedCanRagdoll(
                ped,
                false
            )

            SetPedCanRagdollFromPlayerImpact(
                ped,
                false
            )

            if IsPedRagdoll(ped) then

                ClearPedTasksImmediately(
                    ped
                )

                SetEntityVelocity(
                    ped,
                    0.0,
                    0.0,
                    0.0
                )
            end
        else
            Wait(1000)
        end
    end
end)

-- Fae
local faeDisguises = {}

RegisterNetEvent(
    'sns_fae:mischief',
    function(serverId, model)

        local player =
            GetPlayerFromServerId(serverId)

        if player == -1 then
            return
        end

        local ped =
            GetPlayerPed(player)

        if not DoesEntityExist(ped) then
            return
        end

        -- Toggle off

        if faeDisguises[serverId] then

            local disguise =
                faeDisguises[serverId]

            if DoesEntityExist(disguise.prop) then
                DeleteEntity(disguise.prop)
            end

            SetEntityVisible(
                ped,
                true,
                false
            )

            faeDisguises[serverId] = nil

            return
        end

        local hash =
            joaat(model)

        RequestModel(hash)

        while not HasModelLoaded(hash) do
            Wait(0)
        end

        local coords =
            GetEntityCoords(ped)

        local prop =
            CreateObject(
                hash,
                coords.x,
                coords.y,
                coords.z,
                false,
                false,
                false
            )

        if not DoesEntityExist(prop) then
            return
        end

        SetEntityVisible(
            ped,
            false,
            false
        )

        AttachEntityToEntity(
            prop,
            ped,
            0,

            0.0,
            0.0,
            -1.0,

            0.0,
            0.0,
            90.0,

            false,
            false,
            false,
            false,
            2,
            true
        )

        faeDisguises[serverId] = {
            prop = prop
        }

        if ped == PlayerPedId() then

            lib.notify({
                title = "Mischief",
                description = "Your fae magic disguises you.",
                type = "success"
            })

            CreateThread(function()

                local endTime =
                    GetGameTimer() + 60000

                while faeDisguises[serverId]
                and GetGameTimer() < endTime do

                    DisableControlAction(
                        0,
                        21,
                        true
                    )

                    DisableControlAction(
                        0,
                        22,
                        true
                    )

                    SetPedMoveRateOverride(
                        ped,
                        0.7
                    )

                    Wait(0)
                end
                
                if faeDisguises[serverId] then

                    TriggerServerEvent(
                        'sns_fae:endMischief'
                    )
                end
            end)
        end
    end
)

RegisterNetEvent(
    'sns_fae:endMischief',
    function(serverId)

        local disguise =
            faeDisguises[serverId]

        if not disguise then
            return
        end

        local player =
            GetPlayerFromServerId(serverId)

        if player ~= -1 then

            local ped =
                GetPlayerPed(player)

            SetEntityVisible(
                ped,
                true,
                false
            )

            SetPedMoveRateOverride(
                ped,
                1.0
            )
        end

        if DoesEntityExist(disguise.prop) then

            DeleteEntity(
                disguise.prop
            )
        end

        faeDisguises[serverId] =
            nil

        if serverId ==
            GetPlayerServerId(PlayerId())
        then

            lib.notify({
                title = "Mischief Ended",
                description = "Your glamour fades.",
                type = "inform"
            })
        end
    end
)

local fairyDustActive = false

RegisterNetEvent('sns_fae:client:fairydust', function()

    if fairyDustActive then
        return
    end

    fairyDustActive = true

    local ped = PlayerPedId()

    lib.notify({
        title = 'Fairy Dust',
        description = 'Reality twists around you...',
        type = 'error'
    })

    AnimpostfxPlay("DrugsTrevorClownsFight", 30000, false)
    SetTimecycleModifier("spectator5")
    SetPedMotionBlur(ped, true)
    ShakeGameplayCam("DRUNK_SHAKE", 1.5)

    CreateThread(function()

        local endTime = GetGameTimer() + 30000

        while GetGameTimer() < endTime do

            Wait(math.random(3000, 6000))

            if IsPedDeadOrDying(ped) then
                break
            end

            local coords = GetEntityCoords(ped)

            -- Ragdoll
            if math.random(1, 100) <= 50 then
                SetPedToRagdoll(
                    ped,
                    math.random(1500, 3000),
                    math.random(1500, 3000),
                    0,
                    false,
                    false,
                    false
                )
            end

            -- Forced movement
            if math.random(1, 100) <= 40 then

                TaskGoStraightToCoord(
                    ped,
                    coords.x + math.random(-4, 4),
                    coords.y + math.random(-4, 4),
                    coords.z,
                    1.0,
                    2000,
                    0.0,
                    0.0
                )

                Wait(2000)
                ClearPedTasksImmediately(ped)
            end

            DoScreenFadeOut(250)
            Wait(350)
            DoScreenFadeIn(500)

            ShakeGameplayCam("SMALL_EXPLOSION_SHAKE", 0.75)

            PlaySoundFrontend(-1, "Bed", "WastedSounds", true)
        end

        ClearPedTasksImmediately(ped)
        ClearPedSecondaryTask(ped)

        SetPedCanRagdoll(ped, true)

        ResetPedMovementClipset(ped, 0.0)
        ResetPedStrafeClipset(ped)
        ResetPedWeaponMovementClipset(ped)

        ClearTimecycleModifier()
        SetPedMotionBlur(ped, false)

        AnimpostfxStopAll()
        StopGameplayCamShaking(true)

        fairyDustActive = false

        lib.notify({
            title = 'Fairy Dust',
            description = 'The strange visions finally fade.',
            type = 'inform'
        })

    end)
end)
-- Witch/Warlock
RegisterNetEvent(
    'sns_creatures:client:aetheriumBoltHit',
    function(targetServerId)

        local targetPlayer =
            GetPlayerFromServerId(
                targetServerId
            )

        if targetPlayer == -1 then
            return
        end

        local targetPed =
            GetPlayerPed(
                targetPlayer
            )

        if not DoesEntityExist(
            targetPed
        ) then
            return
        end

        RequestNamedPtfxAsset("core")

        while not HasNamedPtfxAssetLoaded("core") do
            Wait(0)
        end

        UseParticleFxAssetNextCall("core")

        StartParticleFxLoopedOnEntity(
            "ent_dst_elec_fire_sp",
            targetPed,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            3.0,
            false,
            false,
            false
        )

        if targetPed ~= PlayerPedId() then
            return
        end

        ApplyDamageToPed(
            targetPed,
            25,
            false
        )

        ShakeGameplayCam(
            "SMALL_EXPLOSION_SHAKE",
            0.75
        )

        SetPedToRagdoll(
            targetPed,
            3000,
            3000,
            0,
            false,
            false,
            false
        )

        lib.notify({
            title = "Aetherium Bolt",
            description = "Arcane energy strikes you!",
            type = "error"
        })
    end
)

RegisterNetEvent(
    'sns_creatures:client:aetheriumBoltCast',
    function(startCoords, forward)

        local model =
            `prop_ld_flow_bottle`

        RequestModel(model)

        while not HasModelLoaded(model) do
            Wait(0)
        end

        local bolt = CreateObject(
            model,
            startCoords.x,
            startCoords.y,
            startCoords.z,
            false,
            false,
            false
        )

        SetEntityVisible(
            bolt,
            false,
            false
        )

        SetEntityCollision(
            bolt,
            false,
            false
        )

        RequestNamedPtfxAsset(
            "core"
        )

        while not HasNamedPtfxAssetLoaded(
            "core"
        ) do
            Wait(0)
        end

        UseParticleFxAssetNextCall("core")

        local projectileFx =
            StartParticleFxLoopedOnEntity(
                "ent_sht_electrical_box_sp",
                bolt,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                2.0,
                false,
                false,
                false
            )

        CreateThread(function()

            local currentPos =
                startCoords

            for i = 1, 40 do

                Wait(25)

                currentPos = vector3(
                    currentPos.x + (forward.x * 1.5),
                    currentPos.y + (forward.y * 1.5),
                    currentPos.z + (forward.z * 1.5)
                )

                SetEntityCoordsNoOffset(
                    bolt,
                    currentPos.x,
                    currentPos.y,
                    currentPos.z,
                    false,
                    false,
                    false
                )

                UseParticleFxAssetNextCall(
                    "core"
                )

                StartParticleFxNonLoopedAtCoord(
                    "ent_dst_elec_fire_sp",

                    currentPos.x,
                    currentPos.y,
                    currentPos.z,

                    0.0,
                    0.0,
                    0.0,

                    0.35,

                    false,
                    false,
                    false
                )
            end

            StopParticleFxLooped(
                projectileFx,
                false
            )

            DeleteEntity(
                bolt
            )
        end)
    end
)

RegisterNetEvent(
    'sns_creatures:client:concussiveBlastHit',
    function(direction)

        local ped = PlayerPedId()

        SetPedToRagdoll(
            ped,
            3000,
            3000,
            0,
            false,
            false,
            false
        )

        Wait(100)

        SetEntityVelocity(
            ped,
            direction.x * 10.0,
            direction.y * 10.0,
            5.0
        )

        ShakeGameplayCam(
            "LARGE_EXPLOSION_SHAKE",
            0.75
        )

        lib.notify({
            title = "Wing Gust",
            description = "A powerful gust throws you backwards!",
            type = "error"
        })
    end
)

-- Dragonkin
RegisterNetEvent(
    'sns_creatures:client:dragonFireHit',
    function()

        local ped = PlayerPedId()

        SetPedToRagdoll(
            ped,
            2000,
            2000,
            0,
            false,
            false,
            false
        )

        StartEntityFire(ped)

        ShakeGameplayCam(
            "MEDIUM_EXPLOSION_SHAKE",
            0.75
        )

        lib.notify({
            title = "Dragonfire",
            description = "You are engulfed in flames!",
            type = "error"
        })

        CreateThread(function()

            Wait(5000)

            if DoesEntityExist(ped) then
                StopEntityFire(ped)
            end
        end)
    end
)

local activeDragonFireFX = {}

RegisterNetEvent(
    'sns_creatures:client:dragonFireBreathFX',
    function(dragonId)

        local dragonPlayer =
            GetPlayerFromServerId(dragonId)

        if dragonPlayer == -1 then
            return
        end

        local dragonPed =
            GetPlayerPed(dragonPlayer)

        if not DoesEntityExist(dragonPed) then
            return
        end

        if activeDragonFireFX[dragonId] then

            StopParticleFxLooped(
                activeDragonFireFX[dragonId],
                false
            )

            activeDragonFireFX[dragonId] = nil
        end

        RequestNamedPtfxAsset("core")

        while not HasNamedPtfxAssetLoaded("core") do
            Wait(0)
        end

        -- Head bone
        local headBone =
            GetPedBoneIndex(
                dragonPed,
                31086
            )

        UseParticleFxAssetNextCall("core")

        local fx =
            StartParticleFxLoopedOnEntityBone(
                "ent_sht_flame",

                dragonPed,

                -- Position
                0.15,
                0.35,
                0.0,

                -- Rotation
                90.0,
                0.0,
                180.0,

                headBone,

                -- Scale
                1.8,

                false,
                false,
                false
            )

        activeDragonFireFX[dragonId] = fx

        CreateThread(function()

            Wait(1500)

            if activeDragonFireFX[dragonId] then

                StopParticleFxLooped(
                    activeDragonFireFX[dragonId],
                    false
                )

                activeDragonFireFX[dragonId] = nil
            end
        end)
    end
)

RegisterNetEvent(
    'sns_creatures:client:dragonGustHit',
    function(direction)

        local ped = PlayerPedId()

        SetPedToRagdoll(
            ped,
            3000,
            3000,
            0,
            false,
            false,
            false
        )

        Wait(100)

        SetEntityVelocity(
            ped,
            direction.x * 10.0,
            direction.y * 10.0,
            5.0
        )

        ShakeGameplayCam(
            "LARGE_EXPLOSION_SHAKE",
            0.75
        )

        lib.notify({
            title = "Wing Gust",
            description = "A powerful gust throws you backwards!",
            type = "error"
        })
    end
)
-- Elf
RegisterNetEvent(
    'sns_creatures:client:rooted',
    function()

        local ped =
            PlayerPedId()

        FreezeEntityPosition(
            ped,
            true
        )

        lib.notify({
            title = "Rooted",
            description = "Vines hold you in place.",
            type = "error"
        })

        Wait(5000)

        FreezeEntityPosition(
            ped,
            false
        )
    end
)

RegisterNetEvent(
    'sns_creatures:client:rootTarget',
    function()

        local rooted = true

        lib.notify({
            title = "Rooted",
            description = "Living vines bind your feet!",
            type = "error"
        })

        CreateThread(function()

            local endTime =
                GetGameTimer() + 20000

            while rooted
            and GetGameTimer() < endTime do

                DisableControlAction(0, 30, true) -- A/D
                DisableControlAction(0, 31, true) -- W/S
                DisableControlAction(0, 21, true) -- Sprint
                DisableControlAction(0, 22, true) -- Jump

                Wait(0)
            end

            rooted = false
        end)
    end
)

RegisterNetEvent(
    'sns_creatures:client:healingRain',
    function(coords)

        RequestNamedPtfxAsset("core")

        while not HasNamedPtfxAssetLoaded("core") do
            Wait(0)
        end

        CreateThread(function()

            local endTime =
                GetGameTimer() + 15000

            while GetGameTimer() < endTime do

                for i = 1, 8 do

                    UseParticleFxAssetNextCall("core")

                    StartParticleFxNonLoopedAtCoord(
                        "ent_amb_waterfall_splash_p",

                        coords.x + math.random(-8, 8),
                        coords.y + math.random(-8, 8),
                        coords.z + 8.0,

                        0.0,
                        0.0,
                        0.0,

                        1.0,

                        false,
                        false,
                        false
                    )
                end

                Wait(500)
            end
        end)
    end
)

RegisterNetEvent(
    'sns_creatures:client:healRainTick',
    function()

        local ped =
            PlayerPedId()

        if IsEntityDead(ped) then
            return
        end

        local maxHealth =
            GetEntityMaxHealth(ped)

        local currentHealth =
            GetEntityHealth(ped)

        local newHealth =
            math.min(
                maxHealth,
                currentHealth + 10
            )

        SetEntityHealth(
            ped,
            newHealth
        )

        PlaySoundFrontend(
            -1,
            "Boss_Message_Orange",
            "GTAO_Boss_Goons_FM_Soundset",
            true
        )
    end
)

-- Usar
RegisterNetEvent(
    'sns_creatures:client:maulHit',
    function()

        local ped =
            PlayerPedId()

        ApplyDamageToPed(
            ped,
            50,
            false
        )

        SetPedToRagdoll(
            ped,
            5000,
            5000,
            0,
            false,
            false,
            false
        )

        lib.notify({
            title = "Maul",
            description = "You are savagely mauled!",
            type = "error"
        })
    end
)

RegisterNetEvent(
    'sns_creatures:client:ursarRoarHit',
    function(direction)

        local ped =
            PlayerPedId()

        SetPedToRagdoll(
            ped,
            4000,
            4000,
            0,
            false,
            false,
            false
        )

        Wait(50)

        ApplyForceToEntity(
            ped,
            1,

            direction.x * 600.0,
            direction.y * 600.0,
            200.0,

            0.0,
            0.0,
            0.0,

            0,

            false,
            true,
            true,
            false,
            true
        )

        ShakeGameplayCam(
            "LARGE_EXPLOSION_SHAKE",
            1.0
        )

        lib.notify({
            title = "Roar",
            description = "The Ursar's roar hurls you backwards!",
            type = "error"
        })
    end
)

-- Mermaids

RegisterNetEvent(
    'sns_creatures:client:hydroSpearFX',
    function(caster, origin, direction, range)

        local player = GetPlayerFromServerId(caster)

        if player == -1 then
            return
        end

        local ped = GetPlayerPed(player)

        if not DoesEntityExist(ped) then
            return
        end

        local particleDict = 'core'
        local particleName = 'water_cannon_jet'

        RequestNamedPtfxAsset(particleDict)

        while not HasNamedPtfxAssetLoaded(particleDict) do
            Wait(0)
        end

        -- Right hand
        local handBone = GetPedBoneIndex(
            ped,
            57005
        )

        if handBone == -1 then
            return
        end

        local handCoords =
            GetWorldPositionOfEntityBone(
                ped,
                handBone
            )

        local dx = direction.x
        local dy = direction.y
        local dz = direction.z

        local horizontalLength =
            math.sqrt(
                (dx * dx) +
                (dy * dy)
            )

        local pitch =
            math.deg(
                math.atan(
                    dz,
                    horizontalLength
                )
            )

        local yaw =
            math.deg(
                math.atan(
                    dy,
                    dx
                )
            )

        UseParticleFxAssetNextCall(particleDict)

        local fx =
            StartParticleFxLoopedAtCoord(
                particleName,

                handCoords.x,
                handCoords.y,
                handCoords.z,

                -- Rotation
                pitch,
                0.0,
                yaw - 90.0,

                -- Scale
                1.0,

                false,
                false,
                false,
                false
            )

        if not fx or fx == 0 then

            if Config.Debug then
                print(
                    '[SNS Mermaid] Failed to create Hydro Spear FX.'
                )
            end

            RemoveNamedPtfxAsset(particleDict)

            return
        end

        CreateThread(function()

            Wait(1000)

            if DoesParticleFxLoopedExist(fx) then
                StopParticleFxLooped(
                    fx,
                    false
                )
            end

            RemoveNamedPtfxAsset(
                particleDict
            )

        end)
    end
)

RegisterNetEvent('sns_creatures:client:hydroSpearHit', function(damage, direction)

    local ped = PlayerPedId()

    if not DoesEntityExist(ped) or IsEntityDead(ped) then
        return
    end

    damage = tonumber(damage)

    if not damage or damage <= 0 then
        return
    end

    -- Debug direction
    if not direction then
        if Config.Debug then
            print('[SNS Mermaid] Hydro Spear hit but no direction received.')
        end
        return
    end

    if Config.Debug then
        print(
            ('[SNS Mermaid] Hydro Spear knockback direction: %.2f, %.2f, %.2f')
            :format(
                direction.x,
                direction.y,
                direction.z
            )
        )
    end

    local currentHealth = GetEntityHealth(ped)

    local newHealth = math.max(
        0,
        currentHealth - damage
    )

    SetEntityHealth(
        ped,
        newHealth
    )

    SetPedToRagdoll(
        ped,
        1500,
        1500,
        0,
        false,
        false,
        false
    )

    Wait(100)

    SetEntityVelocity(
        ped,
        direction.x * 4.0,
        direction.y * 4.0,
        2.0
    )

    -- Camera shake
    ShakeGameplayCam(
        "SMALL_EXPLOSION_SHAKE",
        0.35
    )

    if Config.Debug then
        print('[SNS Mermaid] Hydro Spear knockback applied.')
    end

end)

-- Werewolves

local HUMAN_WOLF_MODELS = {
    [`Overseer_male`] = true,
    [`Overseer_female`] = true,
}

local REGULAR_WOLF_MODELS = {
    [`Direwolves_base`] = true,
}

local function GetWerewolfForm()
    local ped = PlayerPedId()
    local model = GetEntityModel(ped)

    if HUMAN_WOLF_MODELS[model] then
        return "humanwolf"
    end

    if REGULAR_WOLF_MODELS[model] then
        return "wolf"
    end

    return false
end

local function IsWerewolf()
    return GetWerewolfForm() ~= false
end

RegisterNetEvent(
    "sns_creatures:client:predatorSight",
    function()

        if predatorSightEnabled then

            StopPredatorSight()

            return

        end

        if GetWerewolfForm() ~= "wolf" then

            return lib.notify({
                title = "Predator's Sight",
                description = "This ability requires your wolf form.",
                type = "error"
            })

        end

        local ped = PlayerPedId()

        if IsEntityDead(ped) then
            return
        end

        predatorSightEnabled = true

        SetSeethrough(
            true
        )

    end
)

CreateThread(function()

    while true do

        Wait(250)

        if predatorSightEnabled then

            local ped = PlayerPedId()

            if GetWerewolfForm() ~= "wolf"
                or IsEntityDead(ped) then

                StopPredatorSight()

            end

        end

    end

end)

AddEventHandler(
    "onResourceStop",
    function(resourceName)

        if resourceName ~= GetCurrentResourceName() then
            return
        end

        StopPredatorSight()

    end
)

RegisterNetEvent(
    "sns_creatures:client:werewolfHowl",
    function(duration, multiplier)

        local ped = PlayerPedId()

        if not IsWerewolf() then
            return
        end

        RequestAnimDict("amb@code_human_wander_drinking@beer@male@idle_a")

        while not HasAnimDictLoaded(
            "amb@code_human_wander_drinking@beer@male@idle_a"
        ) do
            Wait(10)
        end

        TaskPlayAnim(
            ped,
            "amb@code_human_wander_drinking@beer@male@idle_a",
            "idle_a",
            8.0,
            -8.0,
            2000,
            49,
            0.0,
            false,
            false,
            false
        )

        ShakeGameplayCam(
            "LARGE_EXPLOSION_SHAKE",
            0.35
        )

        multiplier = tonumber(multiplier) or 1.25
        duration = tonumber(duration) or 15000

        SetPlayerMeleeWeaponDamageModifier(
            PlayerId(),
            multiplier
        )

        lib.notify({
            title = "Blood Howl",
            description = "Your blood surges with primal strength!",
            type = "success"
        })

        Wait(duration)

        SetPlayerMeleeWeaponDamageModifier(
            PlayerId(),
            1.0
        )

        lib.notify({
            title = "Blood Howl",
            description = "The power of the howl fades.",
            type = "inform"
        })

    end
)

RegisterNetEvent(
    "sns_creatures:client:lupineLeap",
    function()

        if GetWerewolfForm() ~= "humanwolf" then
            return
        end

        local ped = PlayerPedId()

        if IsEntityDead(ped) then
            return
        end

        local duration = 5000

        local endTime = GetGameTimer() + duration

        CreateThread(function()

            while GetGameTimer() < endTime do

                Wait(0)

                if GetWerewolfForm() ~= "humanwolf" then
                    break
                end

                SetSuperJumpThisFrame(
                    PlayerId()
                )

                SetPedMoveRateOverride(
                    ped,
                    1.20
                )

            end

            SetPedMoveRateOverride(
                ped,
                1.0
            )

        end)

        lib.notify({
            title = "Lupine Leap",
            description = "Your muscles surge with lupine strength.",
            type = "success"
        })

    end
)

RegisterNetEvent(
    "sns_creatures:client:attemptDoorBreach",
    function()

        if not IsWerewolf() then
            return
        end

        local ped = PlayerPedId()

        local coords = GetEntityCoords(ped)
        local forward = GetEntityForwardVector(ped)

        local targetCoords =
            coords +
            (forward * 1.5)

        local door = GetClosestObjectOfType(
            targetCoords.x,
            targetCoords.y,
            targetCoords.z,
            1.5,
            0,
            false,
            false,
            false
        )

        if door == 0 then

            return lib.notify({
                title = "Blood Moon Breach",
                description = "There is no door close enough.",
                type = "error"
            })

        end

        local doorCoords = GetEntityCoords(door)

        TaskTurnPedToFaceCoord(
            ped,
            doorCoords.x,
            doorCoords.y,
            doorCoords.z,
            500
        )

        Wait(500)

        RequestAnimDict(
            "misscarsteal4@actor"
        )

        while not HasAnimDictLoaded(
            "misscarsteal4@actor"
        ) do
            Wait(10)
        end

        TaskPlayAnim(
            ped,
            "misscarsteal4@actor",
            "actor_berating_loop",
            8.0,
            -8.0,
            2500,
            0,
            0.0,
            false,
            false,
            false
        )

        local success = lib.skillCheck(
            {
                "hard",
                "hard",
                "hard",
                "hard"
            },
            {
                "e"
            }
        )

        ClearPedTasks(ped)

        if not success then

            lib.notify({
                title = "Blood Moon Breach",
                description = "You failed to break through the door.",
                type = "error"
            })

            return
        end

        TriggerServerEvent(
            "sns_creatures:werewolfBreachDoor",
            door,
            doorCoords
        )

    end
)

RegisterNetEvent(
    "sns_creatures:client:feralRendHit",
    function(damage, direction)

        local ped = PlayerPedId()

        if not DoesEntityExist(ped) then
            return
        end

        if IsEntityDead(ped) then
            return
        end

        damage = tonumber(damage)

        if not damage or damage <= 0 then
            return
        end

        local health = GetEntityHealth(ped)

        SetEntityHealth(
            ped,
            math.max(
                0,
                health - damage
            )
        )

        SetPedToRagdoll(
            ped,
            1500,
            1500,
            0,
            false,
            false,
            false
        )

        if direction then

            Wait(50)

            SetEntityVelocity(
                ped,
                direction.x * 5.0,
                direction.y * 5.0,
                3.0
            )

        end

        ShakeGameplayCam(
            "SMALL_EXPLOSION_SHAKE",
            0.35
        )

    end
)
-- Toughness
local maxToughness = 0
local currentToughness = 0

local initialized = false
local previousHealth = 0
local previousArmor = 0

local function SetToughness(amount)
    amount = tonumber(amount) or 0

    maxToughness = math.max(0, amount)
    currentToughness = maxToughness

    local ped = PlayerPedId()

    if DoesEntityExist(ped) then
        previousHealth = GetEntityHealth(ped)
        previousArmor = GetPedArmour(ped)
    end

    initialized = maxToughness > 0
end

RegisterNetEvent(
    'sns_creatures:client:setToughness',
    function(amount)

        SetToughness(amount)

    end
)

local function LoadToughness()

    local amount = lib.callback.await(
        'sns_creatures:server:getToughness',
        false
    )

    SetToughness(amount)

end

CreateThread(function()

    Wait(1000)

    LoadToughness()

    while true do

        Wait(250)

        local ped = PlayerPedId()

        if not DoesEntityExist(ped) then
            goto continue
        end

        if IsEntityDead(ped) then
            initialized = false
            currentToughness = 0
            goto continue
        end

        local health = GetEntityHealth(ped)
        local armor = GetPedArmour(ped)

        if not initialized then
            LoadToughness()
        end

        previousHealth = health
        previousArmor = armor

        ::continue::

    end

end)

-- Orc
local enrageActive = false
local enrageExpires = 0
local enrageToken = 0

local function GetEnrageConfig()
    return Config.Races.orc.Enrage
end

local function GetEnrageDuration()
    local config = GetEnrageConfig()

    local tier = tonumber(
        exports.sns_creatures:GetCurrentTier()
    ) or 0

    local duration =
        config.BaseDuration +
        (tier * config.DurationPerTier)

    return math.min(
        duration,
        config.MaxDuration
    )
end

local function StopEnrage()
    if not enrageActive then
        return
    end

    enrageActive = false
    enrageExpires = 0
    enrageToken = enrageToken + 1

    local playerId = PlayerId()

    SetPlayerMeleeWeaponDamageModifier(
        playerId,
        1.0
    )

    lib.notify({
        title = 'Enrage Ended',
        description = 'Your rage has subsided.',
        type = 'inform'
    })
end

local function StartEnrage()

    local playerData = exports.qbx_core:GetPlayerData()
    local race = playerData.metadata.creatureRace

    if race ~= 'orc' then
        return
    end

    local ped = PlayerPedId()

    if not DoesEntityExist(ped) then
        return
    end

    if IsEntityDead(ped) then
        return
    end

    local config = GetEnrageConfig()
    local duration = GetEnrageDuration()

    if duration <= 0 then
        return
    end

    enrageExpires =
        GetGameTimer() + (duration * 1000)

    if enrageActive then
        return
    end

    enrageActive = true
    enrageToken = enrageToken + 1

    local token = enrageToken

    SetPlayerMeleeWeaponDamageModifier(
        PlayerId(),
        config.MeleeMultiplier
    )

    lib.notify({
        title = 'ENRAGED',
        description = ('Enrage activated for %s seconds.'):format(duration),
        type = 'success'
    })

    CreateThread(function()

        while enrageActive and token == enrageToken do

            Wait(1000)

            if not enrageActive then
                break
            end

            if token ~= enrageToken then
                break
            end

            local ped = PlayerPedId()

            if not DoesEntityExist(ped) then
                StopEnrage()
                break
            end

            if IsEntityDead(ped) then
                StopEnrage()
                break
            end

            if GetGameTimer() >= enrageExpires then
                StopEnrage()
                break
            end

            local armor = GetPedArmour(ped)

            if armor < 100 then

                SetPedArmour(
                    ped,
                    math.min(
                        100,
                        armor + config.ArmorRegen
                    )
                )

            end

            local currentAether =
                exports.sns_creatures:GetAetherium()

            local maxAether =
                LocalPlayer.state.maxAetherium or 100

            if currentAether < maxAether then

                local amount =
                    math.min(
                        config.AetherPerSecond,
                        maxAether - currentAether
                    )

                if amount > 0 then
                    exports.sns_creatures:AddAetherium(amount)
                end

            end
        end
    end)
end

AddEventHandler(
    'gameEventTriggered',
    function(name, args)

        if name ~= 'CEventNetworkEntityDamage' then
            return
        end

        local playerData = exports.qbx_core:GetPlayerData()
        local race = playerData.metadata.creatureRace

        if race ~= 'orc' then
            return
        end

        local ped = PlayerPedId()

        if not DoesEntityExist(ped) then
            return
        end

        local victim = args[1]

        if victim ~= ped then
            return
        end

        if IsEntityDead(ped) then
            return
        end

        -- Any damage refreshes Enrage.
        StartEnrage()
    end
)

CreateThread(function()

    local wasJumping = false

    while true do

        Wait(0)

        if not enrageActive then
            wasJumping = false
            goto continue
        end

        local ped = PlayerPedId()

        if not DoesEntityExist(ped) then
            goto continue
        end

        if IsEntityDead(ped) then
            goto continue
        end

        local jumping =
            IsPedJumping(ped)

        if jumping and not wasJumping then

            local config = GetEnrageConfig()

            local velocity =
                GetEntityVelocity(ped)

            local forward =
                GetEntityForwardVector(ped)

            local horizontalVelocity =
                math.sqrt(
                    velocity.x * velocity.x +
                    velocity.y * velocity.y
                )

            local boostedVelocity =
                horizontalVelocity *
                config.JumpMultiplier

            SetEntityVelocity(
                ped,
                forward.x * boostedVelocity,
                forward.y * boostedVelocity,
                velocity.z + 10.0
            )

        end

        wasJumping = jumping

        ::continue::
    end
end)

AddEventHandler(
    'onResourceStop',
    function(resourceName)

        if resourceName ~= GetCurrentResourceName() then
            return
        end

        if enrageActive then
            SetPlayerMeleeWeaponDamageModifier(
                PlayerId(),
                1.0
            )
        end
    end
)

exports(
    'IsEnraged',
    function()
        return enrageActive
    end
)

exports(
    'StopEnrage',
    function()
        StopEnrage()
    end
)

-- Angel
local angelSanctuaryActive = false
local angelSanctuaryCoords = nil
local angelSanctuaryRadius = 0.0
local angelSanctuaryExpires = 0

local SANCTUARY_PTFX_DICT = 'scr_ch_finale'
local SANCTUARY_PTFX = 'scr_ch_finale_hit_gold'

local function LoadSanctuaryPtfx()

    RequestNamedPtfxAsset(
        SANCTUARY_PTFX_DICT
    )

    local timeout =
        GetGameTimer() + 5000

    while not HasNamedPtfxAssetLoaded(
        SANCTUARY_PTFX_DICT
    ) do

        Wait(10)

        if GetGameTimer() >= timeout then
            return false
        end
    end

    return true
end

RegisterNetEvent(
    'sns_creatures:client:angelSanctuary',
    function(coords, duration, radius)

        angelSanctuaryActive = true

        angelSanctuaryCoords = coords

        angelSanctuaryRadius =
            tonumber(radius) or 15.0

        angelSanctuaryExpires =
            GetGameTimer() +
            ((tonumber(duration) or 15) * 1000)

        lib.notify({
            title = "Sanctuary",
            description = "Divine protection surrounds you.",
            type = "success"
        })

        -- Load particle asset
        local ptfxLoaded =
            LoadSanctuaryPtfx()

        -- Activation effects
        if ptfxLoaded then

            UseParticleFxAsset(
                SANCTUARY_PTFX_DICT
            )

            StartNetworkedParticleFxNonLoopedAtCoord(
                SANCTUARY_PTFX,
                coords.x,
                coords.y,
                coords.z + 0.5,
                0.0,
                0.0,
                0.0,
                2.0,
                false,
                false,
                false
            )

            -- Golden bursts around the sanctuary
            for i = 1, 16 do

                local angle =
                    math.rad(i * 22.5)

                local x =
                    coords.x +
                    math.cos(angle) *
                    angelSanctuaryRadius

                local y =
                    coords.y +
                    math.sin(angle) *
                    angelSanctuaryRadius

                UseParticleFxAsset(
                    SANCTUARY_PTFX_DICT
                )

                StartNetworkedParticleFxNonLoopedAtCoord(
                    SANCTUARY_PTFX,
                    x,
                    y,
                    coords.z + 0.5,
                    0.0,
                    0.0,
                    angle,
                    0.5,
                    false,
                    false,
                    false
                )
            end
        end

        -- Activation sound
        PlaySoundFrontend(
            -1,
            'CHECKPOINT_PERFECT',
            'HUD_MINI_GAME_SOUNDSET',
            true
        )

        -- Main Sanctuary thread
        CreateThread(function()

            local nextParticle =
                GetGameTimer()

            while angelSanctuaryActive do

                Wait(0)

                local now =
                    GetGameTimer()

                if now >= angelSanctuaryExpires then
                    break
                end

                local ped =
                    PlayerPedId()

                local playerCoords =
                    GetEntityCoords(ped)

                local distance =
                    #(playerCoords - angelSanctuaryCoords)

                -- Protection
                if distance <= angelSanctuaryRadius then

                    SetEntityInvincible(
                        ped,
                        true
                    )

                else

                    SetEntityInvincible(
                        ped,
                        false
                    )
                end

                -- Golden shield sphere
                DrawMarker(
                    28,
                    angelSanctuaryCoords.x,
                    angelSanctuaryCoords.y,
                    angelSanctuaryCoords.z + 1.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    angelSanctuaryRadius * 2.0,
                    angelSanctuaryRadius * 2.0,
                    angelSanctuaryRadius * 2.0,
                    255,
                    215,
                    70,
                    30,
                    false,
                    false,
                    2,
                    false,
                    nil,
                    nil,
                    false
                )

                -- Golden ground ring
                DrawMarker(
                    1,
                    angelSanctuaryCoords.x,
                    angelSanctuaryCoords.y,
                    angelSanctuaryCoords.z - 1.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    angelSanctuaryRadius * 2.0,
                    angelSanctuaryRadius * 2.0,
                    0.15,
                    255,
                    215,
                    70,
                    100,
                    false,
                    false,
                    2,
                    false,
                    nil,
                    nil,
                    false
                )

                -- Pulsing golden light
                local pulse =
                    50.0 +
                    (
                        math.sin(
                            now / 250.0
                        ) + 1.0
                    ) * 40.0

                DrawLightWithRange(
                    angelSanctuaryCoords.x,
                    angelSanctuaryCoords.y,
                    angelSanctuaryCoords.z + 1.0,
                    255,
                    215,
                    70,
                    angelSanctuaryRadius * 1.5,
                    pulse
                )

                -- Periodic gold particles
                if ptfxLoaded and now >= nextParticle then

                    nextParticle =
                        now + 600

                    for i = 1, 12 do

                        local angle =
                            math.rad(
                                (i * 30) +
                                ((now / 20) % 360)
                            )

                        local particleRadius =
                            angelSanctuaryRadius * 0.95

                        local x =
                            angelSanctuaryCoords.x +
                            math.cos(angle) *
                            particleRadius

                        local y =
                            angelSanctuaryCoords.y +
                            math.sin(angle) *
                            particleRadius

                        local z =
                            angelSanctuaryCoords.z +
                            0.5 +
                            math.sin(
                                now / 500.0 + i
                            ) * 1.5

                        UseParticleFxAsset(
                            SANCTUARY_PTFX_DICT
                        )

                        StartNetworkedParticleFxNonLoopedAtCoord(
                            SANCTUARY_PTFX,
                            x,
                            y,
                            z,
                            0.0,
                            0.0,
                            angle,
                            0.35,
                            false,
                            false,
                            false
                        )
                    end
                end
            end

            -- Remove protection
            SetEntityInvincible(
                PlayerPedId(),
                false
            )

            angelSanctuaryActive = false
            angelSanctuaryCoords = nil
            angelSanctuaryRadius = 0.0
            angelSanctuaryExpires = 0
        end)

        -- Ending effect
        CreateThread(function()

            local remaining =
                math.max(
                    0,
                    (
                        angelSanctuaryExpires -
                        GetGameTimer()
                    ) - 750
                )

            Wait(remaining)

            if not angelSanctuaryCoords then
                return
            end

            local endCoords =
                angelSanctuaryCoords

            local endRadius =
                angelSanctuaryRadius

            if ptfxLoaded then

                for i = 1, 20 do

                    local angle =
                        math.rad(i * 18)

                    local x =
                        endCoords.x +
                        math.cos(angle) *
                        endRadius

                    local y =
                        endCoords.y +
                        math.sin(angle) *
                        endRadius

                    UseParticleFxAsset(
                        SANCTUARY_PTFX_DICT
                    )

                    StartNetworkedParticleFxNonLoopedAtCoord(
                        SANCTUARY_PTFX,
                        x,
                        y,
                        endCoords.z + 0.5,
                        0.0,
                        0.0,
                        angle,
                        0.6,
                        false,
                        false,
                        false
                    )
                end
            end

            PlaySoundFrontend(
                -1,
                'CHECKPOINT_NORMAL',
                'HUD_MINI_GAME_SOUNDSET',
                true
            )
        end)
    end
)

local ANGEL_SMITE_DICT = 'core'

local ANGEL_SMITE_FIRE = 'ent_amb_fbi_fire_lg'
local ANGEL_SMITE_ELECTRIC = 'ent_amb_elec_crackle'
local ANGEL_SMITE_FIRE_RING = 'ent_amb_fire_ring'

local function LoadAngelSmiteEffects()
    if HasNamedPtfxAssetLoaded(ANGEL_SMITE_DICT) then
        return true
    end

    RequestNamedPtfxAsset(ANGEL_SMITE_DICT)

    local timeout = GetGameTimer() + 5000

    while not HasNamedPtfxAssetLoaded(ANGEL_SMITE_DICT) do
        Wait(10)

        if GetGameTimer() >= timeout then
            print('[SNS Creatures] Failed to load Angel Smite PTFX')
            return false
        end
    end

    return true
end

RegisterNetEvent(
    'sns_creatures:client:angelDivineSmite',
    function(coords, duration, radius)

        if not LoadAngelSmiteEffects() then
            return
        end

        local endTime =
            GetGameTimer() + (duration * 1000)

        local effects = {}

        -- FIRE AT THE BASE

        local firePositions = {
            { 0.0, 0.0, 0.10, 1.2 },
            { 1.5, 0.0, 0.10, 0.9 },
            { -1.5, 0.0, 0.10, 0.9 },
            { 0.0, 1.5, 0.10, 0.9 },
            { 0.0, -1.5, 0.10, 0.9 }
        }

        for _, fireData in ipairs(firePositions) do

            UseParticleFxAssetNextCall(
                ANGEL_SMITE_DICT
            )

            local fire =
                StartParticleFxLoopedAtCoord(
                    ANGEL_SMITE_FIRE,

                    coords.x + fireData[1],
                    coords.y + fireData[2],
                    coords.z + fireData[3],

                    0.0,
                    0.0,
                    0.0,

                    fireData[4],

                    false,
                    false,
                    false,
                    false
                )

            if fire and fire ~= 0 then

                SetParticleFxLoopedAlpha(
                    fire,
                    0.65
                )

                SetParticleFxLoopedColour(
                    fire,
                    1.0,
                    0.60,
                    0.10
                )

                effects[#effects + 1] = fire
            end
        end

        -- ELECTRIC ENERGY

        local electricPositions = {
            { 0.0, 0.0, 1.5, 1.0 },
            { 1.2, 0.0, 2.5, 0.8 },
            { -1.2, 0.0, 3.5, 0.8 },
            { 0.0, 1.2, 4.5, 0.8 },
            { 0.0, -1.2, 5.5, 0.8 }
        }

        for _, electricData in ipairs(electricPositions) do

            UseParticleFxAssetNextCall(
                ANGEL_SMITE_DICT
            )

            local electric =
                StartParticleFxLoopedAtCoord(
                    ANGEL_SMITE_ELECTRIC,

                    coords.x + electricData[1],
                    coords.y + electricData[2],
                    coords.z + electricData[3],

                    0.0,
                    0.0,
                    0.0,

                    electricData[4],

                    false,
                    false,
                    false,
                    false
                )

            if electric and electric ~= 0 then

                SetParticleFxLoopedAlpha(
                    electric,
                    0.65
                )

                SetParticleFxLoopedColour(
                    electric,
                    1.0,
                    0.85,
                    0.35
                )

                effects[#effects + 1] = electric
            end
        end

        -- FIRE RING

        UseParticleFxAssetNextCall(
            ANGEL_SMITE_DICT
        )

        local fireRing =
            StartParticleFxLoopedAtCoord(
                ANGEL_SMITE_FIRE_RING,

                coords.x,
                coords.y,
                coords.z + 0.05,

                0.0,
                0.0,
                0.0,

                math.max(radius * 0.25, 0.75),

                false,
                false,
                false,
                false
            )

        if fireRing and fireRing ~= 0 then

            SetParticleFxLoopedAlpha(
                fireRing,
                0.65
            )

            SetParticleFxLoopedColour(
                fireRing,
                1.0,
                0.65,
                0.10
            )

            effects[#effects + 1] = fireRing
        end

        -- BEAM / GROUND RING / LIGHTING

        CreateThread(function()

            local beamHeight = 18.0
            local beamStartTime = GetGameTimer()

            while GetGameTimer() < endTime do

                Wait(0)

                local time = GetGameTimer()

                local pulse =
                    0.90 +
                    (
                        math.sin(time * 0.008) * 0.10
                    )

                -- BEAM FADE

                local beamAge = time - beamStartTime

                local beamFade = 1.0

                if beamAge >= 1000 then
                    beamFade =
                        1.0 -
                        (
                            (beamAge - 1000) / 500
                        )
                    
                    if beamFade < 0.0 then
                        beamFade = 0.0
                    end
                end

                -- SOLID YELLOW OUTER BEAM

                DrawMarker(
                    1,

                    coords.x,
                    coords.y,
                    coords.z,

                    0.0,
                    0.0,
                    0.0,

                    0.0,
                    0.0,
                    0.0,

                    radius * 0.55,
                    radius * 0.55,
                    beamHeight,

                    255,
                    223,
                    0,

                    math.floor(
                        50 *
                        pulse *
                        beamFade
                    ),

                    false,
                    false,
                    2,
                    false,
                    nil,
                    nil,
                    false
                )

                -- INNER BRIGHT BEAM

                DrawMarker(
                    1,

                    coords.x,
                    coords.y,
                    coords.z,

                    0.0,
                    0.0,
                    0.0,

                    0.0,
                    0.0,
                    0.0,

                    radius * 0.45,
                    radius * 0.45,
                    beamHeight,

                    255,
                    255,
                    255,

                    math.floor(
                        300*
                        pulse *
                        beamFade
                    ),

                    false,
                    false,
                    2,
                    false,
                    nil,
                    nil,
                    false
                )

                -- LARGE YELLOW CIRCLE AROUND THE BASE

                DrawMarker(
                    25,

                    coords.x,
                    coords.y,
                    coords.z + 0.04,

                    0.0,
                    0.0,
                    0.0,

                    0.0,
                    0.0,
                    0.0,

                    radius * 1.50,
                    radius * 1.50,
                    0.12,

                    255,
                    223,
                    0,

                    math.floor(
                        25 *
                        pulse
                    ),

                    false,
                    false,
                    2,
                    false,
                    nil,
                    nil,
                    false
                )

                -- YELLOW LIGHTING

                DrawLightWithRange(
                    coords.x,
                    coords.y,
                    coords.z + 1.0,

                    255,
                    210,
                    50,

                    radius * 3.0,
                    55.0
                )

                DrawLightWithRange(
                    coords.x,
                    coords.y,
                    coords.z + 6.0,

                    255,
                    220,
                    80,

                    radius * 2.0,
                    40.0
                )

                DrawLightWithRange(
                    coords.x,
                    coords.y,
                    coords.z + 12.0,

                    255,
                    235,
                    130,

                    radius * 1.5,
                    30.0
                )
            end
        end)

        -- CLEANUP

        CreateThread(function()

            Wait(duration * 1000)

            for _, effect in ipairs(effects) do

                if effect and effect ~= 0 then

                    StopParticleFxLooped(
                        effect,
                        false
                    )

                end
            end

            RemoveNamedPtfxAsset(
                ANGEL_SMITE_DICT
            )
        end)
    end
)

RegisterNetEvent(
    'sns_creatures:client:angelDivineSmiteImpact',
    function()

        PlaySoundFrontend(
            -1,
            'CHECKPOINT_PERFECT',
            'HUD_MINI_GAME_SOUNDSET',
            true
        )

        ShakeGameplayCam(
            'LARGE_EXPLOSION_SHAKE',
            0.15
        )
    end
)

RegisterNetEvent(
    'sns_creatures:client:angelSmiteDamage',
    function(damage, sourceId)

        local ped = PlayerPedId()

        if IsPedDeadOrDying(ped) then
            return
        end

        local health =
            GetEntityHealth(ped)

        local newHealth =
            math.max(0, health - damage)

        SetEntityHealth(
            ped,
            newHealth
        )

        ShakeGameplayCam(
            "SMALL_EXPLOSION_SHAKE",
            0.15
        )
    end
)

-- Kitsune
local function IsKitsune()
    local playerData = exports.qbx_core:GetPlayerData()

    return playerData
        and playerData.metadata
        and playerData.metadata.creatureRace == 'kitsune'
end

local function LoadPtfx(dict)
    RequestNamedPtfxAsset(dict)

    local timeout = GetGameTimer() + 3000

    while not HasNamedPtfxAssetLoaded(dict) do
        Wait(10)

        if GetGameTimer() >= timeout then
            return false
        end
    end

    return true
end

local function GetAimDirection()
    local rotation = GetGameplayCamRot(2)
    local pitch = math.rad(rotation.x)
    local yaw = math.rad(rotation.z)
    local horizontal = math.cos(pitch)

    return vector3(
        -math.sin(yaw) * horizontal,
        math.cos(yaw) * horizontal,
        math.sin(pitch)
    )
end

-- DASH MOVEMENT: only runs for the activating Kitsune.

RegisterNetEvent('sns_creatures:client:kitsuneDash', function(config)
    if not IsKitsune() then return end

    local ped = PlayerPedId()

    if IsEntityDead(ped) or IsPedInAnyVehicle(ped, false) then
        return
    end

    local direction = GetAimDirection()
    local speed = tonumber(config.Speed) or 35.0

    SetEntityVelocity(
        ped,
        direction.x * speed,
        direction.y * speed,
        direction.z * speed
    )

    -- Record the dash path and send it to the server for nearby players.
    CreateThread(function()
        local points = {}
        local endTime = GetGameTimer() + 400
        local lastPoint = GetEntityCoords(ped)

        while GetGameTimer() < endTime do
            local coords = GetEntityCoords(ped)

            if #(coords - lastPoint) >= 0.5 then
                points[#points + 1] = {
                    x = coords.x,
                    y = coords.y,
                    z = coords.z
                }

                lastPoint = coords

                if #points >= 30 then
                    break
                end
            end

            Wait(0)
        end

        if #points > 0 then
            TriggerServerEvent(
                'sns_creatures:server:kitsuneDashTrail',
                points
            )
        end
    end)
end)


-- DASH FIRE: broadcast by the server to nearby clients.


RegisterNetEvent('sns_creatures:client:kitsuneDashTrailFX', function(points)
    CreateThread(function()
        local dict = 'core'

        if not LoadPtfx(dict) then return end

        local effects = {}

        for _, point in ipairs(points) do
            UseParticleFxAssetNextCall(dict)

            local fx = StartParticleFxLoopedAtCoord(
                'ent_amb_fire_ring',
                point.x,
                point.y,
                point.z - 0.5,
                0.0,
                0.0,
                0.0,
                0.45,
                false,
                false,
                false,
                false
            )

            if fx and fx ~= 0 then
                SetParticleFxLoopedColour(
                    fx,
                    1.0,
                    0.25,
                    0.02,
                    false
                )

                effects[#effects + 1] = fx
            end

            Wait(15)
        end

        Wait(400)

        for _, fx in ipairs(effects) do
            StopParticleFxLooped(fx, false)
        end

        RemoveNamedPtfxAsset(dict)
    end)
end)

RegisterNetEvent('sns_creatures:client:kitsuneDashFX', function(serverId, config)
    local playerId = GetPlayerFromServerId(serverId)
    if playerId == -1 then return end

    local ped = GetPlayerPed(playerId)
    if ped == 0 or not DoesEntityExist(ped) then return end

    CreateThread(function()
        local dict = 'core'

        if not LoadPtfx(dict) then return end

        local duration = math.max(
            100,
            tonumber(config.FireDuration) or 400
        )

        local endTime = GetGameTimer() + duration
        local lastCoords = GetEntityCoords(ped)
        local effects = {}

        while GetGameTimer() < endTime do
            if not DoesEntityExist(ped) then break end

            local coords = GetEntityCoords(ped)
            local distance = #(coords - lastCoords)

            -- Add fire along the path as the player moves.
            if distance >= 0.6 then
                UseParticleFxAssetNextCall(dict)

                local fx = StartParticleFxLoopedAtCoord(
                    'ent_amb_fire_ring',
                    lastCoords.x,
                    lastCoords.y,
                    lastCoords.z - 0.5,
                    0.0,
                    0.0,
                    0.0,
                    0.45,
                    false,
                    false,
                    false,
                    false
                )

                if fx and fx ~= 0 then
                    SetParticleFxLoopedColour(
                        fx,
                        1.0,
                        0.25,
                        0.02,
                        false
                    )

                    effects[#effects + 1] = fx
                end

                lastCoords = coords
            end

            Wait(0)
        end

        -- Stop every trail segment after the dash.
        for _, fx in ipairs(effects) do
            StopParticleFxLooped(fx, false)
        end

        RemoveNamedPtfxAsset(dict)
    end)
end)


-- FOX FIRE: large white guiding orb attached visually to the Kitsune.

RegisterNetEvent('sns_creatures:client:kitsuneFoxFireFX', function(serverId, config)
    local playerId = GetPlayerFromServerId(serverId)
    if playerId == -1 then return end

    local ped = GetPlayerPed(playerId)
    if ped == 0 or not DoesEntityExist(ped) then return end

    -- Capture the summon position once.
    local coords = GetEntityCoords(ped)
    local heading = math.rad(GetEntityHeading(ped))

    local behind = tonumber(config.BehindDistance) or 1.2
    local height = tonumber(config.Height) or 2.8

    local orbX = coords.x - math.sin(heading) * behind
    local orbY = coords.y + math.cos(heading) * behind
    local orbZ = coords.z + height

    local duration = math.max(
        0,
        tonumber(config.DisperseTime) or 10
    ) * 1000

    local radius = tonumber(config.OrbRadius) or 0.65
    local lightRange = tonumber(config.LightRange) or 12.0

    CreateThread(function()
        local endTime = GetGameTimer() + duration

        while GetGameTimer() < endTime do
            local pulse = 1.0 + math.sin(GetGameTimer() / 250.0) * 0.08

            DrawMarker(
                28,
                orbX,
                orbY,
                orbZ,
                0.0, 0.0, 0.0,
                0.0, 0.0, 0.0,
                radius * 0.5 * pulse,
                radius * 0.5 * pulse,
                radius * 0.5 * pulse,
                255, 140, 30, 220,
                false,
                false,
                2,
                false,
                nil,
                nil,
                false
            )

            DrawLightWithRange(
                orbX,
                orbY,
                orbZ,
                255,
                120,
                20,
                lightRange,
                3.0
            )

            Wait(0)
        end
    end)
end)

