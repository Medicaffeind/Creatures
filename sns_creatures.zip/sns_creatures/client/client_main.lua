-- Client: sns_creatures/main.lua

PassiveAbilities = PassiveAbilities or {}
ActiveAbilities = ActiveAbilities or {}
Cooldowns = Cooldowns or {}

local currentRace = nil
local currentForm = nil
local hasEditedForms = {}
local currentTier = 0
local maxToughness = 0
local currentToughness = 0
local toughnessInitialized = false

local previousHealth = 0
local previousArmor = 0

-- Load Saved Race
local function LoadSavedRace()
    Wait(2000)
    local race = lib.callback.await('sns_creatures:server:getSavedRace', false)
    if not race then return end

    currentRace = race
    lib.notify({
        title = "Race Loaded",
        description = "Your race is: " .. race,
        type = "info"
    })

    if exports['sns_creatures'] and type(exports['sns_creatures'].StartRaceAbilities) == "function" then
        exports['sns_creatures']:StartRaceAbilities(race)
    end
end

-- Save Form Appearance
local function SaveFormAppearance(formType, appearance)
    if not currentRace then
        return lib.notify({
            title = "Race Not Set",
            description = "You must have a race before saving a form.",
            type = "error"
        })
    end

    if not formType or not appearance then
        return lib.notify({
            title = "Invalid Data",
            description = "Form type or appearance missing.",
            type = "error"
        })
    end

    local success = lib.callback.await("sns_creatures:server:saveFormAppearance", false, currentRace, formType, appearance)
    if success then
        hasEditedForms[currentRace] = hasEditedForms[currentRace] or {}
        hasEditedForms[currentRace][formType] = true

        lib.notify({
            title = "Form Saved",
            description = ("Your %s form appearance was saved."):format(formType),
            type = "success"
        })
    else
        lib.notify({
            title = "Save Failed",
            description = "Could not save your appearance.",
            type = "error"
        })
    end
end

-- Edit Form Command (Illenium integration)
RegisterCommand("editform", function(_, args)
    if not currentRace then
        return lib.notify({
            title = "Race",
            description = "You have no race assigned.",
            type = "error"
        })
    end

    local formType = args[1]
    if formType ~= "transform" and formType ~= "mutate" then
        return lib.notify({
            title = "Usage",
            description = "/editform [transform|mutate]",
            type = "error"
        })
    end

    exports['illenium-appearance']:ForceClothMenu(true, true, formType == "mutate")

end, false)

-- Apply Saved Appearance
local function ApplySavedAppearance(formType)
    if not currentRace then return false end
    local data = lib.callback.await('sns_creatures:server:getFormAppearance', false, currentRace, formType)
    if not data then return false end

    local pedModel = data.model
    local appearance = data.appearance

    if type(appearance) == "string" then
        appearance = json.decode(appearance)
    end

    if appearance then
        exports['illenium-appearance']:setPedAppearance(PlayerPedId(), appearance)
    end

    if Config.VFX.EnableScreenFade then
        DoScreenFadeOut(500)
        Wait(500)
        DoScreenFadeIn(500)
    end

    if Config.VFX.EnableSound then
        PlaySoundFrontend(-1, Config.VFX.TransformSound, "HUD_FRONTEND_DEFAULT_SOUNDSET", false)
    end

    if Config.VFX.EnableParticles then
        UseParticleFxAssetNextCall(Config.VFX.ParticleAsset)
        StartParticleFxNonLoopedAtCoord(Config.VFX.ParticleEffect, GetEntityCoords(PlayerPedId()), 0,0,0,1.0, false, false, false)
    end

    return true
end

-- Transform / Mutate
local function Transform(formType)
    if not currentRace then
        return lib.notify({ title = "No Race", description = "You have no race assigned.", type = "error" })
    end

    local raceData = Config.Races[currentRace]
    if not raceData then return end

    local model
    if formType == "transform" then
        if currentTier == 5 and raceData.eldertransformModel then
            model = raceData.eldertransformModel
        else
            model = raceData.transformModel
        end
    elseif formType == "mutate" then
        model = raceData.mutateModel
    else
        return
    end

    local playerId = PlayerId()
    local currentStamina = GetPlayerStamina(playerId)
    local staminaCost = 25.0

    if currentStamina < staminaCost then
        return lib.notify({
            title = "Too Exhausted",
            description = "You don't have enough stamina to transform.",
            type = "error"
        })
    end

    SetPlayerStamina(playerId, currentStamina - staminaCost)

    -- check if the player has saved this form before
    local hasSaved = lib.callback.await('sns_creatures:server:hasFormAppearance', false, currentRace, formType)

    if not hasSaved then
        lib.notify({
            title = "First Time Setup",
            description = ("You haven't set your %s form yet. Transforming now and opening the editor..."):format(formType),
            type = "inform"
        })

        lib.requestModel(model)
        SetPlayerModel(PlayerId(), model)
        SetModelAsNoLongerNeeded(model)
        currentForm = formType
        LoadToughness()

        Wait(500)
        ExecuteCommand(("editform %s"):format(formType))
        return
    end

    lib.requestModel(model)
    SetPlayerModel(PlayerId(), model)
    SetModelAsNoLongerNeeded(model)
    currentForm = formType
    LoadToughness()

    Wait(500)
    ApplySavedAppearance(formType)
end

-- Revert to Human
local function RevertForm()
    if GetEntityModel(PlayerPedId()) == `mp_m_freemode_01` or GetEntityModel(PlayerPedId()) == `mp_f_freemode_01` then
        return lib.notify({ title = "Already Human", type = "info" })
    end

    TriggerEvent("illenium-appearance:client:reloadSkin", true)
    SetToughness(0)
    lib.notify({ title = "Reverted", description = "Returned to normal form.", type = "success" })
    currentForm = nil
end

-- Load Tier
local function LoadSavedTier()
    Wait(2500)
    currentTier = lib.callback.await('sns_creatures:server:getSavedTier', false) or 0
end

-- Tier helper
local function GetTierName(race, tier)
    if not race or not tier then return "Unknown" end

    local raceData = Config.Races[race]
    if not raceData or not raceData.Tiers then return "Unknown" end

    return raceData.Tiers[tier] or "Unknown"
end

-- Commands
RegisterCommand("race", function()
    if currentRace then
        lib.notify({ title = "Your Race", description = "You are currently a " .. currentRace .. ".", type = "info" })
    else
        lib.notify({ title = "Your Race", description = "You do not have a race assigned.", type = "warning" })
    end
end, false)

RegisterCommand("transform", function() Transform("transform") end, false)
RegisterCommand("mutate", function() Transform("mutate") end, false)
RegisterCommand("revert", function() RevertForm() end, false)

-- Race Form Menu
RegisterCommand("raceform", function()
    if not currentRace then
        return lib.notify({ title = "Race Form", description = "You have no race assigned.", type = "error" })
    end

    lib.registerContext({
    id = 'race_form_menu',
    title = ('Race Form Menu (%s - Tier %s: %s)'):format(
        currentRace,
        currentTier,
        GetTierName(currentRace, currentTier)
    ),
    options = {
        { title = "Transform", description = "Enter your transform form", icon = "wand-magic-sparkles", event = "sns_creatures:transform" },
        { title = "Mutate", description = "Enter your mutate form", icon = "dna", event = "sns_creatures:mutate" },
        { title = "Revert", description = "Return to your normal form", icon = "rotate-left", event = "sns_creatures:revert" },
    }
})
    lib.showContext('race_form_menu')
end, false)

-- Show tier command
RegisterCommand("showtier", function()
    local race = lib.callback.await('sns_creatures:server:getSavedRace', false) or "None"
    local tier = lib.callback.await('sns_creatures:server:getSavedTier', false) or 0
    local tierName = GetTierName(race, tier)

    lib.notify({
        title = "Creature Tier",
        description = ("Race: %s\nTier: %s"):format(race, tierName),
        type = "info"
    })
end, false)

-- Event Hooks
RegisterNetEvent('sns_creatures:transform', function() Transform("transform") end)
RegisterNetEvent('sns_creatures:mutate', function() Transform("mutate") end)
RegisterNetEvent('sns_creatures:revert', RevertForm)

RegisterNetEvent('sns_creatures:client:setRace', function(race)
    currentRace = race
    LoadToughness()
    lib.notify({ title = 'Race Selected', description = 'You are now a ' .. race, type = 'success' })

    if exports['sns_creatures'] and type(exports['sns_creatures'].StartRaceAbilities) == "function" then
        exports['sns_creatures']:StartRaceAbilities(race)
    end
end)

RegisterNetEvent('sns_creatures:client:clearRace', function()
    currentRace = nil
    SetToughness(0)
    lib.notify({ title = 'Race Cleared', description = 'You are now human again.', type = 'info' })
    if exports['sns_creatures'] and type(exports['sns_creatures'].StopCurrentRaceAbilities) == "function" then
        exports['sns_creatures']:StopCurrentRaceAbilities()
    end
end)

RegisterNetEvent('sns_creatures:client:saveFormAppearance', function(formType, appearance)
    SaveFormAppearance(formType, appearance)
end)

-- Tier Events
RegisterNetEvent('sns_creatures:client:setTier', function(newTier)
    if not currentRace then
        return lib.notify({
            title = "Tier Update Failed",
            description = "No race is assigned.",
            type = "error"
        })
    end

    currentTier = newTier
    local tierName = GetTierName(currentRace, newTier)

    lib.notify({
        title = "Tier Updated",
        description = ("Your %s tier is now: %s"):format(currentRace, tierName),
        type = "success"
    })
end)

RegisterNetEvent('sns_creatures:client:clearTier', function()
    currentTier = 0

    lib.notify({
        title = "Tier Reset",
        description = "Your creature tier has been cleared.",
        type = "info"
    })
end)

-- Toughness

function SetToughness(amount)
    amount = tonumber(amount) or 0

    maxToughness = math.max(0, amount)
    currentToughness = maxToughness

    local ped = PlayerPedId()

    if DoesEntityExist(ped) then
        previousHealth = GetEntityHealth(ped)
        previousArmor = GetPedArmour(ped)
    end

    toughnessInitialized = maxToughness > 0
end

RegisterNetEvent('sns_creatures:client:setToughness', function(amount)
    SetToughness(amount)
end)

function LoadToughness()
    local amount = lib.callback.await(
        'sns_creatures:server:getToughness',
        false
    )

    SetToughness(amount)
end

function GetCurrentToughness()
    return currentToughness
end

exports('GetCurrentToughness', GetCurrentToughness)

function GetMaxToughness()
    return maxToughness
end

exports('GetMaxToughness', GetMaxToughness)

-- Toughness Damage Handling

AddEventHandler('gameEventTriggered', function(name, args)
    if name ~= 'CEventNetworkEntityDamage' then
        return
    end

    if not toughnessInitialized then
        return
    end

    if currentToughness <= 0 then
        return
    end

    local ped = PlayerPedId()

    if not DoesEntityExist(ped) then
        return
    end

    local victim = args[1]

    if victim ~= ped then
        return
    end

    local currentHealth = GetEntityHealth(ped)
    local currentArmor = GetPedArmour(ped)

    local healthDamage = previousHealth - currentHealth

    if healthDamage <= 0 then
        previousHealth = currentHealth
        previousArmor = currentArmor
        return
    end

    if currentArmor > 0 then
        previousHealth = currentHealth
        previousArmor = currentArmor
        return
    end

    local absorbed = math.min(currentToughness, healthDamage)

    currentToughness = currentToughness - absorbed

    if absorbed > 0 then
        local restoredHealth = currentHealth + absorbed

        SetEntityHealth(ped, restoredHealth)

        previousHealth = restoredHealth
        previousArmor = GetPedArmour(ped)
    else
        previousHealth = currentHealth
        previousArmor = currentArmor
    end
end)

CreateThread(function()
    Wait(1000)

    LoadToughness()

    while true do
        Wait(100)

        local ped = PlayerPedId()

        if not DoesEntityExist(ped) then
            goto continue
        end

        if IsEntityDead(ped) then
            toughnessInitialized = false
            currentToughness = 0

            goto continue
        end

        if not toughnessInitialized then
            LoadToughness()
        end

        previousHealth = GetEntityHealth(ped)
        previousArmor = GetPedArmour(ped)

        ::continue::
    end
end)


-- Load Race on Spawn / Restart
AddEventHandler('QBCore:Client:OnPlayerLoaded', function()
    LoadSavedRace()
    LoadSavedTier()
end)

AddEventHandler('onResourceStart', function(resource)
    if resource == GetCurrentResourceName() then
        LoadSavedRace()
        LoadSavedTier()
    end
end)

-- Client Race Check
function HasRequiredRaceClient(requiredRace)
    local playerData = exports.qbx_core:GetPlayerData()
    if not playerData then return false end

    local playerRace = playerData.metadata.creatureRace or 'human'

    if not requiredRace then return true end

    if type(requiredRace) == 'string' then
        return playerRace == requiredRace
    end

    if type(requiredRace) == 'table' then
        for i = 1, #requiredRace do
            if requiredRace[i] == playerRace then
                return true
            end
        end

        if requiredRace.allow then
            for i = 1, #requiredRace.allow do
                if requiredRace.allow[i] == playerRace then
                    return true
                end
            end
            return false
        end

        if requiredRace.deny then
            for i = 1, #requiredRace.deny do
                if requiredRace.deny[i] == playerRace then
                    return false
                end
            end
            return true
        end
    end

    return false
end

exports('HasRequiredRaceClient', HasRequiredRaceClient)

function GetCurrentTier()
    return currentTier or 0
end

function GetCurrentForm()
    return currentForm
end

exports('GetCurrentTier', GetCurrentTier)
exports('GetCurrentForm', GetCurrentForm)